import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/tests/upstream/baseline-20261028/native-cache/runs/SpecBindings/legacy/jobs.json" to "/workspace/solidity-lean/tests/upstream/baseline-20261028/native-cache/runs/SpecBindings/legacy/runtime.json"
