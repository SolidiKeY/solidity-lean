import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/tests/upstream/baseline-20261028/native-cache/runs/TryContinue/viaIR/jobs.json" to "/workspace/solidity-lean/tests/upstream/baseline-20261028/native-cache/runs/TryContinue/viaIR/runtime.json"
