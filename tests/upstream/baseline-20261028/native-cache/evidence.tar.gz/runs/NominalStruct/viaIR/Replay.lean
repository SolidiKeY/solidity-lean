import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/tests/upstream/baseline-20261028/native-cache/runs/NominalStruct/viaIR/jobs.json" to "/workspace/solidity-lean/tests/upstream/baseline-20261028/native-cache/runs/NominalStruct/viaIR/runtime.json"
