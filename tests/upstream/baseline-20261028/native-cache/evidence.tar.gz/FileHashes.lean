import Lake.Build.Trace
open Lean Lake

def main (args : List String) : IO Unit := do
  let input := args.head!
  let output := args[1]!
  let jobs := ((Json.parse (← IO.FS.readFile input)).toOption.getD Json.null).getArr?.toOption.getD #[]
  let mut rows : Array Json := #[]
  for job in jobs do
    let path := (job.getObjValAs? String "path").toOption.getD ""
    let text := (job.getObjValAs? Bool "text").toOption.getD false
    let h ← computeFileHash path text
    rows := rows.push (Json.mkObj [("path",toJson path),("text",toJson text),("lakeHash",toJson (toString h))])
  IO.FS.writeFile output (toJson rows).pretty
