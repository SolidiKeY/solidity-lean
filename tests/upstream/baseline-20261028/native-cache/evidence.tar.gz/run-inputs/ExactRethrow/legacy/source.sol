pragma solidity ^0.8.0; contract ExactRethrow {function exact() public pure {bytes memory data=hex"0102";assembly {revert(add(data,32),mload(data))}}}
