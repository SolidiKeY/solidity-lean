pragma solidity ^0.8.0; contract WrongRethrow {function wrong() public pure {bytes memory data=hex"0102";assembly {revert(add(data,33),mload(data))}}}
