pragma solidity ^0.8.0; contract BadClause {
 /// @custom:key ensures false; requires false
 function bad() public pure {}
}
