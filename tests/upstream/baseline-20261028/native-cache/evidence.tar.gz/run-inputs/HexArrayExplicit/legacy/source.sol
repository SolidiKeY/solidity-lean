pragma solidity ^0.8.0; contract HexArrayExplicit {function f() public pure returns(uint){bytes2[2] memory a=[bytes2(hex"abcd"),bytes2(hex"0123")];return uint16(a[1]);}}
