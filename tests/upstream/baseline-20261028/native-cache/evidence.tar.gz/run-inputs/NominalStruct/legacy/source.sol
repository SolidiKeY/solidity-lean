pragma solidity ^0.8.0; type Ticket is uint8; contract NominalStruct {struct B{Ticket x;} function f() public pure returns(uint){B memory b=B(Ticket.wrap(7));return Ticket.unwrap(b.x);}}
