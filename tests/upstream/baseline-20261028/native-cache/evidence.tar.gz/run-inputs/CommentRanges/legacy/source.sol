pragma solidity ^0.8.0;
// 😀 ordinary line comment
contract CommentRanges { /* 😀 */ function f() public pure { assert(true); } function f(uint x) public pure { assert(x==x); } }
