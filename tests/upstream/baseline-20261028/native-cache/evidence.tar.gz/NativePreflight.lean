import Solidity.Tools.Upstream
#check Solidity.Frontend.Source.read
#check Solidity.Tools.Upstream.replay
#check Solidity.Tools.Upstream.entryProg
#print axioms Solidity.Tools.Upstream.entryGuard_failed
#print axioms Solidity.Tools.Upstream.entryGuard_success
#print axioms Solidity.Tools.Upstream.entryGuard_prior
