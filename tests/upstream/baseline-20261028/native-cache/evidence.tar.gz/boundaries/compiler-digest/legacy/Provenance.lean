import Solidity.Frontend.Import
solc_import "/workspace/solidity-lean/tests/upstream/baseline-20261028/probes/rechecked/runs/ScalarMatrixValid/legacy/compiler-digest.ast.json" hash 0x5c46fec53ff4aa6 as Invalid.«ScalarMatrixValid» testing entrypoints
