import Solidity.Frontend.Import
solc_import "/workspace/solidity-lean/tests/upstream/baseline-20261028/probes/rechecked/runs/ScalarMatrixValid/viaIR/compiler-digest.ast.json" hash 0x2809fd8b20488835 as Invalid.«ScalarMatrixValid» testing entrypoints
