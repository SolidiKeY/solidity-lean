import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/tests/upstream/baseline-20261028/native-cache/boundaries/internal-entry/legacy/jobs.json" to "/workspace/solidity-lean/tests/upstream/baseline-20261028/native-cache/boundaries/internal-entry/legacy/runtime.json"
