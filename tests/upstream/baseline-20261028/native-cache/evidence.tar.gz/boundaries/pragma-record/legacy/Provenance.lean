import Solidity.Frontend.Import
solc_import "/workspace/solidity-lean/tests/upstream/baseline-20261028/probes/rechecked/runs/ScalarMatrixValid/legacy/pragma-record.ast.json" hash 0xdbb3ab3695b0805c as Invalid.«ScalarMatrixValid» testing entrypoints
