import Solidity.Frontend.Import
solc_import "/workspace/solidity-lean/tests/upstream/baseline-20261028/probes/rechecked/runs/ScalarMatrixValid/viaIR/pragma-record.ast.json" hash 0xb71cb0f80886272d as Invalid.«ScalarMatrixValid» testing entrypoints
