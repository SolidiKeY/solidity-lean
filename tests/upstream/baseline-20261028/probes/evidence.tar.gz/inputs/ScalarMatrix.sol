// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;
type Ticket is uint8;
type Switch is bool;
type Account is address;
function plusOne(uint x) pure returns (uint) { return x + 1; }
contract ScalarMatrix {
 enum Choice { A, B, C }
 uint counter;
 uint[] values;
 uint[2] fixedValues;
 struct Box { uint value; }
 Box[] boxes;
 function identifiers() public pure returns (uint) { uint $x = 7; { uint $x = 10; $x++; } return $x; }
 // require(false); imaginary annotation and emoji 😀 are ordinary comments.
 function comments() public pure returns (uint) { string memory s = "/* require(false); */"; return bytes(s).length; }
 function wrappers() public pure returns (uint) { Ticket t=Ticket.wrap(255); Switch s=Switch.wrap(true); Account a=Account.wrap(address(7)); assert(Switch.unwrap(s)); assert(Account.unwrap(a)==address(7)); return Ticket.unwrap(t); }
 function bounds() public pure returns (uint) { assert(type(int8).min == -128); assert(uint(type(Choice).max)==2); return type(uint8).max; }
 function falseBounds() public pure { assert(type(uint8).max == 254); }
 function literals() public pure returns (uint) { return uint((1.5 % 1) * 2); }
 function unicodeBytes() public pure returns (uint) { return bytes(unicode"éλ").length; }
 function addressValue() public pure returns (uint) { return uint160(payable(address(7))); }
 function unaryValue() public pure returns (uint) { int8 x=-5; return uint8(-x); }
 function bitwiseValue() public pure returns (uint) { bytes2 x=hex"ffff"; return uint16(~x); }
 function shiftValue() public pure returns (int) { int8 x=-8; return x>>1; }
 function comparison() public pure returns (bool) { int8 x=-2; return x < -1; }
 function die() internal pure returns(bool) { require(false); return true; }
 function lazyValue() public pure returns (bool) { return (false && die()) || (true || die()); }
 function increment() public returns (uint) { counter=3; uint old=counter++; assert(old==3); return counter; }
 function discard() public returns (uint) { counter=0; counter++; return counter; }
 function deleteValue() public returns (uint) { values.push(9); delete values; return values.length; }
 function uncheckedValue() public pure returns (uint) { unchecked { uint8 x=255; x++; return x; } }
 function checkedHelper(uint8 x) internal pure returns(uint8) { return x+1; }
 function uncheckedCaller() public pure returns(uint) { unchecked { return checkedHelper(255); } }
 function freeCall() public pure returns(uint) { return plusOne(4); }
 function nominalArray() public pure returns(uint) { Ticket[2] memory a=[Ticket.wrap(3),Ticket.wrap(4)]; return Ticket.unwrap(a[1]); }
 function fixedCopy() public returns(uint) { fixedValues[0]=3; fixedValues[1]=4; uint[2] memory b=fixedValues; fixedValues[0]=9; return b[0]+b[1]; }
 function construction() public pure returns(uint) { Box memory b=Box({value:7}); return b.value; }
 function compound() public returns(uint) { counter=3; counter+=4; return counter; }
 function publicEntry() public pure returns(uint) { return privateHelper(); }
 function privateHelper() private pure returns(uint) { return 7; }
 function hashKeccak() public pure returns(bool) { bytes memory a="ab"; bytes memory b="ab"; return keccak256(a)==keccak256(b); }
 function hashSha() public pure returns(bool) { return sha256(bytes("ab"))==sha256(bytes("ab")); }
 function hashRipemd() public pure returns(bool) { return ripemd160(bytes("ab"))==ripemd160(bytes("ab")); }
 function byteConcat() public pure returns(uint) { bytes memory a=bytes.concat(hex"61",hex"62"); assert(a[0]==hex"61" && a[1]==hex"62"); return a.length; }
 function stringConcatValue() public pure returns(uint) { string memory a=string.concat("a","b"); return bytes(a).length; }
 function selfIdentity() public view returns(bool) { return address(this)==address(this); }
 function nonpayable() public returns(uint) { return privateHelper(); }
 function recycled() public returns(uint) { boxes.push(Box(1)); Box storage r=boxes[0]; boxes.pop(); r.value=5; boxes.push(); return boxes[0].value; }
}
