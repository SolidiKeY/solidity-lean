pragma solidity ^0.8.0; contract WrongIdentifier {function f() public pure {uint function=1;}}
