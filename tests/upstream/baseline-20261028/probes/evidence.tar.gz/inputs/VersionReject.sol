pragma solidity >=0.9.0; contract VersionReject { function f() public pure returns(uint){return 1;} }
