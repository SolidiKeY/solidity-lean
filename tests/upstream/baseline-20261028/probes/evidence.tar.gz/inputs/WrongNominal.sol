pragma solidity ^0.8.0; type A is uint8; type B is uint8; contract WrongNominal {function f() public pure returns(A){return B.wrap(1);}}
