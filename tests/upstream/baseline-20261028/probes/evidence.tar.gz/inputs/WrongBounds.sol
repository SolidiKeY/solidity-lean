pragma solidity ^0.8.0; contract WrongBounds {function f() public pure returns(uint){return type(bool).max;}}
