pragma solidity ^0.8.0; contract WrongAddress {function f() public pure returns(address){return 0x52908400098527886e0f7030069857D2E4169EE7;}}
