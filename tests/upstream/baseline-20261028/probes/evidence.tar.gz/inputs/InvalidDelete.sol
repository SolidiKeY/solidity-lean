pragma solidity ^0.8.0; contract InvalidDelete {uint[] a; function f() public {uint[] storage r=a; delete r;}}
