import Solidity.Frontend.SolcJson.Contract
open Lean Solidity.Frontend
private def readProbe : IO Unit := do
 let fixture := (Json.parse (← IO.FS.readFile "/workspace/solidity-lean/tests/upstream/baseline-20261028/probes/rechecked/runs/ComputedRevert/viaIR/source.ast.json")).toOption.getD Json.null
 let ast := (fixture.getObjVal? "ast").toOption.getD Json.null
 let outcome : Json := match Source.read fixture ast with
  | .error e => Json.mkObj [("phase",toJson "provenance"),("status",toJson "refused"),("reason",toJson e)]
  | .ok provenance =>
   let scan := fun request => (Admission.scan ast provenance {request with declarationRoots := request.declarationRoots ++ [Admission.header [] ast] ++ (J.arrD ast "nodes").toList.filter (J.kind · == "PragmaDirective")}).normalize.requireCompilerCode false
   match readContract ast "ComputedRevert" [] true (scanSource := scan) (entrypoints := true) (viaIR := true) with
   | .error e => Json.mkObj [("phase",toJson "source-reader"),("status",toJson "refused"),("reason",toJson e)]
   | .ok c =>
    let functions := (c.ctor.toList ++ c.funs).map fun f =>
     let (status,reason,body) : String × String × Json := match f.body with
      | .error g => ("reader-refused",g.msg,Json.null)
      | .ok ss => ("reader-emitted","",toJson (ss.map fun (entry : Nat × String) => Json.mkObj [("line",toJson entry.1),("text",toJson entry.2)]))
     Json.mkObj [("function",toJson f.sourceName),("modelName",toJson f.name),("signature",toJson f.sourceSignature),("sourceId",toJson f.sourceId),("line",toJson f.line),("tag",toJson f.tag.toStr),("status",toJson status),("reason",toJson reason),("body",body),("scopeDiagnostic",match f.sourceScope.diagnostic? with | none => Json.null | some d => Json.mkObj [("name",toJson d.name.toString),("reason",toJson d.reason)])]
    Json.mkObj [("phase",toJson "source-reader"),("status",toJson "reader-completed"),("functions",toJson functions),("members",toJson c.members),("functionMembers",toJson c.funMembers),("initializationMembers",toJson c.initMembers),("dropped",toJson (c.dropped.map fun (e : String × Gap) => Json.mkObj [("name",toJson e.1),("reason",toJson e.2.msg),("line",toJson e.2.line)])),("initializationGap",match c.initGap with | none => Json.null | some g => toJson g.msg)]
 IO.FS.writeFile "/workspace/solidity-lean/tests/upstream/baseline-20261028/probes/rechecked/runs/ComputedRevert/viaIR/reader-complete.json" outcome.pretty
#eval readProbe
