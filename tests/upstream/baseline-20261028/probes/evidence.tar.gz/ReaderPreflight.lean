import Solidity.Frontend.SolcJson.Contract
#check Solidity.Frontend.Source.read
#check Solidity.Frontend.readContract
#check Solidity.Frontend.Admission.scan
