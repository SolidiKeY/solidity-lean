import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-H2SxoB/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-H2SxoB/checkpoint.json"
