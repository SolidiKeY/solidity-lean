import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-94uoMF/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-94uoMF/checkpoint.json"
