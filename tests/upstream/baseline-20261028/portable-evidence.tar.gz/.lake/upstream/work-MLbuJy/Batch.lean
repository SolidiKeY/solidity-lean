import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-MLbuJy/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-MLbuJy/checkpoint.json"
