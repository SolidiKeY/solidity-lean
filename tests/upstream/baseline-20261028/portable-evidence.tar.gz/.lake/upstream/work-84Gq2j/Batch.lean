import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-84Gq2j/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-84Gq2j/checkpoint.json"
