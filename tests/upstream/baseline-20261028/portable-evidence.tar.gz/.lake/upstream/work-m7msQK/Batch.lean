import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-m7msQK/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-m7msQK/checkpoint.json"
