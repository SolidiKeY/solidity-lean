import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-M40w3m/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-M40w3m/checkpoint.json"
