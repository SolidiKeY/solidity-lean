import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-fGPOGE/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-fGPOGE/checkpoint.json"
