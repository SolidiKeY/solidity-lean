import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-5zsddG/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-5zsddG/checkpoint.json"
