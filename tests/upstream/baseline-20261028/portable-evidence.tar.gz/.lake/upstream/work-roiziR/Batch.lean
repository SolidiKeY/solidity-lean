import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-roiziR/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-roiziR/checkpoint.json"
