import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-fChXHQ/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-fChXHQ/checkpoint.json"
