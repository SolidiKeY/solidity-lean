import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-5KcVzO/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-5KcVzO/checkpoint.json"
