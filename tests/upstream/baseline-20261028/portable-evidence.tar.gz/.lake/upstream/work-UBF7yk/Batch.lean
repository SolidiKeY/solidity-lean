import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-UBF7yk/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-UBF7yk/checkpoint.json"
