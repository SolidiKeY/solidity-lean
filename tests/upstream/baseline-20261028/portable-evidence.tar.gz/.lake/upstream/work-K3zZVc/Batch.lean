import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-K3zZVc/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-K3zZVc/checkpoint.json"
