import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-WWH2l4/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-WWH2l4/checkpoint.json"
