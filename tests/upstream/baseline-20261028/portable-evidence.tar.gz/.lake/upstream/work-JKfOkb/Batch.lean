import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-JKfOkb/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-JKfOkb/checkpoint.json"
