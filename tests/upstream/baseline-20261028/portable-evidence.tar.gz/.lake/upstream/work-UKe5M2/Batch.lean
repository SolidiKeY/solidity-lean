import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-UKe5M2/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-UKe5M2/checkpoint.json"
