import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-mZUI7o/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-mZUI7o/checkpoint.json"
