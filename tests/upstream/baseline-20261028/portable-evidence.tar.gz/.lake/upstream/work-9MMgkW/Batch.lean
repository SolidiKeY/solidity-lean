import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-9MMgkW/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-9MMgkW/checkpoint.json"
