import Solidity.Tools.Upstream
#upstream_batch "/workspace/solidity-lean/.lake/upstream/work-2hSs80/batch.json" to "/workspace/solidity-lean/.lake/upstream/work-2hSs80/checkpoint.json"
