// Lean compiler output
// Module: Solidity.Semantics.Lifetime
// Imports: Init Solidity.Semantics.Deploy
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Solidity_Semantics_setBy___at___Solidity_State_pay_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_ofState(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_ofState___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_System_ctorIdx(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_atTime(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_PrimTy_ofInt_x3f_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_atTime___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_observe(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_TRes_ofOpt_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_TRes_ofOpt_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_System_ctorIdx___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_PrimTy_ofInt_x3f_match__1_splitter___redArg(uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_nat_to_int(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_ofState___redArg(lean_object*, lean_object*);
static lean_object* l_Solidity_Lifetime_System_run___redArg___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lifetime_System_run___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorIdx___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_wait_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorIdx(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_enter(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_call_elim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Except_map_match__1_splitter___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_TRes_ofOpt_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorElim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_call_elim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorElim___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorIdx___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_TRes_ofOpt_match__1_splitter___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Solidity_Prog_runC___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Solidity_Storage_resetTransient(lean_object*, lean_object*);
static lean_object* l_Solidity_Lifetime_World_enter___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_wait_elim(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_System_run(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Solidity_PrimTy_ofInt_x3f(uint8_t, lean_object*);
lean_object* l_Solidity_PrimTy_dflt(uint8_t);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_ctorIdx___boxed(lean_object*, lean_object*);
lean_object* l_Solidity_TRes_ofOpt___redArg(lean_object*);
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_PrimTy_ofInt_x3f_match__1_splitter___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_atTime___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorElim___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Solidity_Lifetime_World_observe___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorIdx___redArg(lean_object*);
lean_object* lean_int_add(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_PrimTy_ofInt_x3f_match__1_splitter(lean_object*, uint8_t, lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t lean_int_dec_eq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Except_map_match__1_splitter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Solidity_Semantics_lookupBy___at___Solidity_State_pay_spec__1___redArg(lean_object*, lean_object*);
static lean_object* l_Solidity_Lifetime_World_enter___closed__1;
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_ctorIdx(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_ctorIdx(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = lean_unsigned_to_nat(0u);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_ctorIdx___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lifetime_World_ctorIdx(x_1, x_2);
lean_dec_ref(x_2);
lean_dec_ref(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_ofState___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; uint8_t x_7; 
x_3 = lean_ctor_get(x_2, 6);
lean_inc_ref(x_3);
x_4 = lean_ctor_get(x_2, 0);
lean_inc(x_4);
x_5 = lean_ctor_get(x_2, 4);
lean_inc(x_5);
x_6 = lean_ctor_get(x_2, 5);
lean_inc(x_6);
lean_dec_ref(x_2);
x_7 = !lean_is_exclusive(x_3);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_8 = lean_ctor_get(x_3, 1);
x_9 = lean_ctor_get(x_3, 3);
x_10 = lean_ctor_get(x_3, 4);
lean_dec(x_10);
x_11 = lean_ctor_get(x_3, 2);
lean_dec(x_11);
x_12 = lean_ctor_get(x_3, 0);
lean_dec(x_12);
x_13 = l_Solidity_Storage_resetTransient(x_1, x_4);
lean_ctor_set(x_3, 4, x_9);
lean_ctor_set(x_3, 3, x_8);
lean_ctor_set(x_3, 2, x_6);
lean_ctor_set(x_3, 1, x_5);
lean_ctor_set(x_3, 0, x_13);
return x_3;
}
else
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_14 = lean_ctor_get(x_3, 1);
x_15 = lean_ctor_get(x_3, 3);
lean_inc(x_15);
lean_inc(x_14);
lean_dec(x_3);
x_16 = l_Solidity_Storage_resetTransient(x_1, x_4);
x_17 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_5);
lean_ctor_set(x_17, 2, x_6);
lean_ctor_set(x_17, 3, x_14);
lean_ctor_set(x_17, 4, x_15);
return x_17;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_ofState(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Solidity_Lifetime_World_ofState___redArg(x_1, x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_ofState___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Solidity_Lifetime_World_ofState(x_1, x_2, x_3);
lean_dec(x_2);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lifetime_World_observe___closed__0() {
_start:
{
uint8_t x_1; lean_object* x_2; 
x_1 = 1;
x_2 = l_Solidity_PrimTy_dflt(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_observe(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_4 = lean_ctor_get(x_2, 0);
x_5 = lean_ctor_get(x_2, 1);
x_6 = lean_ctor_get(x_2, 2);
x_7 = lean_ctor_get(x_2, 3);
x_8 = lean_ctor_get(x_2, 4);
x_9 = l_Solidity_Storage_resetTransient(x_1, x_4);
x_10 = lean_box(0);
x_11 = lean_box(0);
x_12 = l_Solidity_Lifetime_World_observe___closed__0;
lean_ctor_set(x_2, 4, x_10);
lean_ctor_set(x_2, 3, x_8);
lean_ctor_set(x_2, 2, x_12);
lean_ctor_set(x_2, 1, x_7);
lean_ctor_set(x_2, 0, x_12);
x_13 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_13, 0, x_9);
lean_ctor_set(x_13, 1, x_10);
lean_ctor_set(x_13, 2, x_11);
lean_ctor_set(x_13, 3, x_11);
lean_ctor_set(x_13, 4, x_5);
lean_ctor_set(x_13, 5, x_6);
lean_ctor_set(x_13, 6, x_2);
return x_13;
}
else
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_14 = lean_ctor_get(x_2, 0);
x_15 = lean_ctor_get(x_2, 1);
x_16 = lean_ctor_get(x_2, 2);
x_17 = lean_ctor_get(x_2, 3);
x_18 = lean_ctor_get(x_2, 4);
lean_inc(x_18);
lean_inc(x_17);
lean_inc(x_16);
lean_inc(x_15);
lean_inc(x_14);
lean_dec(x_2);
x_19 = l_Solidity_Storage_resetTransient(x_1, x_14);
x_20 = lean_box(0);
x_21 = lean_box(0);
x_22 = l_Solidity_Lifetime_World_observe___closed__0;
x_23 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_17);
lean_ctor_set(x_23, 2, x_22);
lean_ctor_set(x_23, 3, x_18);
lean_ctor_set(x_23, 4, x_20);
x_24 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_24, 0, x_19);
lean_ctor_set(x_24, 1, x_20);
lean_ctor_set(x_24, 2, x_21);
lean_ctor_set(x_24, 3, x_21);
lean_ctor_set(x_24, 4, x_15);
lean_ctor_set(x_24, 5, x_16);
lean_ctor_set(x_24, 6, x_23);
return x_24;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_atTime___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_1);
if (x_3 == 0)
{
lean_object* x_4; 
x_4 = lean_ctor_get(x_1, 4);
lean_dec(x_4);
lean_ctor_set(x_1, 4, x_2);
return x_1;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_5 = lean_ctor_get(x_1, 0);
x_6 = lean_ctor_get(x_1, 1);
x_7 = lean_ctor_get(x_1, 2);
x_8 = lean_ctor_get(x_1, 3);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_dec(x_1);
x_9 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_9, 0, x_5);
lean_ctor_set(x_9, 1, x_6);
lean_ctor_set(x_9, 2, x_7);
lean_ctor_set(x_9, 3, x_8);
lean_ctor_set(x_9, 4, x_2);
return x_9;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_atTime(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Solidity_Lifetime_World_atTime___redArg(x_2, x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_atTime___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Solidity_Lifetime_World_atTime(x_1, x_2, x_3);
lean_dec_ref(x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lifetime_World_enter___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lifetime_World_enter___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_World_enter(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; uint8_t x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_4 = lean_ctor_get(x_2, 0);
lean_inc(x_4);
x_5 = lean_ctor_get(x_2, 1);
lean_inc(x_5);
x_6 = lean_ctor_get(x_2, 2);
lean_inc(x_6);
lean_dec_ref(x_2);
x_7 = lean_ctor_get(x_3, 0);
x_8 = lean_ctor_get(x_3, 2);
x_9 = 1;
x_10 = lean_int_add(x_6, x_8);
lean_dec(x_6);
x_11 = l_Solidity_PrimTy_ofInt_x3f(x_9, x_10);
x_12 = l_Solidity_TRes_ofOpt___redArg(x_11);
if (lean_obj_tag(x_12) == 0)
{
lean_object* x_13; 
lean_dec_ref(x_12);
lean_dec(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_1);
x_13 = l_Solidity_Lifetime_World_enter___closed__0;
return x_13;
}
else
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_23; lean_object* x_27; uint8_t x_28; 
x_14 = lean_ctor_get(x_12, 0);
lean_inc(x_14);
if (lean_is_exclusive(x_12)) {
 lean_ctor_release(x_12, 0);
 x_15 = x_12;
} else {
 lean_dec_ref(x_12);
 x_15 = lean_box(0);
}
x_16 = l_Solidity_Storage_resetTransient(x_1, x_4);
x_17 = lean_box(0);
x_18 = lean_box(0);
x_27 = l_Solidity_Lifetime_World_enter___closed__1;
x_28 = lean_int_dec_eq(x_8, x_27);
if (x_28 == 0)
{
lean_object* x_29; 
x_29 = l_Solidity_Semantics_lookupBy___at___Solidity_State_pay_spec__1___redArg(x_7, x_5);
if (lean_obj_tag(x_29) == 0)
{
x_23 = x_27;
goto block_26;
}
else
{
lean_object* x_30; 
x_30 = lean_ctor_get(x_29, 0);
lean_inc(x_30);
lean_dec_ref(x_29);
x_23 = x_30;
goto block_26;
}
}
else
{
x_19 = x_5;
goto block_22;
}
block_22:
{
lean_object* x_20; lean_object* x_21; 
x_20 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_20, 0, x_16);
lean_ctor_set(x_20, 1, x_17);
lean_ctor_set(x_20, 2, x_18);
lean_ctor_set(x_20, 3, x_18);
lean_ctor_set(x_20, 4, x_19);
lean_ctor_set(x_20, 5, x_14);
lean_ctor_set(x_20, 6, x_3);
if (lean_is_scalar(x_15)) {
 x_21 = lean_alloc_ctor(1, 1, 0);
} else {
 x_21 = x_15;
}
lean_ctor_set(x_21, 0, x_20);
return x_21;
}
block_26:
{
lean_object* x_24; lean_object* x_25; 
x_24 = lean_int_add(x_23, x_8);
lean_dec(x_23);
lean_inc(x_7);
x_25 = l_Solidity_Semantics_setBy___at___Solidity_State_pay_spec__0___redArg(x_7, x_24, x_5);
x_19 = x_25;
goto block_22;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_TRes_ofOpt_match__1_splitter___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_dec(x_2);
lean_inc(x_3);
return x_3;
}
else
{
lean_object* x_4; lean_object* x_5; 
x_4 = lean_ctor_get(x_1, 0);
lean_inc(x_4);
lean_dec_ref(x_1);
x_5 = lean_apply_1(x_2, x_4);
return x_5;
}
}
}
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_TRes_ofOpt_match__1_splitter(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l___private_Solidity_Semantics_Lifetime_0__Solidity_TRes_ofOpt_match__1_splitter___redArg(x_3, x_4, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_TRes_ofOpt_match__1_splitter___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l___private_Solidity_Semantics_Lifetime_0__Solidity_TRes_ofOpt_match__1_splitter___redArg(x_1, x_2, x_3);
lean_dec(x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_TRes_ofOpt_match__1_splitter___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l___private_Solidity_Semantics_Lifetime_0__Solidity_TRes_ofOpt_match__1_splitter(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_PrimTy_ofInt_x3f_match__1_splitter___redArg(uint8_t x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
switch (x_1) {
case 0:
{
lean_object* x_6; 
lean_dec(x_4);
lean_dec(x_3);
x_6 = lean_apply_1(x_5, x_2);
return x_6;
}
case 1:
{
lean_object* x_7; 
lean_dec(x_5);
lean_dec(x_4);
x_7 = lean_apply_1(x_3, x_2);
return x_7;
}
default: 
{
lean_object* x_8; 
lean_dec(x_5);
lean_dec(x_3);
x_8 = lean_apply_1(x_4, x_2);
return x_8;
}
}
}
}
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_PrimTy_ofInt_x3f_match__1_splitter(lean_object* x_1, uint8_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l___private_Solidity_Semantics_Lifetime_0__Solidity_PrimTy_ofInt_x3f_match__1_splitter___redArg(x_2, x_3, x_4, x_5, x_6);
return x_7;
}
}
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_PrimTy_ofInt_x3f_match__1_splitter___redArg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; lean_object* x_7; 
x_6 = lean_unbox(x_1);
x_7 = l___private_Solidity_Semantics_Lifetime_0__Solidity_PrimTy_ofInt_x3f_match__1_splitter___redArg(x_6, x_2, x_3, x_4, x_5);
return x_7;
}
}
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Solidity_PrimTy_ofInt_x3f_match__1_splitter___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
uint8_t x_7; lean_object* x_8; 
x_7 = lean_unbox(x_2);
x_8 = l___private_Solidity_Semantics_Lifetime_0__Solidity_PrimTy_ofInt_x3f_match__1_splitter(x_1, x_7, x_3, x_4, x_5, x_6);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_System_ctorIdx(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = lean_unsigned_to_nat(0u);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_System_ctorIdx___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Solidity_Lifetime_System_ctorIdx(x_1, x_2, x_3, x_4);
lean_dec_ref(x_4);
lean_dec_ref(x_1);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lifetime_System_run___redArg___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_System_run___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; lean_object* x_24; uint8_t x_25; 
x_6 = lean_ctor_get(x_2, 1);
lean_inc_ref(x_6);
x_7 = lean_ctor_get(x_2, 2);
lean_inc_ref(x_7);
lean_dec_ref(x_2);
lean_inc(x_4);
x_24 = lean_apply_1(x_7, x_4);
x_25 = lean_unbox(x_24);
if (x_25 == 0)
{
lean_object* x_26; lean_object* x_27; uint8_t x_28; 
x_26 = lean_ctor_get(x_5, 2);
x_27 = l_Solidity_Lifetime_World_enter___closed__1;
x_28 = lean_int_dec_eq(x_26, x_27);
if (x_28 == 0)
{
lean_object* x_29; 
lean_dec_ref(x_6);
lean_dec_ref(x_5);
lean_dec(x_4);
lean_dec_ref(x_3);
lean_dec_ref(x_1);
x_29 = l_Solidity_Lifetime_System_run___redArg___closed__0;
return x_29;
}
else
{
goto block_23;
}
}
else
{
goto block_23;
}
block_23:
{
lean_object* x_8; 
lean_inc_ref(x_1);
x_8 = l_Solidity_Lifetime_World_enter(x_1, x_3, x_5);
if (lean_obj_tag(x_8) == 0)
{
lean_object* x_9; 
lean_dec_ref(x_8);
lean_dec_ref(x_6);
lean_dec(x_4);
lean_dec_ref(x_1);
x_9 = l_Solidity_Lifetime_System_run___redArg___closed__0;
return x_9;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_10 = lean_ctor_get(x_8, 0);
lean_inc(x_10);
lean_dec_ref(x_8);
x_11 = lean_box(0);
x_12 = lean_apply_1(x_6, x_4);
lean_inc_ref(x_1);
x_13 = l_Solidity_Prog_runC___redArg(x_1, x_11, x_12, x_10);
if (lean_obj_tag(x_13) == 0)
{
uint8_t x_14; 
lean_dec_ref(x_1);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
return x_13;
}
else
{
lean_object* x_15; lean_object* x_16; 
x_15 = lean_ctor_get(x_13, 0);
lean_inc(x_15);
lean_dec(x_13);
x_16 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_16, 0, x_15);
return x_16;
}
}
else
{
uint8_t x_17; 
x_17 = !lean_is_exclusive(x_13);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; 
x_18 = lean_ctor_get(x_13, 0);
x_19 = l_Solidity_Lifetime_World_ofState___redArg(x_1, x_18);
lean_ctor_set(x_13, 0, x_19);
return x_13;
}
else
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_20 = lean_ctor_get(x_13, 0);
lean_inc(x_20);
lean_dec(x_13);
x_21 = l_Solidity_Lifetime_World_ofState___redArg(x_1, x_20);
x_22 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_22, 0, x_21);
return x_22;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_System_run(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Solidity_Lifetime_System_run___redArg(x_1, x_4, x_5, x_6, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Except_map_match__1_splitter___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_4; lean_object* x_5; 
lean_dec(x_3);
x_4 = lean_ctor_get(x_1, 0);
lean_inc(x_4);
lean_dec_ref(x_1);
x_5 = lean_apply_1(x_2, x_4);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; 
lean_dec(x_2);
x_6 = lean_ctor_get(x_1, 0);
lean_inc(x_6);
lean_dec_ref(x_1);
x_7 = lean_apply_1(x_3, x_6);
return x_7;
}
}
}
LEAN_EXPORT lean_object* l___private_Solidity_Semantics_Lifetime_0__Except_map_match__1_splitter(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l___private_Solidity_Semantics_Lifetime_0__Except_map_match__1_splitter___redArg(x_4, x_5, x_6);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorIdx___redArg(lean_object* x_1) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
else
{
lean_object* x_3; 
x_3 = lean_unsigned_to_nat(1u);
return x_3;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorIdx(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lifetime_Event_ctorIdx___redArg(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorIdx___redArg___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lifetime_Event_ctorIdx___redArg(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorIdx___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lifetime_Event_ctorIdx(x_1, x_2);
lean_dec_ref(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorElim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_3 = lean_ctor_get(x_1, 0);
lean_inc(x_3);
x_4 = lean_ctor_get(x_1, 1);
lean_inc_ref(x_4);
lean_dec_ref(x_1);
x_5 = lean_apply_2(x_2, x_3, x_4);
return x_5;
}
else
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_ctor_get(x_1, 0);
lean_inc(x_6);
lean_dec_ref(x_1);
x_7 = lean_apply_1(x_2, x_6);
return x_7;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorElim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_Solidity_Lifetime_Event_ctorElim___redArg(x_4, x_6);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_ctorElim___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_Solidity_Lifetime_Event_ctorElim(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec(x_3);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_call_elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lifetime_Event_ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_call_elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Solidity_Lifetime_Event_ctorElim___redArg(x_3, x_5);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_wait_elim___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lifetime_Event_ctorElim___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lifetime_Event_wait_elim(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Solidity_Lifetime_Event_ctorElim___redArg(x_3, x_5);
return x_6;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Solidity_Semantics_Deploy(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Solidity_Semantics_Lifetime(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Solidity_Semantics_Deploy(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_Solidity_Lifetime_World_observe___closed__0 = _init_l_Solidity_Lifetime_World_observe___closed__0();
lean_mark_persistent(l_Solidity_Lifetime_World_observe___closed__0);
l_Solidity_Lifetime_World_enter___closed__0 = _init_l_Solidity_Lifetime_World_enter___closed__0();
lean_mark_persistent(l_Solidity_Lifetime_World_enter___closed__0);
l_Solidity_Lifetime_World_enter___closed__1 = _init_l_Solidity_Lifetime_World_enter___closed__1();
lean_mark_persistent(l_Solidity_Lifetime_World_enter___closed__1);
l_Solidity_Lifetime_System_run___redArg___closed__0 = _init_l_Solidity_Lifetime_System_run___redArg___closed__0();
lean_mark_persistent(l_Solidity_Lifetime_System_run___redArg___closed__0);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
