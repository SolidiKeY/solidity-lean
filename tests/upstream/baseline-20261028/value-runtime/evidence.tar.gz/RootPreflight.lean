import Solidity.Tools.Upstream
import Solidity.Semantics.Lifetime
#check Solidity.Lifetime.System.run
#print axioms Solidity.Lifetime.System.run_ok
#eval IO.println "LIFETIME_ROOT_NATIVE_IMPORT_PASS"
