from pathlib import Path
import json,hashlib,os,subprocess,time,resource
root=Path('/workspace/solidity-lean');out=root/'.lake/upstream/value-entry-runtime-20261028';before=json.load(open(out/'before.json'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(Path(p))==h for p,h in before['snapshots'].items())
a=json.load(open(out/'cache/audit.json'));overlay=out/'overlay'
for module in a['targetClosures']['Solidity.Tools.Upstream']:
 target=overlay/(module.replace('.','/')+'.olean');target.parent.mkdir(parents=True,exist_ok=True);target.symlink_to(root/'.lake/build/lib/lean'/(module.replace('.','/')+'.olean'))
refs={str(p.relative_to(out)):dict(resolved=str(p.resolve()),sha256=sha(p),symlink=p.is_symlink()) for p in overlay.rglob('*.olean')};assert len(refs)==77
(out/'overlay-imports.json').write_text(json.dumps(refs,indent=2)+'\n')
commands=[];env={**os.environ,'LEAN_NUM_THREADS':'1','LEAN_PATH':str(overlay)+':'+str(root/'.lake/build/lib/lean')}
for label,args in [('resolved-preflight-deps',['--deps']),('resolved-preflight',[])]:
 cmd=['timeout','-k','10','120','lean','-j1','--tstack=131072',*args,str(out/'RootPreflight.lean')];start=time.monotonic();r=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);p=out/'logs'/(label+'.log');p.write_bytes(r.stdout);commands.append(dict(command=cmd,exitCode=r.returncode,elapsedSeconds=time.monotonic()-start,log=str(p.relative_to(out)),sha256=sha(p),cgroupPeakBytes=int(Path('/sys/fs/cgroup/memory.peak').read_text())));print(label,r.returncode,flush=True)
 (out/'overlay-completion-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 assert r.returncode==0,r.stdout.decode()
assert all(sha(Path(p))==h for p,h in before['snapshots'].items())
(out/'after.json').write_text(json.dumps(dict(allSharedArtifactsUnchanged=True,checked=len(before['snapshots']),privateRootArtifacts={str(p.relative_to(out)):dict(sha256=sha(p),bytes=p.stat().st_size) for p in overlay.rglob('*') if p.is_file() and not p.is_symlink()},cgroupPeakBytes=int(Path('/sys/fs/cgroup/memory.peak').read_text()),memoryMaxBytes=int(Path('/sys/fs/cgroup/memory.max').read_text()),swapMaxBytes=int(Path('/sys/fs/cgroup/memory.swap.max').read_text()),memoryEvents=Path('/sys/fs/cgroup/memory.events').read_text()),indent=2)+'\n')
