import asyncio,json,os
from pathlib import Path
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
ROOT=Path.cwd()
async def main():
 env=os.environ.copy()
 env.update(LEAN_PROJECT_PATH=str(ROOT),LEAN_NUM_THREADS='1',LEAN_LSP_MAX_OPEN_FILES='1',LEAN_MCP_PREWARM_FILES='',LEAN_REPL='false')
 env['LAKE_CACHE_DIR']=str(ROOT/'.lake/cloudvm-cache')
 env['PATH']=str(ROOT/'.lake/integration-repair/bin')+':'+env['PATH']
 params=StdioServerParameters(command=str(ROOT/'.venv/bin/python'),args=['-m','lean_lsp_mcp','--lean-project-path',str(ROOT)],env=env)
 async with stdio_client(params) as (read,write):
  async with ClientSession(read,write) as session:
   await session.initialize()
   for name in ['Solidity/Calculus/PaymentWitness.lean', 'Solidity/Calculus/PaymentConditions.lean', 'Solidity/Calculus/CallbackSound/Payments.lean', 'Solidity/Calculus/PaymentClose.lean', 'Solidity/Examples/Tactics/PaymentWitness.lean', 'Solidity/Examples/Tactics/PaymentRules.lean', 'Solidity/Examples/Tactics/PaymentSource.lean']:
    avail=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
    if avail<12*1024**3: raise RuntimeError('OS reserve below 12 GiB')
    print('Checking '+name,flush=True)
    for attempt in range(1, 21):
     avail=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
     if avail<12*1024**3: raise RuntimeError('OS reserve below 12 GiB')
     result=await asyncio.wait_for(session.call_tool('lean_diagnostic_messages',{'file_path':str(ROOT/name),'interactive':False,'timeout_s':45}),timeout=90)
     data=result.model_dump(mode='json')
     (ROOT/'.lake/integration-repair'/('payment-types-'+name.replace('/','__')+'-'+str(attempt)+'.json')).write_text(json.dumps(data,indent=2))
     print(json.dumps(data),flush=True)
     value=data.get('structuredContent',{}).get('result',{})
     if not value.get('partial',False):
      if not value.get('success',False): raise RuntimeError('Lean diagnostics failed')
      break
    else: raise RuntimeError('Lean diagnostics remain partial')
asyncio.run(main())
