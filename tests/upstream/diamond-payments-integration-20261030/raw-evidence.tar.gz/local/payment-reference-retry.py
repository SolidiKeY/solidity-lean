import json, os, signal, subprocess, time
from pathlib import Path

root = Path.cwd()
out = root / '.lake/integration-repair/payment-reference-retry'
out.mkdir(exist_ok=True)
env = os.environ.copy()
env.update(SOLKEY_ROOT='/home/guilherme/projects/solkey',
           SOLC_REFERENCE=str(root / '.lake/integration-repair/soljson-v0.8.38.js'),
           LEAN_NUM_THREADS='1',
           LAKE_CACHE_DIR=str(root / '.lake/cloudvm-cache'),
           TMPDIR=str(root / '.lake/integration-repair/tmp'))
env['PATH'] = str(root / '.lake/integration-repair/payment-regression-bin') + ':' + env['PATH']
cg = Path('/sys/fs/cgroup') / Path('/proc/self/cgroup').read_text().strip().split('::')[1].lstrip('/')

def snapshot():
    available = int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines()
                         if x.startswith('MemAvailable:'))) * 1024
    return {'monotonic': time.monotonic(), 'os_available_bytes': available,
            **{k: (cg / k).read_text().strip() for k in
               ['memory.current', 'memory.peak', 'memory.max', 'memory.swap.max', 'memory.events']}}

commands = [['node', '--test', 'scripts/payment-reference.test.mjs']]
results = []
for i, command in enumerate(commands):
    before = snapshot()
    assert before['memory.max'] == str(12 * 1024**3)
    assert before['memory.swap.max'] == '0'
    assert before['os_available_bytes'] >= 12 * 1024**3
    samples = [before]
    print('RUN', command, flush=True)
    with (out / f'{i}.stdout.log').open('w') as stdout, (out / f'{i}.stderr.log').open('w') as stderr:
        p = subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        stopped = None
        while p.poll() is None:
            s = snapshot()
            samples.append(s)
            if s['os_available_bytes'] < 12 * 1024**3 or s['monotonic'] - before['monotonic'] > 600:
                stopped = 'OS reserve below 12 GiB' if s['os_available_bytes'] < 12 * 1024**3 else 'repair runner timeout'
                os.killpg(p.pid, signal.SIGTERM)
                try: p.wait(timeout=5)
                except subprocess.TimeoutExpired: os.killpg(p.pid, signal.SIGKILL); p.wait()
                break
            time.sleep(0.5)
    samples.append(snapshot())
    (out / f'{i}.resources.json').write_text(json.dumps(samples, indent=2) + '\n')
    result = {'command': command, 'exit': p.returncode, 'stopped': stopped,
              'seconds': samples[-1]['monotonic'] - before['monotonic']}
    results.append(result)
    (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(result), flush=True)
