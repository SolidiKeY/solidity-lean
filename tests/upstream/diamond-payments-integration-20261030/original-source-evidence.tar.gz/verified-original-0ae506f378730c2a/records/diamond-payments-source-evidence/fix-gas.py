from pathlib import Path
p=Path('/workspace/solidity-lean/scripts/payment-source.mjs');s=p.read_text().replace('originalOrderedObservations:ordered,independentGasObservations:gas','originalSourceSha256:api.fixtureSha256,originalOrderedObservations:ordered,independentGasObservations:gas');s+='''
/** Whole-fixture verdict: functional Lean evidence never discharges gas. */
export function certifyPaymentGas(row,job,report,provenance) {
  if(!job.independentGasObservations?.length)return row;
  const base={...row,typedSourceStatus:row.status,gasEvidence:report??null};
  if(row.status!=='working')return base;
  if(!report)return {...base,status:'blocked',reason:'typed payment observations passed; independent gas evidence unavailable'};
  const m=report.metadata,r=report.result;
  if(!m||!r||Object.entries(provenance).some(([k,v])=>m[k]!==v)||r.path!==job.path||r.sourceSha256!==job.originalSourceSha256)
    return {...base,status:'blocked',reason:'payment gas provenance mismatch'};
  if(JSON.stringify(r.expectedObservations)!==JSON.stringify(job.originalOrderedObservations.map(x=>x.original)))
    return {...base,status:'broken',reason:'ordered source/gas expectations disagree with independent replay'};
  const actual=r.variants?.flatMap(v=>v.gasObserved??[])??[];
  const expected=job.independentGasObservations.map(x=>x.original);
  if(r.status==='broken'||actual.some(x=>!x.matches||x.actual!==x.expected))
    return {...base,status:'broken',reason:'independent frozen payment gas mismatch'};
  if(r.status!=='working'||!job.requiredPipelines.every(p=>r.variants?.some(v=>v.profile===p&&v.status==='working'))||
     actual.length!==expected.length||!expected.every(x=>actual.some(g=>g.original===x&&g.matches)))
    return {...base,status:'blocked',reason:'incomplete independent payment gas observations'};
  return {...base,status:'working',reason:'typed ordered payment source observations and all independent frozen gas observations match'};
}
''';p.write_text(s)
p=Path('/workspace/solidity-lean/scripts/solidity-upstream.mjs');s=p.read_text().replace("import {preparePaymentSource} from './payment-source.mjs';", "import {preparePaymentSource,certifyPaymentGas} from './payment-source.mjs';");s=s.replace('COMPILER_SHA,VERSION});','COMPILER_SHA,VERSION,fixtureSha256:sha(bytes)});');s=s.replace("compilerCodeAdapterSha256:sha(readFileSync(join(ROOT,'scripts/solc-code.mjs'))),", "compilerCodeAdapterSha256:sha(readFileSync(join(ROOT,'scripts/solc-code.mjs'))),\n    paymentSourceAdapterSha256:sha(readFileSync(join(ROOT,'scripts/payment-source.mjs'))),\n    paymentReferenceSha256:sha(readFileSync(join(ROOT,'scripts/evm-reference/payment-replay.mjs'))),\n    paymentReferenceEngineSha256:sha(readFileSync(join(ROOT,'scripts/evm-reference/replay.mjs'))),\n    paymentReferenceLockSha256:sha(readFileSync(join(ROOT,'scripts/evm-reference/package-lock.json'))),")
s=s.replace("  runTool('lake',['build','Solidity.Tools.Upstream'],Math.max(options.timeoutMs,300000));\n",'');needle='  for (let first=0;first<jobs.length;first+=options.batchSize) {';s=s.replace(needle,"  runTool('lake',['build',jobs.some(j=>j.paymentSource)?'Solidity.Tools.PaymentReplay':'Solidity.Tools.Upstream'],Math.max(options.timeoutMs,300000));\n"+needle)
needle="  const summary=writeReports(output,metadata,results,files.length,manifest.files);\n";pos=s.rindex(needle);s=s[:pos]+'''  for(const job of jobs.filter((j,i,a)=>j.paymentSource&&j.independentGasObservations?.length&&a.findIndex(x=>x.path===j.path)===i)) {
    const reportPath=join(work,'payment-gas-'+sha(job.path).slice(0,16)+'.json');let report;
    try {runTool('node',['scripts/evm-reference/payment-replay.mjs','--compiler',options.compiler,'--filter',job.path,'--out',reportPath],options.timeoutMs);}
    catch(e) { /* A report may retain a real mismatch; absent evidence stays blocked. */ }
    if(existsSync(reportPath))report=json(reportPath);
    const provenance={commit:PIN,compilerSha256:COMPILER_SHA,archiveSha256:manifest.archiveSha256,
      runnerSha256:metadata.paymentReferenceSha256,adapterSha256:metadata.runnerSha256,
      baseEngineSha256:metadata.paymentReferenceEngineSha256,dependencyLockSha256:metadata.paymentReferenceLockSha256};
    results.set(job.path,certifyPaymentGas(results.get(job.path),job,report,provenance));
  }
'''+s[pos:];s=s.replace("Generated EVM/SSA, gas, logs and the native C++ harness are not tested.","No Lean gas or compiler-equivalence claim. Payment gas obligations require a separate provenance-matched bytecode report; other generated EVM/SSA, logs and native C++ harness are not tested.")
p.write_text(s)
