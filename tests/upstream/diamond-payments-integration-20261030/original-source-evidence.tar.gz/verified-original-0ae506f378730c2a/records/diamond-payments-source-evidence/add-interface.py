from pathlib import Path
p=Path('/workspace/solidity-lean/Solidity/Frontend/PaymentImport.lean');s=p.read_text();pos=s.index('syntax (name := paymentSource)');s=s[:pos]+'''/-- The checked source wrapper's typed replay interface. All states and handles
remain indexed by the imported code catalog; JSON observations are outside it. -/
structure Interface {K : Type} (contracts : K → Contract) (owner recipient : K) where
  deploy : World contracts → Address → Address → Context →
    TRes (World contracts × (Handle owner × Option (Handle recipient)))
  invoke : World contracts → Handle owner → Option (Handle recipient) → Context → Address →
    String → TRes (World contracts × List String)

'''+s[pos:]
pos=s.index('  -- The retained source plan')
s=s[:pos]+'''  if plan.root.isNone then
    command s!"def {n}.invoke (w : Solidity.ContractWorld.World {n}.contracts) (self : Solidity.ContractWorld.Handle {n}.Code.owner) (_recipient : Option (Solidity.ContractWorld.Handle {n}.Code.recipient)) (ctx : Solidity.ContractWorld.Context) (fresh : Solidity.ContractWorld.Address) (signature : String) : Solidity.TRes (Solidity.ContractWorld.World {n}.contracts × List String) := do\\n if signature != {toJson (plan.sendName ++ "()") |>.compress} then .error .exhausted else do\\n let (next, result) ← {n}.send w self ctx fresh\\n pure (next, [if result then \\"1\\" else \\"0\\"])"
  else
    let mut branches := ""
    for method in plan.methods do
      branches := branches ++ s!"if signature == {toJson (method.name ++ "()") |>.compress} then do\\n let target ← Solidity.TRes.ofOpt recipient\\n let (next, _) ← {n}.transfer w self target ctx ⟨{method.amount}, by decide +kernel⟩\\n pure (next, [])\\n else "
    let some (getter, _) := plan.getter | throwError "missing payment getter"
    branches := branches ++ s!"if signature == {toJson (getter ++ "()") |>.compress} then do\\n let (next, value) ← w.call self {n}.getterEntry ctx\\n pure (next, [toString value.1])\\n else if signature == \\"()\\" then do\\n let (next, _) ← w.call self {n}.ownerReceiveEntry ctx\\n pure (next, [])\\n else .error .exhausted"
    command s!"def {n}.invoke (w : Solidity.ContractWorld.World {n}.contracts) (self : Solidity.ContractWorld.Handle {n}.Code.owner) (recipient : Option (Solidity.ContractWorld.Handle {n}.Code.recipient)) (ctx : Solidity.ContractWorld.Context) (_fresh : Solidity.ContractWorld.Address) (signature : String) : Solidity.TRes (Solidity.ContractWorld.World {n}.contracts × List String) := do\\n {branches}"
  command s!"def {n}.interface : Solidity.Frontend.PaymentSource.Interface {n}.contracts {n}.Code.owner {n}.Code.recipient := ⟨{n}.deploy, {n}.invoke⟩"
'''+s[pos:]
p.write_text(s)
