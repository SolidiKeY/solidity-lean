import Solidity.Frontend.PaymentImport

/-! # Original payment source compositions, executed in the typed world
These are the original pinned source declarations. Runtime gas is independent
bytecode evidence. Every receive below is the imported declaration's body. -/
namespace Solidity.Examples.Tactics.PaymentSource
open Solidity.ContractWorld

solc_payment_source "/workspace/solidity-lean/tests/payment-source/Send.ast.json" hash 0x7b794eeca2e6495e as Send
solc_payment_source "/workspace/solidity-lean/tests/payment-source/Transfer.ast.json" hash 0x02b50c62d6e3412d as Transfer

private def amount (n : Nat) : Word := PrimTy.ofIntD .uint n
private def alice : Address := ⟨⟨100, by decide +kernel⟩, by decide +kernel⟩
private def owner : Address := ⟨⟨200, by decide +kernel⟩, by decide +kernel⟩
private def child : Address := ⟨⟨300, by decide +kernel⟩, by decide +kernel⟩
private def other : Address := ⟨⟨400, by decide +kernel⟩, by decide +kernel⟩
private def funding (a : Address) : Word := if a = alice then amount 1000 else amount 0

private structure SendSnapshot where
  sender : Int
  owner : Int
  child : Int
  installed : Bool
  result : Bool
  deriving DecidableEq

private def sendSnapshot : Option SendSnapshot := (do
  let (created, (self, _)) ← Send.deploy (World.empty Send.contracts funding) owner child
    {sender := alice, mode := .ordinary (amount 20)}
  let (next, result) ← Send.send created self {sender := alice} child
  pure (next, SendSnapshot.mk (next.balance alice).1 (next.balance owner).1
    (next.balance child).1 (next.accounts child).isSome result)).toOption.map Prod.snd

/-- Original constructor20wei; new Receiver; its actual receive; s()true. -/
theorem original_send : sendSnapshot = some ⟨980, 20, 0, true, true⟩ := by decide +kernel

private def initialized : TRes (World Transfer.contracts ×
    (Handle Transfer.Code.owner × Option (Handle Transfer.Code.recipient))) :=
  Transfer.deploy (World.empty Transfer.contracts funding) owner child {sender := alice}

private structure TransferSnapshot where
  beforeBalance : Int
  afterBalance : Int
  fundedBytes : List UInt8
  unfundedBytes : List UInt8
  installed : Bool
  deriving DecidableEq

private def initWorld : World Transfer.contracts :=
  match initialized with | .ok (w, _) => w | .error _ => World.empty Transfer.contracts funding
private def selfRef : Handle Transfer.Code.owner := ⟨owner⟩
private def childRef : Handle Transfer.Code.recipient := ⟨child⟩

/-- The actual deployment supplies exactly these references. -/
private theorem initialize_run : initialized = .ok (initWorld, (selfRef, some childRef)) := by rfl

private def fundingRun := initWorld.call selfRef Transfer.ownerReceiveEntry
  {sender := alice, mode := .ordinary (amount 10)}
private def fundedWorld : World Transfer.contracts :=
  match fundingRun with | .ok (w, _) => w | .error _ => initWorld
private theorem funding_empty : fundingRun = initWorld.call selfRef (Entry.unit .nil true)
    {sender := alice, mode := .ordinary (amount 10)} := by
  exact World.call_unit_noop initWorld selfRef Transfer.ownerReceiveBody true _ rfl Transfer.owner_receive_run
set_option diagnostics true in
private theorem funding_run : fundingRun = .ok (fundedWorld, ()) := by
  unfold fundedWorld
  rw [funding_empty]
  rfl


end Solidity.Examples.Tactics.PaymentSource
