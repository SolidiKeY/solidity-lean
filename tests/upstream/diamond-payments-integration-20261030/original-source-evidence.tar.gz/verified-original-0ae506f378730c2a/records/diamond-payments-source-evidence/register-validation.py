from pathlib import Path
import json
r=Path('/workspace/solidity-lean')
p=r/'Solidity/Tools/PaymentReplay.lean';s=p.read_text();
for actor in ['sender','ownerAddress','recipientAddress']:s=s.replace(f'toJson (committed.balance {actor}).1',f'toJson (toString (committed.balance {actor}).1)')
p.write_text(s)
p=r/'scripts/payment-source.test.mjs';s=p.read_text().replace('worldAfter.ownerBalance,20','worldAfter.ownerBalance,\'20\'');p.write_text(s)
p=r/'TrustAudit.lean';s=p.read_text();s='import Solidity.Examples.Tactics.PaymentSource\n'+s;s=s.replace('``Solidity.Examples.Tactics.FilteredSets.theory_guard_correct]', '''``Solidity.Examples.Tactics.FilteredSets.theory_guard_correct,
    ``Solidity.ContractWorld.World.receiveRun_ok,
    ``Solidity.ContractWorld.World.stipend_transfer_failure,
    ``Solidity.ContractWorld.World.receiveRun_unfunded,
    ``Solidity.ContractWorld.World.call_unit_noop,
    ``Solidity.ContractWorld.World.createSend_ok,
    ``Solidity.ContractWorld.World.stipend_send_true,
    ``Solidity.ContractWorld.sendResult_true_iff,
    ``Solidity.ContractWorld.sendResult_failure,
    ``Solidity.ContractWorld.sendResult_uncaught,
    ``Solidity.ContractWorld.payment_atomic_failure,
    ``Solidity.ContractWorld.World.paidRun_certificate,
    ``Solidity.Examples.Tactics.PaymentSource.original_send,
    ``Solidity.Examples.Tactics.PaymentSource.original_transfer,
    ``Solidity.Examples.Tactics.PaymentSource.wrong_handle,
    ``Solidity.Examples.Tactics.PaymentSource.wrong_kind,
    ``Solidity.Examples.Tactics.PaymentSource.wrong_bytes]''');p.write_text(s)
p=r/'tests/trust-inventory.json';d=json.loads(p.read_text())
for f in ['Solidity/Frontend/PaymentImport.lean','Solidity/Tools/PaymentReplay.lean']:
 for line in (r/f).read_text().splitlines():
  if 'unsafe eval' in line:
   row={'file':f,'kind':'unsafe','code':line.strip()}
   if row not in d:d.append(row)
p.write_text(json.dumps(d,indent=2)+'\n')
p=r/'docs/solidity-features.json';d=json.loads(p.read_text());rows=d['features'] if isinstance(d,dict) else d
for feature in rows:
 if feature['id']=='sendTransfer':
  for f in ['Solidity/Semantics/PaymentWorld.lean','Solidity/Frontend/PaymentPlan.lean','Solidity/Frontend/PaymentImport.lean','Solidity/Tools/PaymentReplay.lean','Solidity/Examples/Tactics/PaymentSource.lean','scripts/payment-source.test.mjs']:
   if f not in feature['localEvidence']:feature['localEvidence'].append(f)
p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
