from pathlib import Path
Path('/workspace/solidity-lean/Solidity/Examples/Tactics/PaymentSource.lean').write_text('''import Solidity.Frontend.PaymentImport

/-! # Original payment source compositions, executed in the typed world
These are the original pinned source declarations. Runtime gas is independent
bytecode evidence. Every receive below is the imported declaration's body. -/
namespace Solidity.Examples.Tactics.PaymentSource
open Solidity.ContractWorld

solc_payment_source "../../../tests/payment-source/Send.ast.json" hash 0x618ef97ebcb4db61 as Send
solc_payment_source "../../../tests/payment-source/Transfer.ast.json" hash 0x3c508c29b45d4bae as Transfer

private def amount (n : Nat) : Word := PrimTy.ofIntD .uint n
private def address (n : Nat) : Address :=
  ⟨amount (n % 1000), by have h := Nat.mod_lt n (by decide : 0 < 1000); simp only [amount, PrimTy.ofIntD]; omega⟩
private def alice : Address := ⟨⟨100, by decide +kernel⟩, by decide +kernel⟩
private def owner : Address := ⟨⟨200, by decide +kernel⟩, by decide +kernel⟩
private def child : Address := ⟨⟨300, by decide +kernel⟩, by decide +kernel⟩
private def other : Address := ⟨⟨400, by decide +kernel⟩, by decide +kernel⟩
private def funding (a : Address) : Word := if a = alice then amount 1000 else amount 0

private structure SendSnapshot where
  sender : Int
  owner : Int
  child : Int
  installed : Bool
  result : Bool
  deriving DecidableEq

private def sendSnapshot : Option SendSnapshot := (do
  let (created, (self, _)) ← Send.deploy (World.empty Send.contracts funding) owner child
    {sender := alice, mode := .ordinary (amount 20)}
  let (next, result) ← Send.send created self {sender := alice} child
  pure (next, SendSnapshot.mk (next.balance alice).1 (next.balance owner).1
    (next.balance child).1 (next.accounts child).isSome result)).toOption.map Prod.snd

/-- Original constructor20wei; new Receiver; its actual receive; s()true. -/
theorem original_send : sendSnapshot = some ⟨980, 20, 0, true, true⟩ := by decide +kernel

private def initialized : TRes (World Transfer.contracts ×
    (Handle Transfer.Code.owner × Option (Handle Transfer.Code.recipient))) :=
  Transfer.deploy (World.empty Transfer.contracts funding) owner child {sender := alice}

private structure TransferSnapshot where
  beforeBalance : Int
  afterBalance : Int
  fundedBytes : List UInt8
  unfundedBytes : List UInt8
  installed : Bool
  deriving DecidableEq

private def transferSnapshot : Option TransferSnapshot := (do
  let (created, (self, reference)) ← initialized
  let recipient ← TRes.ofOpt reference
  let (funded, ()) ← created.call self Transfer.ownerReceiveEntry
    {sender := alice, mode := .ordinary (amount 10)}
  let (same, before) ← funded.call self Transfer.getterEntry {sender := alice}
  let (afterF, f) := atomic same (Transfer.transfer same self recipient {sender := alice} (amount 1))
  let (afterH, h) := atomic afterF (Transfer.transfer afterF self recipient {sender := alice} (amount (100*10^18)))
  let (final, after) ← afterH.call self Transfer.getterEntry {sender := alice}
  let .error fe := f | .error .exhausted
  let .error he := h | .error .exhausted
  pure (final, TransferSnapshot.mk before.1 after.1 fe.data he.data
    ((final.accounts child).isSome && (final.accounts owner).isSome))).toOption.map Prod.snd

/-- Original receive10wei; g()10; actual nested Error(no_receive); h()empty
failure; both transactions leave g()10 and both code identities installed. -/
theorem original_transfer : transferSnapshot = some ⟨10, 10,
    Semantics.encodeError ("no_receive".toUTF8.data.toList), [], true⟩ := by decide +kernel

/-- Recipient reason bytes are not erased or replaced by an expected value. -/
theorem wrong_bytes : (transferSnapshot.map (·.fundedBytes)) ≠ some [] := by decide +kernel

/-- The stored initializer address is checked against the actual handle. -/
theorem wrong_handle : (do
    let (w, (self, _)) ← initialized
    Transfer.transfer w self ⟨other⟩ {sender := alice} (amount 1)).toOption = none := by decide +kernel

/-- A forged recipient kind cannot dispatch the owner's receive as A's code. -/
theorem wrong_kind : (do
    let (w, _) ← initialized
    w.stipend .send (⟨owner⟩ : Handle Transfer.Code.recipient) Transfer.receiveEntry alice (amount 0)).toOption = none := by decide +kernel

#print axioms original_send
#print axioms original_transfer
#print axioms wrong_handle
#print axioms wrong_kind
end Solidity.Examples.Tactics.PaymentSource
''')
