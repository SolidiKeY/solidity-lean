from pathlib import Path
Path('/workspace/solidity-lean/Solidity/Frontend/PaymentImport.lean').write_text('''import Solidity.Frontend.PaymentPlan
import Solidity.Semantics.PaymentWorld
import Solidity.Tools.Upstream

/-! # Declaration-checked payment source composition
The command checks the complete source plan, imports the original declarations,
and quotes the actual receive/getter programs. Creation is the existing World
operation. Initializer handle assignment is an existing typed statement; it is
not a supplied observation or an external-response-table entry. -/
namespace Solidity.Frontend.PaymentSource
open Lean Elab Command
open Solidity.ContractWorld

def unitEntry (C : Contract) (name : String) (payable : Bool) : Except String (Entry C Unit) := do
  let ⟨Γ, P⟩ ← Tools.Upstream.entryProg C [.call (.name name) []]
  return { locals := Γ, body := P, result := fun _ => .ok (), payable := payable }

def wordEntry (C : Contract) (raw : List RawStmt) : Except String (Entry C Word) := do
  let ⟨Γ, P⟩ ← Tools.Upstream.entryProg C raw
  return { locals := Γ, body := P, result := fun σ =>
    match Semantics.lookupBy (Var.ofName Tools.retLocal) (Tools.localVals (P.outNames []) σ.env) with
    | some (.uint n) => .ok n
    | _ => .error .exhausted }

def closed (C : Contract) (raw : List RawStmt) : TRes (Prog C [] []) :=
  match Tools.Upstream.entryProg C raw with
  | .error _ => .error .exhausted
  | .ok ⟨Γ, P⟩ => if h : Γ = [] then .ok (h ▸ P) else .error .exhausted

def checked {α : Type} : Except String α → TRes α
  | .ok a => .ok a
  | .error _ => .error .exhausted

syntax (name := paymentSource) "solc_payment_source " str " hash " num " as " ident : command

@[command_elab paymentSource]
def elabPaymentSource : CommandElab := fun stx => do
  let path : TSyntax `str := ⟨stx[1]⟩
  let hash : TSyntax `num := ⟨stx[3]⟩
  let file := System.FilePath.mk (← getFileName)
  let bytes ← IO.FS.readBinFile ((file.parent.getD ".") / path.getString)
  unless (fnv1a64 bytes).toNat == hash.getNat do throwError "solidity.paymentSource.hash: input differs"
  let some text := String.fromUTF8? bytes | throwError "payment source must be UTF-8"
  let data ← ofExcept (Json.parse text)
  let ast ← ofExcept (data.getObjVal? "ast")
  let plan ← ofExcept (PaymentPlan.read ast)
  let output := stx[5].getId
  let full := (← getCurrNamespace) ++ output
  let sourceName (s : String) := full ++ `Source ++ Lean.Name.mkSimple s
  for s in [plan.owner, plan.target] do
    let n := mkIdent (sourceName s)
    elabCommand (← `(solc_import $path hash $hash as $n testing))
  let targetName := sourceName plan.target
  let ownerName := sourceName plan.owner
  let targetC ← liftTermElabM <| unsafe evalConst Contract targetName
  let targetRows ← liftTermElabM <| unsafe evalConst (List ImportRow) (targetName ++ `report)
  let some recv := targetRows.find? (fun r => r.sourceId == plan.receiveId && r.status == .elaborated)
    | throwError "solidity.paymentSource.receive: exact receive declaration did not elaborate"
  unless recv.payable do throwError "solidity.paymentSource.receive: payable mismatch"
  let received ← ofExcept (unitEntry targetC recv.name recv.payable)
  let bodyName := full ++ `receiveBody
  if let some error ← liftCoreM (Prog.define bodyName targetName received.body) then throwError error
  let command (text : String) : CommandElabM Unit := do
    elabCommand (← ofExcept (Parser.runParserCategory (← getEnv) `command text))
  let n := output.toString
  let targetText := targetName.toString
  let ownerText := ownerName.toString
  command s!"inductive {n}.Code where\\n | owner | recipient\\n deriving DecidableEq"
  command s!"def {n}.contracts : {n}.Code → Solidity.Contract\\n | .owner => {ownerText}\\n | .recipient => {targetText}"
  command s!"def {n}.receiveEntry : Solidity.ContractWorld.Entry ({n}.contracts .recipient) Unit := \{ locals := _, body := {bodyName}, result := fun _ => .ok (), payable := true }"
  command s!"def {n}.targetCtor : Solidity.Prog ({n}.contracts .recipient) [] [] := .nil"
  if plan.root.isNone then
    command s!"def {n}.ownerCtor : Solidity.Prog ({n}.contracts .owner) [] [] := sol[{ownerText}]\{ constructor(); }"
    command s!"def {n}.deploy (w : Solidity.ContractWorld.World {n}.contracts) (self fresh : Solidity.ContractWorld.Address) (ctx : Solidity.ContractWorld.Context) : Solidity.TRes (Solidity.ContractWorld.World {n}.contracts × (Solidity.ContractWorld.Handle {n}.Code.owner × Option (Solidity.ContractWorld.Handle {n}.Code.recipient))) := do\\n let (next, reference) ← w.create .owner self {n}.ownerCtor ctx\\n pure (next, (reference, none))"
    command s!"def {n}.send (w : Solidity.ContractWorld.World {n}.contracts) (self : Solidity.ContractWorld.Handle {n}.Code.owner) (ctx : Solidity.ContractWorld.Context) (fresh : Solidity.ContractWorld.Address) : Solidity.TRes (Solidity.ContractWorld.World {n}.contracts × Bool) := w.paymentFrame self ctx false (fun paid => do\\n let (created, recipient) ← paid.create .recipient fresh {n}.targetCtor \{ sender := self.address }\\n created.stipend .send recipient {n}.receiveEntry self.address (Solidity.PrimTy.dflt .uint))"
  else
    let root := plan.root.getD ""
    let ownC ← liftTermElabM <| unsafe evalConst Contract ownerName
    let ownRows ← liftTermElabM <| unsafe evalConst (List ImportRow) (ownerName ++ `report)
    let some ownRecv := ownRows.find? (fun r => some r.sourceId == plan.ownerReceive && r.status == .elaborated)
      | throwError "solidity.paymentSource.receive: owner receive unavailable"
    let ownEntry ← ofExcept (unitEntry ownC ownRecv.name ownRecv.payable)
    let ownBodyName := full ++ `ownerReceiveBody
    if let some error ← liftCoreM (Prog.define ownBodyName ownerName ownEntry.body) then throwError error
    command s!"def {n}.ownerReceiveEntry : Solidity.ContractWorld.Entry ({n}.contracts .owner) Unit := \{ locals := _, body := {ownBodyName}, result := fun _ => .ok (), payable := true }"
    command s!"def {n}.rootEntry : Except String (Solidity.ContractWorld.Entry ({n}.contracts .owner) Solidity.ContractWorld.Word) := Solidity.Frontend.PaymentSource.wordEntry {ownerText} [.decl (.named \\"uint\\") \\"_r\\" (some (.name {toJson root |>.compress}))]"
    command s!"def {n}.deploy (w : Solidity.ContractWorld.World {n}.contracts) (self fresh : Solidity.ContractWorld.Address) (ctx : Solidity.ContractWorld.Context) : Solidity.TRes (Solidity.ContractWorld.World {n}.contracts × (Solidity.ContractWorld.Handle {n}.Code.owner × Option (Solidity.ContractWorld.Handle {n}.Code.recipient))) := do\\n if (w.accounts self).isSome || decide (self = ctx.sender) || ctx.isStatic then .error .revert else do\\n let (created, recipient) ← w.create .recipient fresh {n}.targetCtor \{ sender := self }\\n let init ← Solidity.Frontend.PaymentSource.closed {ownerText} [.assign (.name {toJson root |>.compress}) (.num recipient.address.1.1.toNat)]\\n let (next, reference) ← created.create .owner self init ctx\\n pure (next, (reference, some recipient))"
    command s!"def {n}.transfer (w : Solidity.ContractWorld.World {n}.contracts) (self : Solidity.ContractWorld.Handle {n}.Code.owner) (recipient : Solidity.ContractWorld.Handle {n}.Code.recipient) (ctx : Solidity.ContractWorld.Context) (amount : Solidity.ContractWorld.Word) : Solidity.TRes (Solidity.ContractWorld.World {n}.contracts × Bool) := w.paymentFrame self ctx false (fun paid => do\\n let entry ← Solidity.Frontend.PaymentSource.checked {n}.rootEntry\\n let (same, stored) ← paid.call self entry \{ sender := ctx.sender }\\n if stored != recipient.address.1 then .error .exhausted else same.stipend .transfer recipient {n}.receiveEntry self.address amount)"
    let some (getter, getterId) := plan.getter | throwError "payment getter absent"
    let some getRow := ownRows.find? (fun r => r.sourceId == getterId && r.status == .elaborated)
      | throwError "solidity.paymentSource.getter: source getter did not elaborate"
    let raw ← ofExcept (Tools.runStmt ownC getRow.name [])
    let getEntry ← ofExcept (wordEntry ownC [raw])
    let getBodyName := full ++ `getterBody
    if let some error ← liftCoreM (Prog.define getBodyName ownerName getEntry.body) then throwError error
    command s!"def {n}.getterEntry : Solidity.ContractWorld.Entry ({n}.contracts .owner) Solidity.ContractWorld.Word := \{ locals := _, body := {getBodyName}, result := fun σ => match Solidity.Semantics.lookupBy (Solidity.Var.ofName \\"_r\\") (Solidity.Tools.localVals ({getBodyName}.outNames []) σ.env) with | some (.uint value) => .ok value | _ => .error .exhausted }"
  -- The retained source plan contains declaration identities, never expectations.
  let planTerm := quote plan
  elabCommand (← `(def $(mkIdent (output ++ `plan)) : PaymentPlan.Plan := $planTerm))
end Solidity.Frontend.PaymentSource
''')
