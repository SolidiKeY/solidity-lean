from pathlib import Path
Path('/workspace/solidity-lean/scripts/payment-source.mjs').write_text('''/** Narrow source/world job preparation. Lean validates the complete AST shape;
 * this routing heuristic never establishes source admission or an outcome. */
import {writeFileSync,readFileSync,mkdirSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
const sha=x=>createHash('sha256').update(x).digest('hex');
export function preparePaymentSource(path,fixture,compile,work,api) {
  const source=[...fixture.sources.values()].join('\\n');
  if(!/\\bnew\\s+/.test(source)||!/[.]\\s*(send|transfer)\\s*\\(/.test(source))return null;
  const blocked=reason=>({path,stage:'lean-runtime',status:'blocked',reason});
  if(fixture.sources.size!==1||Object.keys(fixture.settings).some(k=>!['EVMVersion','compileViaYul','revertStrings'].includes(k))||
    fixture.settings.revertStrings&&!['debug','default'].includes(fixture.settings.revertStrings))return null;
  if(!api.evmCompatible(fixture.settings.EVMVersion))return blocked('payment EVM constraint excludes osaka');
  const required=api.runtimePipelines(fixture.settings),jobs=[];
  for(const pipeline of required){
    const sources=Object.fromEntries([...fixture.sources].map(([n,s])=>[n,{content:api.withPreamble(s)}]));
    const settings={viaIR:pipeline==='viaIR',evmVersion:'osaka',optimizer:{enabled:false,runs:200},libraries:{},remappings:[],
      ...(fixture.settings.revertStrings?{debug:{revertStrings:fixture.settings.revertStrings}}:{}),
      outputSelection:{'*':{'':['ast'],'*':['abi']}}};
    const out=compile({language:'Solidity',sources,settings});
    if((out.errors??[]).some(e=>e.severity==='error'))return blocked('payment source compiler diagnostics');
    const ast=out.sources[fixture.mainSource].ast;
    const owner=ast.nodes.filter(n=>n.nodeType==='ContractDefinition').at(-1);
    if(!owner)return blocked('payment source deployment owner missing');
    const abi=out.contracts[fixture.mainSource][owner.name].abi;
    const vectors=[],gas=[],ordered=[];
    for(const original of fixture.expectations){
      const line=original.trim();if(!line)continue;
      if(/^gas\\s/.test(line)){
        if(!/^gas (ir|irOptimized|legacy|legacyOptimized)( code)?: \\d+$/.test(line)||!vectors.length)return blocked('unadapted payment gas observation');
        gas.push({original,afterVector:vectors.length-1});ordered.push({kind:'independent-bytecode-gas',original,afterVector:vectors.length-1});continue;
      }
      const m=/^(constructor\\([^)]*\\)|\\(\\)|[A-Za-z_$][\\w$]*\\([^)]*\\))(?:\\s*,\\s*(\\d+)\\s*(wei|ether))?\\s*(->.*)$/.exec(line);
      if(!m)return blocked('unadapted ordered payment observation: '+line);
      const value=BigInt(m[2]??0)*(m[3]==='ether'?10n**18n:1n);
      if(value>=2n**256n)return blocked('incoming payment outside uint256');
      let v;
      if(m[1]==='()'){
        if(m[4].trim()!=='->')return blocked('unadapted empty-calldata expected bytes');
        v={signature:'()',args:[],expected:[],failure:false};
      }else [v]=api.semanticVectors({...fixture,expectations:[m[1]+' '+m[4]]},abi);
      vectors.push({...v,value:value.toString(),revertBytes:v.revertBytes??[]});
      ordered.push({kind:'typed-source-world',original,vector:vectors.length-1});
    }
    const normalize=v=>Array.isArray(v)?v.map(normalize):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,
      ['referencedDeclaration','scope','superFunction'].includes(k)&&Number.isInteger(x)&&x>=2**31?x-2**32:normalize(x)])):v;
    const input={header:{solcVersion:api.VERSION,sourceSha256:sha(sources[fixture.mainSource].content),solkeyCommit:'',source:path,
      provenanceVersion:1,compilerFile:'soljson-v0.8.38+commit.1835d247.js',compilerSha256:api.COMPILER_SHA,
      validationStage:'analysis',settings,acceptedPragmas:ast.nodes.filter(n=>n.nodeType==='PragmaDirective').map(n=>n.literals)},ast:normalize(ast)};
    const file=join(work,sha(path+'#payment#'+pipeline).slice(0,24)+'.ast.json');mkdirSync(work,{recursive:true});writeFileSync(file,JSON.stringify(input,null,2)+'\\n');
    jobs.push({path,pipeline,requiredPipelines:required,contract:owner.name,fixture:file,paymentSource:true,vectors,
      originalOrderedObservations:ordered,independentGasObservations:gas});
  }
  return {jobs};
}
''')
p=Path('/workspace/solidity-lean/scripts/solidity-upstream.mjs');s=p.read_text();s="import {preparePaymentSource} from './payment-source.mjs';\n"+s if not s.startswith('#!') else s.replace('\n','\nimport {preparePaymentSource} from \'./payment-source.mjs\';\n',1)
needle="  const allowed = syntax ?";i=s.index(needle);s=s[:i]+'''  if (semantic) {
    const payment=preparePaymentSource(path,fixture,compile,work,{runtimePipelines,withPreamble,semanticVectors,evmCompatible,COMPILER_SHA,VERSION});
    if(payment)return payment;
  }
'''+s[i:]
a=s.index('    writeFileSync(wrapper,`import Solidity.Tools.Upstream');b=s.index('\n    let failure;',a)
s=s[:a]+'''    const payment=batch.some(job=>job.paymentSource);
    writeFileSync(wrapper,`import Solidity.Tools.${payment?'PaymentReplay':'Upstream'}\\n#${payment?'payment':'upstream'}_batch ${JSON.stringify(input)} to ${JSON.stringify(checkpoint)}\\n`);'''+s[b:]
p.write_text(s)
