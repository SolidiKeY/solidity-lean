from pathlib import Path
p=Path('/workspace/solidity-lean/Solidity/Semantics/PaymentWorld.lean');s=p.read_text();i=s.index('#print axioms World.receiveRun_ok');s=s[:i]+'''/-- A proved no-op receive uses the same existing paid empty world frame.
Static admissibility remains syntactic and is not inferred from final equality. -/
theorem World.call_unit_noop (w : World contracts) {k : K} (self : Handle k)
    (P : Prog (contracts k) [] []) (payable : Bool) (ctx : Context)
    (ordinary : ctx.isStatic = false)
    (body : ∀ σ : State (contracts k) [], P.run σ = .ok ⟨σ, List.prefix_refl _⟩) :
    w.call self (Entry.unit P payable) ctx = w.call self (Entry.unit .nil payable) ctx := by
  unfold World.call World.callFrame Entry.unit
  simp only [ordinary, Bool.false_and, Bool.or_false]
  split
  · rfl
  · cases hs : w.storage? self with
    | none => rfl
    | some st =>
      simp only [TRes.ofOpt, bind, Except.bind]
      cases he : w.enter self.address ctx st payable with
      | error e => rfl
      | ok σ =>
        simp only [body σ]
        rfl

/-- Funding refusal precedes execution of the actual receive body. -/
theorem World.receiveRun_unfunded (w : World contracts) {k : K}
    (recipient : Handle k) (entry : Entry (contracts k) Unit) (sender : Address)
    (amount : Word) (st : Storage (contracts k))
    (code : w.isLibrary k = false) (stored : w.storage? recipient = some st)
    (unfunded : (w.funds sender).1 < amount.1) :
    w.receiveRun recipient entry sender amount = .error .revert := by
  simp only [World.receiveRun, World.call, World.callFrame, code, Context.isStatic,
    Bool.false_and, Bool.or_self, Bool.false_eq_true, ↓reduceIte, stored,
    TRes.ofOpt, bind, Except.bind, World.enter, Context.value, unfunded]

#print axioms World.call_unit_noop
#print axioms World.receiveRun_unfunded
'''+s[i:];p.write_text(s)
