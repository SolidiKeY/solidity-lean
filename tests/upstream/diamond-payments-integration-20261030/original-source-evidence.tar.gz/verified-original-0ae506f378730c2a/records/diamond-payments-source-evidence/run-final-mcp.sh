set -euo pipefail
cp lakefile.toml /workspace/diamond-payments-source-evidence/final-original.toml
trap 'cp /workspace/diamond-payments-source-evidence/final-original.toml lakefile.toml' EXIT
cp lakefile.payments.toml lakefile.toml
/workspace/.setup/tools/lean-4.24.0-linux/bin/lake build Solidity > /workspace/diamond-payments-source-evidence/mcp-warm-build.log 2>&1
.venv/bin/python /workspace/diamond-payments-source-evidence/mcp-final.py
