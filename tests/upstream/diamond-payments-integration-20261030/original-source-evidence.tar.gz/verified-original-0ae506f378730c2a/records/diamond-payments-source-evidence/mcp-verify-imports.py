import asyncio,os,json
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
async def main():
 async with stdio_client(StdioServerParameters(command='scripts/run-lean-mcp.sh',env=dict(os.environ))) as (r,w):
  async with ClientSession(r,w) as s:
   await s.initialize()
   for name in ['Solidity.Examples.Tactics.PaymentSource.original_send','Solidity.Examples.Tactics.PaymentSource.original_transfer','Solidity.Examples.Tactics.PaymentSource.wrong_handle','Solidity.Examples.Tactics.PaymentSource.wrong_kind','Solidity.Examples.Tactics.PaymentSource.wrong_bytes','Solidity.Examples.Tactics.PaymentCorpus.breakPiggyBank_callback']:
    result=await s.call_tool('lean_verify',{'file_path':'/workspace/solidity-lean/Solidity.lean','theorem_name':name,'scan_source':True})
    print(name,result.model_dump_json(),flush=True)
    data=result.structuredContent or {};assert 'axioms' in data and set(data['axioms'])<= {'propext','Classical.choice','Quot.sound'},name
 print('ALL_IMPORTED_AXIOM_AUDITS_PASS',flush=True)
asyncio.run(main())
