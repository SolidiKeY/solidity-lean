import asyncio,os
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
async def main():
 async with stdio_client(StdioServerParameters(command='scripts/run-lean-mcp.sh',env=dict(os.environ))) as (r,w):
  async with ClientSession(r,w) as s:
   await s.initialize()
   f='/workspace/solidity-lean/Solidity/Examples/Tactics/PaymentSource.lean'
   for tool,args in [('lean_goal',{'file_path':f,'line':66,'column':78}),('lean_multi_attempt',{'file_path':f,'line':66,'snippets':['rfl','exact of_decide_eq_true rfl','cbv']})]:
    result=await s.call_tool(tool,args);print(tool,result.model_dump_json(),flush=True)
asyncio.run(main())
