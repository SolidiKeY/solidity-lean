#!/bin/bash
real=/workspace/.setup/tools/lean-4.24.0-linux/bin/lake
if [ "$1" = env ] && [ "$2" = lean ]; then
 shift 2
 exec "$real" -f lakefile.payments.toml env lean -j1 "$@"
fi
for arg in "$@"; do
 if [ "$arg" = serve ] || [ "$arg" = lean ]; then
  exec "$real" -f lakefile.payments.toml "$@" -j1
 fi
done
exec "$real" -f lakefile.payments.toml "$@"
