from pathlib import Path
p=Path('/workspace/solidity-lean/Solidity/Semantics/PaymentWorld.lean');s=p.read_text();i=s.index('/-- A source wrapper');s=s[:i]+'''/-- A source local receives the handle returned by actual creation; the next
statement sends to that very handle, including when the amount is zero. -/
def World.createSend (w : World contracts) (k : K) (fresh : Address)
    (ctor : Prog (contracts k) [] []) (receive : Entry (contracts k) Unit)
    (sender : Address) : TRes (World contracts × Bool) := do
  let (created, reference) ← w.create k fresh ctor {sender := sender}
  created.stipend .send reference receive sender (PrimTy.dflt .uint)

'''+s[i:];i=s.index('/-- A proved no-op receive');s=s[:i]+'''omit [DecidableEq K] in
/-- Send true is equivalent to actual successful recipient execution. -/
theorem sendResult_true_iff (w next : World contracts) (run : TRes (World contracts × Unit)) :
    sendResult w run = .ok (next, true) ↔ run = .ok (next, ()) := by
  cases run with
  | ok pair => cases pair with | mk final unit => cases unit; simp only [sendResult, Except.ok.injEq, Prod.mk.injEq, and_true]
  | error e => cases h : catchable e <;> simp only [sendResult, h, Bool.false_eq_true, ↓reduceIte, Except.ok.injEq, Prod.mk.injEq, Bool.false_eq_true, and_false, Except.error_ne_ok]

/-- The source creation/send composition exposes both real world operations. -/
theorem World.createSend_ok {w next : World contracts} {k : K} {fresh : Address}
    {ctor : Prog (contracts k) [] []} {receive : Entry (contracts k) Unit}
    {sender : Address} {result : Bool}
    (run : w.createSend k fresh ctor receive sender = .ok (next, result)) :
    ∃ created reference,
      w.create k fresh ctor {sender := sender} = .ok (created, reference) ∧
      created.stipend .send reference receive sender (PrimTy.dflt .uint) = .ok (next, result) := by
  unfold World.createSend at run
  cases hc : w.create k fresh ctor {sender := sender} with
  | error e => simp only [hc, bind, Except.bind] at run; cases run
  | ok pair => exact ⟨pair.1, pair.2, hc, run⟩

/-- True from a stipend send has an actual funded receive/body/settlement
witness through receiveRun_ok; no default oracle reply supplies this evidence. -/
theorem World.stipend_send_true {w next : World contracts} {k : K}
    {recipient : Handle k} {entry : Entry (contracts k) Unit} {sender : Address} {amount : Word}
    (run : w.stipend .send recipient entry sender amount = .ok (next, true)) :
    w.receiveRun recipient entry sender amount = .ok (next, ()) := by
  unfold World.stipend at run
  split at run
  · cases run
  · exact (sendResult_true_iff w next _).mp run

'''+s[i:];s=s.replace('#print axioms World.call_unit_noop','#print axioms World.createSend_ok\n#print axioms World.stipend_send_true\n#print axioms sendResult_true_iff\n#print axioms World.call_unit_noop');p.write_text(s)
p=Path('/workspace/solidity-lean/Solidity/Frontend/PaymentImport.lean');s=p.read_text().replace('let (created, recipient) ← paid.create .recipient fresh {n}.targetCtor \\{ sender := self.address }\\n created.stipend .send recipient {n}.receiveEntry self.address (Solidity.PrimTy.dflt .uint)', 'paid.createSend .recipient fresh {n}.targetCtor {n}.receiveEntry self.address');p.write_text(s)
