import asyncio,os,json
from mcp import ClientSession,StdioServerParameters
from mcp.client.stdio import stdio_client
async def main():
 async with stdio_client(StdioServerParameters(command='scripts/run-lean-mcp.sh',env=dict(os.environ))) as (r,w):
  async with ClientSession(r,w) as s:
   await s.initialize()
   for f in ['Solidity/Semantics/ContractWorld.lean','Solidity/Semantics/ContractWorldCertificates.lean','Solidity/Semantics/PaymentWorld.lean','Solidity/Frontend/PaymentPlan.lean','Solidity/Frontend/PaymentImport.lean','Solidity/Tools/PaymentReplay.lean','Solidity/Examples/Tactics/PaymentSource.lean','Solidity/Language/Features.lean','Solidity.lean','TrustAudit.lean']:
    for poll in range(12):
     result=await s.call_tool('lean_diagnostic_messages',{'file_path':'/workspace/solidity-lean/'+f,'interactive':False,'timeout_s':60})
     print('DIAGNOSTICS',f,poll,result.model_dump_json(),flush=True)
     data=(result.structuredContent or {}).get('result',{})
     if not data.get('partial'):break
    assert data.get('success') and not data.get('partial') and not any(i['severity']=='error'for i in data.get('items',[])),f
   for f,name in [('Solidity/Semantics/PaymentWorld.lean','Solidity.ContractWorld.World.createSend_ok'),('Solidity/Semantics/PaymentWorld.lean','Solidity.ContractWorld.World.receiveRun_unfunded'),('Solidity/Semantics/PaymentWorld.lean','Solidity.ContractWorld.World.stipend_transfer_failure'),('Solidity/Examples/Tactics/PaymentSource.lean','Solidity.Examples.Tactics.PaymentSource.original_send'),('Solidity/Examples/Tactics/PaymentSource.lean','Solidity.Examples.Tactics.PaymentSource.original_transfer'),('Solidity/Examples/Tactics/PaymentCorpus.lean','Solidity.Examples.Tactics.PaymentCorpus.breakPiggyBank_callback')]:
    result=await s.call_tool('lean_verify',{'file_path':'/workspace/solidity-lean/'+f,'theorem_name':name,'scan_source':True})
    print('VERIFY',name,result.model_dump_json(),flush=True)
    data=result.structuredContent or {};assert 'axioms' in data and set(data['axioms'])<= {'propext','Classical.choice','Quot.sound'},name
 print('ALL_MCP_ASSERTIONS_PASS',flush=True)
asyncio.run(main())
