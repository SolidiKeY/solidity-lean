set -euo pipefail
cp lakefile.toml /workspace/diamond-payments-source-evidence/probe-original.toml
trap 'cp /workspace/diamond-payments-source-evidence/probe-original.toml lakefile.toml' EXIT
cp lakefile.payments.toml lakefile.toml
.venv/bin/python /workspace/diamond-payments-source-evidence/proof-probe.py
