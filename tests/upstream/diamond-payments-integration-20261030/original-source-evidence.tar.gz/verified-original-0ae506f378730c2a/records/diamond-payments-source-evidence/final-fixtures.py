import pathlib,subprocess,time,json
r=pathlib.Path('/workspace/diamond-payments-source-evidence');results=[]
for name,path in [('send','functionCall/send_zero_ether.sol'),('uncalled','expressions/uncalled_address_transfer_send.sol'),('transfer','revertStrings/transfer.sol')]:
 for kind in ['source','bytecode']:
  out=r/('final-'+kind+'-'+name)
  cmd=('node scripts/solidity-upstream.mjs run' if kind=='source' else 'timeout 120 node scripts/evm-reference/payment-replay.mjs')+' --compiler /workspace/diamond-payments-evidence/soljson-v0.8.38.js --filter '+('semanticTests/' if kind=='source' else 'test/libsolidity/semanticTests/')+path+' --out '+str(out if kind=='source' else out.with_suffix('.json'))
  start=time.monotonic()
  with (r/('final-'+kind+'-'+name+'.log')).open('w') as f:
   f.write('command='+cmd+'\n');f.flush();code=subprocess.call(['bash',str(r/'run.sh'),cmd],stdout=f,stderr=subprocess.STDOUT)
  row={'kind':kind,'name':name,'path':path,'command':cmd,'exit':code,'seconds':round(time.monotonic()-start,3)};results.append(row);(r/'fixtures-final.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
