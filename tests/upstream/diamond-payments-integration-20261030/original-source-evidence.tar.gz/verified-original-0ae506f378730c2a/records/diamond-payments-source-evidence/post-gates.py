import pathlib,subprocess,time,json
r=pathlib.Path('/workspace/diamond-payments-source-evidence');results=[]
checks=[('orphans','node scripts/check-orphans.mjs'),('layers','node scripts/check-layers.mjs'),('automatic','node scripts/check-automatic.mjs --strict --build-log /workspace/diamond-payments-source-evidence/full-run.log'),('trust','bash scripts/check-trust.sh'),('inventory','.venv/bin/python scripts/solidity-feature-audit.py --check'),('source-fixtures-reproduce','SOLC_REFERENCE=/workspace/diamond-payments-evidence/soljson-v0.8.38.js node scripts/payment-source-fixtures.mjs --check'),('script-tests','SOLC_REFERENCE=/workspace/diamond-payments-evidence/soljson-v0.8.38.js node --test --test-concurrency=1 scripts/payment-source.test.mjs scripts/payment-reference.test.mjs scripts/payment-corpus.test.mjs scripts/solkey-migration.test.mjs scripts/solidity-upstream.test.mjs scripts/evm-reference/replay.test.mjs scripts/evm-reference/payment-replay.test.mjs'),('trust-audit','lake env lean --tstack=131072 -j1 TrustAudit.lean'),('corpus','bash scripts/check-corpus.sh'),('doc-paths','bash scripts/check-doc-paths.sh'),('diff','git diff --check')]
for name,cmd in checks:
 start=time.monotonic()
 with (r/('gate-'+name+'.log')).open('w') as f:
  f.write('command='+cmd+'\n');f.flush();code=subprocess.call(['bash',str(r/'run.sh'),cmd],stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit':code,'seconds':round(time.monotonic()-start,3)};results.append(row);(r/'gates.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
print('DONE failures='+str(sum(x['exit']!=0 for x in results)),flush=True)
