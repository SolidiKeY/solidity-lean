from pathlib import Path
import json,re
r=Path('/workspace/solidity-lean');e=Path('/workspace/diamond-payments-source-evidence')
full=json.loads((e/'full-resources.json').read_text());assert full['exit']==0
for x in json.loads((e/'fixtures-final.json').read_text()):assert x['exit']==0
p=r/'docs/feature-work/diamond-payments.md';s=p.read_text();s=s.replace('Two original source fixtures still require genuine source-world/payload/gas\nexecution support; they are not declared complete. Earlier milestone validation\nand blocker lists below record their historical checkpoint, not new results.', 'The two remaining original source rows now execute through a narrow typed\nworld-source bridge, with kernel witnesses and paired independent bytecode/gas\nvalidation. All three named source rows pass both required pipelines. Earlier\nvalidation and blocker lists below are historical checkpoints; the final source\nbridge milestone records the current bounded scope and actual checks.')
s=s.replace('## Human-approved conditional payment account','## Checkpoint d426b23f: human-approved conditional payment account (historical)')
s+='\n\n'+(e/'SourceBridge.md').read_text()
s+='''
### Actual final validation

- Full `./run-lean.sh`: exit0,2189.997s;699 library/default jobs and259
  TestSuite jobs. Aggregate sampled RAM peak12884570112 bytes; retained group
  peak12884901888 bytes (the12GiB cap). memory.events max1624 versus inherited377,
  oom0/oom_kill0. This is measured reclaim/pressure, not spare margin. A live
  heavy-build OS snapshot retained8598601728 bytes MemAvailable; physical RAM
  is18882674688 bytes, a reported drift from nominal16GiB. Disk had24GiB free.
- Its first terminal SolKey check was skipped because SOLKEY_RULES was absent;
  that actual skipped output is retained. After supplying the existing pinned
  path, a full cached confirmation exited0 in0.951s and actually matched377
  taclets/131 read annotations. No pin/configuration or budget was changed.
- Strict automatic gate exit0:26 timed TestSuite modules within300s;491
  automatic,61 step-budgeted,11 refuted,0 pending. Orphans/layers/inventory all0.
- Script regressions59/59 passed,43.717s. Source AST reproduction --check exit0.
  Trust inventory728 sources/245 reviewed sites/0 findings; TrustAudit545
  headline theorems use only propext/Classical.choice/Quot.sound. Corpus gate0:
  73 proved/34 unsupported/101 unported, preserving the old PiggyBank improvement
  and every other original pin.
- `fixtures-final.json`: original send source0(43.650s), bytecode0(5.584s);
  uncalled source0(2.231s), bytecode0(2.791s); debug transfer source0(6.409s),
  bytecode0(2.929s). Wall times may include waiting for the single writer lock.
  All ordered rows and required modes are retained in final-source-*/results.json
  and final-bytecode-*.json. Send also verifies all6 gas/code-gas rows across
  irOptimized/legacy/legacyOptimized. The uncalled fixture still executes only
  f(), not its uncalled fallback member references.
- Final per-file MCP and actual lean_verify evidence are in mcp-final.log;
  assertion-backed completion is recorded after it finishes. Initial partial
  diagnostics and shutdown messages are retained, never treated as passing.
- Global doc-path check remains exit1 with the same20 baseline historical/
  external missing references. Its actual debt is not waived or rewritten.

Before/after from d426b23f: send blocked→working; debug transfer blocked→working;
uncalled working→working. Both repaired rows now run actual typed world source
compositions; their kernel witnesses and independent bytecode/gas observations
are distinct evidence. There is no remaining named source-row implementation
blocker or pending human semantics decision for this conditional assignment.
The broader language/profile/decision-completeness gaps above remain outside
this completion claim.

Evidence directory: /workspace/diamond-payments-source-evidence. Earlier
checkpoints, failed attempts, command output, timings and original exports are
preserved. The cumulative patch/handoff/checksum are exported only after the
final actual diagnostics and review complete. No push or merge.
''';p.write_text(s)
p=r/'docs/kernel-port.md';s=p.read_text().replace('source/compiler/EVM blockers remain unchanged. See','the three original payment source fixtures now have a narrow typed world\n  bridge and paired independent bytecode/gas validation; broader compiler\n  correspondence remains open. See').replace('while source-world/gas\n  execution stays open.', 'with the named source-world fixtures now validated separately from numerical\n  gas and broader compiler correspondence.');p.write_text(s)
p=r/'docs/options.md';s=p.read_text().replace('source-world/gas correspondence.','general source-world/gas correspondence. The narrow original payment source\nfixtures now use `Frontend/PaymentImport.lean` over existing world frames, with\nactual receive bodies and independent bytecode/gas agreement. This deterministic\nunmetered source layer does not change the callback judgment or establish\n2300-gas adequacy in Lean.');p.write_text(s)
p=r/'docs/lean-key-rule-map.md';s=p.read_text();needle='| — | `PaymentConditions` exact family';pos=s.index(needle);s=s[:pos]+'''| — | `PaymentWorld` / payment source frame | source boundary, not a taclet | Existing create/call/paidRun compose typed returned handles, actual receive selection/body and settlement. Send true has an actual receive witness; completed failure preserves the pre-receive world, transfer transports actual halt bytes, and atomic failure preserves the original world. `PaymentPlan`/`PaymentImport` bind complete original source declarations and IDs; numerical stipend/gas and compiler agreement remain independent bytecode evidence. Full-gas source calls are not coerced into stipend rules. |
'''+s[pos:];p.write_text(s)
p=r/'scripts/evm-reference/README.md';s=p.read_text()+'''

The upstream source runner uses the payment adapter only after complete-shape
validation in Lean. Whole payment-fixture success requires fresh provenance-
matched reference evidence for both pipelines, every functional observation and
any gas rows; an unmetered typed source match alone stays pending. The SDK is
therefore needed to finish those payment rows, while the Lean core remains
independent of it. Install from this package's lockfile with npm ci --ignore-scripts.
The source witnesses reproduce with scripts/payment-source-fixtures.mjs --check
and SOLC_REFERENCE pointing to the pinned0.8.38 compiler.
''';p.write_text(s)
