import subprocess,time,json,pathlib
root=pathlib.Path('/workspace/diamond-payments-source-evidence');start=time.monotonic();samples=[]
cmd=['bash',str(root/'run.sh'),'./run-lean.sh']
with (root/'full-run.log').open('w') as f:
 f.write('command=./run-lean.sh; LEAN_NUM_THREADS=1; Lean-j1 via saved temporary Lake configuration; retained12GiB/no-swap Docker group\n');f.flush()
 p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT)
 while True:
  try:
   val=subprocess.check_output(['docker','exec','next10-payments-work','cat','/sys/fs/cgroup/memory.current'],text=True).strip();samples.append({'seconds':round(time.monotonic()-start,3),'memory_current_bytes':int(val)})
  except Exception as e:samples.append({'sample_error':type(e).__name__})
  try:p.wait(timeout=2);break
  except subprocess.TimeoutExpired:pass
 code=p.returncode
 peak=subprocess.check_output(['docker','exec','next10-payments-work','cat','/sys/fs/cgroup/memory.peak'],text=True).strip()
 events=subprocess.check_output(['docker','exec','next10-payments-work','cat','/sys/fs/cgroup/memory.events'],text=True)
 result={'exit':code,'seconds':round(time.monotonic()-start,3),'sampled_peak_bytes':max((s.get('memory_current_bytes',0)for s in samples),default=0),'retained_group_cumulative_peak_bytes':int(peak),'memory_events':events,'samples':samples}
 (root/'full-resources.json').write_text(json.dumps(result,indent=2)+'\n');f.write('\n'+json.dumps({k:v for k,v in result.items()if k!='samples'})+'\n')
print(json.dumps({k:v for k,v in result.items()if k!='samples'}),flush=True)
raise SystemExit(code)
