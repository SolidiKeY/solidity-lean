from pathlib import Path
import subprocess,json,hashlib,shutil
r=Path('/workspace/solidity-lean');e=Path('/workspace/diamond-payments-source-evidence');base='f4dee4a29c2e208b36db4a4161a4723c735cd775'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True)
for a in [base,'2edd52bfab0235e71d620ac7d2ef09c2167d20b0','1b9bf3a9bc342ba8807b681a14c3ec8168610a9e','d426b23f74d059dbc507e1a9f988bf5877922013']:subprocess.check_call(['git','merge-base','--is-ancestor',a,head],cwd=r)
old=e/'checkpoint-d426b23f';old.mkdir(exist_ok=True)
for suffix in ['.patch','.patch.sha256','.commit','-handoff.md','-evidence.json','-checksums.sha256']:
 p=Path('/workspace/next10-diamond-payments'+suffix)
 if p.exists() and not (old/p.name).exists():shutil.copy2(p,old/p.name)
p=Path('/workspace/next10-diamond-payments.patch');p.write_bytes(subprocess.check_output(['git','diff','--binary',base,head],cwd=r))
h=hashlib.sha256(p.read_bytes()).hexdigest();Path(str(p)+'.sha256').write_text(h+'  '+str(p)+'\n')
Path('/workspace/next10-diamond-payments.commit').write_text(head+'\n')
d=json.loads((e/'evidence.json').read_text());d.update(commit=head,branch='codex/next10-diamond-payments',clean_checkout=True,cumulative_patch=str(p),patch_sha256=h,prior_exports=str(old),no_push_or_merge=True)
text=json.dumps(d,indent=2)+'\n';(e/'evidence.json').write_text(text);Path('/workspace/next10-diamond-payments-evidence.json').write_text(text)
intro=f'''# Validated conditional payment assignment {head[:8]}

The named remaining payment source gap is closed: all three original source
fixtures and all three independent bytecode reruns pass in every required mode,
with every original observation and gas row retained. The two world-dependent
rows use the new typed frame; uncalled-reference uses its ordinary source fix.
Kernel original send/transfer snapshots, conditional deterministic/callback
family and original PiggyBank proof retain only standard axioms. Full library/
TestSuite, strict, trust, corpus,59 regressions and source/reference gates passed.
The global doc-path gate still fails on20 pre-existing historical/external paths.

Scope is bounded unmetered typed source composition plus independent EVM/gas
agreement. This is not universal compiler equivalence, general source-world or
gas/callback completeness. The original unconditional refutations, six gaps and
target certificates are unchanged. No human decision or named source blocker is
pending. Same VM/branch retained; no push/merge or other task/monitor changes.

Commit: {head}
Base: {base}
Patch SHA256: {h}
Evidence: {e}
Prior d426 exports: {old}

Full actual command/exit/timing/resource, source/compiler/kernel distinctions,
reviewed scope, repaired scratch audit failure and remaining scope limits follow
in the owning feature record copied below.

'''
Path('/workspace/next10-diamond-payments-handoff.md').write_text(intro+(r/'docs/feature-work/diamond-payments.md').read_text())
(e/'STATE.md').write_text((e/'STATE.md').read_text()+f'Final committed HEAD={head}; cleanbranch. Exported cumulativepatch SHA256={h}; canonical artifacts /workspace/next10-diamond-payments.* and-handoff.md/-evidence.json; oldexports preserved checkpoint-d426b23f. All required named source gates closed. No active heavy check.\n')
files=[Path('/workspace/next10-diamond-payments'+s)for s in ['.patch','.patch.sha256','.commit','-evidence.json','-handoff.md']]
files+=sorted(f for f in e.rglob('*')if f.is_file() and f.suffix in ['.log','.json','.md','.py','.sh','.toml','.lean'] and 'checkpoint-d426b23f' not in f.parts)
manifest=Path('/workspace/next10-diamond-payments-checksums.sha256');manifest.write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f)+'\n'for f in files))
assert all(hashlib.sha256(Path(line.split('  ',1)[1]).read_bytes()).hexdigest()==line.split('  ',1)[0]for line in manifest.read_text().splitlines())
print('HEAD='+head);print('PATCH_SHA256='+h);print('PATCH_BYTES='+str(p.stat().st_size));print('VERIFIED_CHECKSUM_FILES='+str(len(files)));print('CLEAN=1')
