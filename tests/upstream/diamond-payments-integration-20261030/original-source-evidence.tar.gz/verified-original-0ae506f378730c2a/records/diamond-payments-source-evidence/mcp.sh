#!/bin/bash
set -euo pipefail
cp lakefile.toml /workspace/diamond-payments-source-evidence/lakefile.original.toml
trap 'cp /workspace/diamond-payments-source-evidence/lakefile.original.toml lakefile.toml' EXIT
cp lakefile.payments.toml lakefile.toml
.venv/bin/python /workspace/diamond-payments-evidence/mcp-resume.py "$@"
