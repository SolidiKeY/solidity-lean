from pathlib import Path
import subprocess,json,hashlib,os
s=Path('/home/guilherme/.local/state/cloudvm/solidity-next10-20261028');old=json.loads((s/'investigation-0e01a8d7-documentation/comparison.json').read_text());out={'scope':'Coordinator fresh verification of exact committed-tree documentation snapshots; no original run or source manifest extension implied'}
root=Path('/tmp/cloudvm-repair-routing/documentation');root.mkdir(exist_ok=True)
for side in ['base','source']:
 q=old[side];snapshot=Path(q['snapshot']);env={**os.environ,'GIT_DIR':'/home/guilherme/projects/solidity-lean/.git','GIT_WORK_TREE':str(snapshot),'GIT_INDEX_FILE':q['private_index']};n=0
 for record in subprocess.check_output(['git','ls-tree','-rz',q['commit']],env=env).split(b'\0'):
  if not record:continue
  meta,name=record.split(b'\t',1);mode,typ,oid=meta.split()
  if typ!=b'blob':continue
  p=snapshot/os.fsdecode(name);data=os.fsencode(os.readlink(p)) if mode==b'120000' else p.read_bytes()
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid.decode();n+=1
 result=subprocess.run(['bash','scripts/check-doc-paths.sh'],cwd=snapshot,env=env,text=True,capture_output=True);log=root/(side+'.log');log.write_text(result.stdout+result.stderr)
 findings=sorted(x for x in result.stdout.splitlines() if x.startswith(('missing:','ambiguous:')));assert result.returncode==q['exit_code']==1 and findings==q['findings']
 out[side]={'commit':q['commit'],'tree':q['tree'],'verified_committed_blobs':n,'exit_code':result.returncode,'findings':findings,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'scanner_sha256':hashlib.sha256((snapshot/'scripts/check-doc-paths.sh').read_bytes()).hexdigest()}
assert out['base']['findings']==out['source']['findings'];out.update(identical_findings=len(out['base']['findings']),new_findings=[],global_gate_passed=False);(root/'comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'compared_blobs':sum(out[x]['verified_committed_blobs'] for x in ['base','source']),'same_findings':out['identical_findings'],'exits':[out[x]['exit_code'] for x in ['base','source']],'passed':False}))
