"""Verify separately pinned coordinator evidence and repair local attribution."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

sha = lambda b: hashlib.sha256(b).hexdigest()
root = Path.cwd()
dest = root / 'tests/upstream/diamond-payments-integration-20261030'
state = Path('/home/guilherme/.local/state/cloudvm/solidity-next10-20261028')
ctx = state / 'integration/repair-contexts/diamond-payments/20bbb1071e12d6e0765c885434df3defc7477b92/616cae7d7f64b8ae733455cac84e2f3392fb6dc91c6e3ead13066e026564706b'
manifest_bytes = (ctx / 'manifest.json').read_bytes()
assert sha(manifest_bytes) == ctx.name
manifest = json.loads(manifest_bytes)
members = {'context/manifest.json': manifest_bytes}
for item in manifest['files']:
    data = (ctx / item['name']).read_bytes()
    assert sha(data) == item['sha256']
    members['context/' + item['name']] = data
receipt_path = state / 'integration/artifacts/diamond-payments/20bbb1071e12d6e0765c885434df3defc7477b92/supplements/8ba611e40179bf799807e7effa1204333ca69d7b4018de7837454cb5716fa7a4/retrieval.json'
receipt_bytes = receipt_path.read_bytes()
assert sha(receipt_bytes) == '9d762c79c1c3aaaaa8e14fc56e704cb2ab7578e365d5455672ff0faf41f8f9e1'
assert receipt_bytes == (dest / 'supplemental-retrieval.json').read_bytes()
receipt = json.loads(receipt_bytes)
identity = manifest['identity']
for key in ['source_commit', 'slug', 'environmentId', 'threadId']:
    assert identity[key] == receipt[key]
assert identity['source_base'] == receipt['base_commit']
for item in receipt['artifacts']:
    data = Path(item['local']).read_bytes()
    assert len(data) == item['size'] and sha(data) == item['sha256']
original_bytes = (dest / 'original-source-evidence.tar.gz').read_bytes()
assert sha(original_bytes) == 'e8bc40d0aa74edb65d0a99f76891102d0c0ea4ed8d43260e70a096c616fb68b1'
with tarfile.open(fileobj=io.BytesIO(original_bytes)) as archive:
    original = {m.name: archive.extractfile(m).read() for m in archive if m.isfile()}
prefix = 'verified-original-0ae506f378730c2a/'
checksums = original[prefix + 'original-175-checksums.sha256']
assert sha(checksums) == '0ae506f378730c2a813f4c12de0acd859a924f3dc4e56508a2b92ef07291a8b3'
lines = checksums.decode().splitlines()
assert len(lines) == 175 and len(original) == 177
for line in lines:
    digest, path = line.split(None, 1)
    assert sha(original[prefix + 'records/' + path.removeprefix('/workspace/')]) == digest
summary = json.loads(original[prefix + 'records/next10-diamond-payments-evidence.json'])
assert summary['commit'] == identity['source_commit'] and summary['base'] == identity['source_base']
assert original[prefix + 'records/next10-diamond-payments.commit'].decode().strip() == identity['source_commit']
src = prefix + 'records/diamond-payments-source-evidence/'
findings = lambda b: sorted(x for x in b.decode().splitlines() if x.startswith(('missing:', 'ambiguous:')))
comparison = json.loads((ctx / '5-comparison.json').read_bytes())
fresh = json.loads((root / '.lake/integration-repair/pinned-documentation/comparison.json').read_bytes())
baseline = (ctx / '0-original-resume-doc-paths-baseline.log').read_bytes()
source = original[src + 'doc-paths-final.log']
assert baseline.decode().splitlines()[0] == identity['source_base']
assert b'EXIT_CODE=1' in baseline
assert source == (ctx / '2-authenticated-source-doc-paths-final.log').read_bytes()
assert source == original[src + 'doc-paths-reviewed.log']
assert findings(baseline) == findings(source) == comparison['base']['findings'] == comparison['source']['findings']
for side in ['base', 'source']:
    assert fresh[side]['commit'] == comparison[side]['commit']
    assert fresh[side]['tree'] == comparison[side]['tree']
    assert fresh[side]['findings'] == findings(source)
    assert fresh[side]['exit_code'] == 1
extra_comparison = json.loads((ctx / '1-original-resume-doc-paths-comparison.json').read_bytes())
assert extra_comparison['baselineExit'] == extra_comparison['currentExit'] == 1
assert sorted(extra_comparison['remaining']) == [x for x in findings(source) if x.startswith('missing:')]
assert extra_comparison['baselineMissing'] == extra_comparison['currentMissing'] == 20
gates = json.loads(original[src + 'gates.json'])
for gate in gates:
    raw = original[src + 'gate-' + gate['name'] + '.log'].decode()
    assert 'command=' + gate['command'] in raw
    assert gate['exit'] == (1 if gate['name'] == 'doc-paths' else 0)
resources = json.loads(original[src + 'full-resources.json'])
assert resources['exit'] == 0 and resources['sampled_peak_bytes'] <= 12 * 1024**3
assert all('memory_current_bytes' in s for s in resources['samples'])
assert 'oom_kill 0' in resources['memory_events']
assert b'545 headline theorems use only the standard axioms' in original[src + 'gate-trust-audit.log']
assert b'Build completed successfully' in original[src + 'full-run.log']
prompt = (ctx / '10-diamond-payments.txt').read_text()
assert "The shared local machine's extra 12 GiB reserve is not an additional per-VM reservation" in prompt
paired = []
def check_matches(obj):
    if isinstance(obj, dict):
        for key, val in obj.items():
            if key == 'matches':
                assert val is True
            check_matches(val)
    elif isinstance(obj, list):
        for val in obj:
            check_matches(val)
for name in ['send', 'uncalled', 'transfer']:
    s = json.loads(original[src + 'final-source-' + name + '/results.json'])
    b = json.loads(original[src + 'final-bytecode-' + name + '.json'])
    row, reference = s['results'][0], b['result']
    assert len(s['results']) == 1 and row['status'] == reference['status'] == 'working'
    assert row['path'] == reference['path']
    assert row['requiredPipelines'] == reference['requiredPipelines'] == ['legacy', 'viaIR']
    assert [v['pipeline'] for v in row['variants']] == row['requiredPipelines']
    assert [v['profile'] for v in reference['variants']] == reference['requiredProfiles']
    for key in ['commit', 'compilerSha256', 'archiveSha256']:
        assert s['metadata'][key] == b['metadata'][key]
    for variant in row['variants'] + reference['variants']:
        assert variant['status'] == 'working'
    if 'paymentReferenceEvidence' in row:
        assert row['paymentReferenceEvidence'] == b
        for variant in row['variants']:
            assert [x['original'] for x in variant['originalOrderedObservations']] == reference['expectedObservations']
    check_matches(b)
    paired.append({'name': name, 'source_sha256': reference['sourceSha256'],
                   'source_pipelines': row['requiredPipelines'], 'reference_profiles': reference['requiredProfiles'],
                   'ordered_observations': len(reference['expectedObservations']), 'retained_status': 'working'})
for name in ['comparison.json', 'base.log', 'source.log']:
    members['repair-recomputation/' + name] = (root / '.lake/integration-repair/pinned-documentation' / name).read_bytes()
members['repair-recomputation/verify-pinned-documentation.py'] = (root / '.lake/integration-repair/verify-pinned-documentation.py').read_bytes()
members['repair-recomputation/repair-evidence.py'] = Path(__file__).read_bytes()
with tarfile.open(dest / 'coordinator-evidence.tar.gz', 'w:gz') as archive:
    for name, data in members.items():
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(data))
record = {
    'version': 1, 'repair_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'scope': 'Separate coordinator evidence and fresh exact-commit recomputation; no extension of original175manifest, historical execution claim, approval, or global gate pass',
    'context_manifest': str(ctx / 'manifest.json'), 'context_manifest_sha256': sha(manifest_bytes),
    'identity': identity, 'identity_matches_supplement': True, 'context_files_verified': 11,
    'supplement_artifacts_reverified': 7, 'original_records_reverified': 175,
    'original_archive_members_reverified': 177, 'original_source_coverage_unchanged': True,
    'extra_baseline_original_manifest_covered': False, 'original_historical_baseline_execution_authenticated': False,
    'documentation': {**fresh, 'original_source_and_extra_baseline_findings_match': True,
                      'missing_each': 20, 'ambiguous_each': 6, 'baseline_debt_identity_verified': True,
                      'provenance': 'Extra baseline bytes are separately pinned retrievals; exact-commit recomputation establishes unchanged findings, not an original historical execution'},
    'source_resource_scope': {
        'frozen_prompt_sha256': sha((ctx / '10-diamond-payments.txt').read_bytes()),
        'memory_max_bytes': 12 * 1024**3, 'swap_max_bytes': 0, 'lean_j': 1, 'lean_threads': 1,
        'os_headroom_required': True, 'extra_local_12GiB_reserve_applies_to_source_VM': False,
        'summary_reported_mem_available_bytes': summary['limits']['observed_heavy_build_mem_available_bytes'],
        'full_resource_samples': len(resources['samples']),
        'continuous_host_MemAvailable_samples_available': False,
        'note': 'Cgroup usage is not host MemAvailable; no continuous-headroom proof is inferred. Source requirements are unchanged.'},
    'local_required_os_reserve_bytes': 12 * 1024**3,
    'retained_build': {k:v for k,v in resources.items() if k != 'samples'},
    'retained_gate_exits': {g['name']: g['exit'] for g in gates}, 'paired_reports_reinspected': paired,
    'evidence_verified': True, 'original_validation_verified': False,
    'original_validation_verified_note': 'Recorded evidence and unchanged documentation findings are verified. Required documentation still exited 1; this is not an all-gates-passing validation.',
    'evidence_prerequisites_remaining': [], 'integration_passed': False,
    'current_combined_gates': 'Coordinator must run; previous checks and reviews do not approve this repair',
    'independent_reviews': {'finder': 'pending', 'skeptic': 'pending'},
    'lean_source_edited': False, 'lean_checks_run': False, 'external_index_written': False, 'commit_created': False,
    'archive': 'coordinator-evidence.tar.gz', 'archive_sha256': sha((dest / 'coordinator-evidence.tar.gz').read_bytes()),
    'archive_index': [{'name': n, 'size': len(b), 'sha256': sha(b)} for n,b in members.items()]}
(dest / 'coordinator-evidence-verification.json').write_text(json.dumps(record, indent=2) + '\n')
verification_path = dest / 'original-evidence-verification.json'
verification = json.loads(verification_path.read_bytes())
verification['prior_audit_head'] = verification['candidate_head']
verification['candidate_head'] = record['repair_head']
verification['version'] = 2
verification['documentation'].update(baseline_log_available=True, baseline_debt_identity_verified=True,
    baseline_log_original_manifest_covered=False, original_historical_baseline_execution_authenticated=False,
    baseline_exit=1, source_exit=1, identical_findings=26, new_findings=[], global_gate_passed=False,
    note='Original175 archive still has no baseline log. Separate pinned coordinator retrieval plus independently recomputed exact Git trees establish identical findings; neither authenticates an original historical baseline execution.')
verification['historical_reserve_satisfied'] = None
verification.pop('required_os_reserve_bytes')
verification['required_local_os_reserve_bytes'] = record['local_required_os_reserve_bytes']
verification['source_resource_scope'] = record['source_resource_scope']
verification['resource_note'] = 'Prior 12GiB reserve failure attributed a LOCAL requirement to the source VM. Frozen source prompt excludes that extra reservation, while retaining hard12GiB/no-swap/serial Lean and VM OS headroom. Raw cgroup samples do not prove continuous host MemAvailable.'
verification['evidence_verified'] = True
verification['original_validation_verified_note'] = record['original_validation_verified_note']
verification['remaining_prerequisites'] = []
verification['coordinator_evidence'] = {'verification': 'coordinator-evidence-verification.json',
    'verification_sha256': sha((dest / 'coordinator-evidence-verification.json').read_bytes()),
    'archive': record['archive'], 'archive_sha256': record['archive_sha256'],
    'original_source_checksum_coverage_added': 0}
verification['prior_focused_repair_checks'] = verification.pop('focused_repair_checks')
verification['focused_repair_checks'] = {'context_hashes': 'pass', 'original175_reverification': 'pass',
    'exact_git_documentation_recomputation': '26 identical findings; both exits1; zero new',
    'lean_source_edited': False, 'lean_checks_run': False, 'independent_reviews': record['independent_reviews'],
    'combined_gates': record['current_combined_gates'], 'index_written': False, 'commit_created': False}
verification_path.write_text(json.dumps(verification, indent=2) + '\n')
local_path = dest / 'manifest.json'
local = json.loads(local_path.read_bytes())
local['evidence_verified'] = True
local['original_validation_verified_note'] = record['original_validation_verified_note']
local['resource_scope'] = 'Retained regression samples concern LOCAL capped integration cgroup and OS reserve; cumulative memory.peak is not per-command RSS. Original source records are verified separately against the frozen source-VM requirements; LOCAL still requires an extra12GiB OS reserve.'
supplement = local['original_evidence_supplement']
supplement['verification_sha256'] = sha(verification_path.read_bytes())
supplement['evidence_verified'] = True
supplement['original_validation_verified_note'] = record['original_validation_verified_note']
supplement['historical_os_reserve_satisfied'] = None
supplement['historical_extra_local_reserve_applicable'] = False
supplement['remaining_prerequisites'] = []
local['coordinator_evidence'] = verification['coordinator_evidence']
local['coordinator_evidence_repair'] = {'head': record['repair_head'], 'integration_passed': False,
    'supersedes_prior_reviews_for_new_edits': True, 'independent_reviews': record['independent_reviews'],
    'combined_gates': record['current_combined_gates']}
local_path.write_text(json.dumps(local, indent=2) + '\n')
print(json.dumps({'context_verified': 11, 'original_records_verified': 175,
                  'documentation_exits': [1,1], 'findings': 26, 'new': 0, 'evidence_verified': True,
                  'original_validation_verified': False, 'integration_passed': False}))
