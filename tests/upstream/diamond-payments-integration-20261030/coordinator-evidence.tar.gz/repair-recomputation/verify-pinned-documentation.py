"""Recompute documentation findings from exact Git blobs, without using the live index."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile

repo = Path.cwd()
out = repo / '.lake/integration-repair/pinned-documentation'
out.mkdir(exist_ok=True)
context = Path('/home/guilherme/.local/state/cloudvm/solidity-next10-20261028/integration/repair-contexts/diamond-payments/20bbb1071e12d6e0765c885434df3defc7477b92/616cae7d7f64b8ae733455cac84e2f3392fb6dc91c6e3ead13066e026564706b')
expected = json.loads((context / '5-comparison.json').read_bytes())
gitdir = subprocess.check_output(['git', 'rev-parse', '--absolute-git-dir'], text=True).strip()
result = {'scope': 'Fresh repair-worker exact committed-tree comparison; not an original historical run or a combined gate'}
for side in ['base', 'source']:
    record = expected[side]
    commit = record['commit']
    snapshot = out / side
    snapshot.mkdir(exist_ok=True)
    archive = out / (side + '.tar')
    with archive.open('wb') as stream:
        subprocess.run(['git', 'archive', '--format=tar', commit], stdout=stream, check=True)
    with tarfile.open(archive) as stream:
        stream.extractall(snapshot, filter='data')
    archive.unlink()
    count = 0
    for line in subprocess.check_output(['git', 'ls-tree', '-rz', commit]).split(b'\0'):
        if not line:
            continue
        meta, name = line.split(b'\t', 1)
        mode, kind, oid = meta.split()
        if kind != b'blob':
            continue
        path = snapshot / os.fsdecode(name)
        data = os.fsencode(os.readlink(path)) if mode == b'120000' else path.read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == oid.decode()
        count += 1
    tree = subprocess.check_output(['git', 'rev-parse', commit + '^{tree}'], text=True).strip()
    assert tree == record['tree']
    # Only this disposable private index is written, never the coordinator's index.
    env = {**os.environ, 'GIT_DIR': gitdir, 'GIT_WORK_TREE': str(snapshot),
           'GIT_INDEX_FILE': str(out / (side + '.index'))}
    subprocess.run(['git', 'read-tree', commit], env=env, check=True)
    scanner = subprocess.run(['bash', 'scripts/check-doc-paths.sh'], cwd=snapshot,
                             env=env, capture_output=True)
    log = scanner.stdout + scanner.stderr
    (out / (side + '.log')).write_bytes(log)
    findings = sorted(line for line in scanner.stdout.decode().splitlines()
                      if line.startswith(('missing:', 'ambiguous:')))
    assert scanner.returncode == record['exit_code'] == 1
    assert findings == record['findings']
    assert count == record['verified_committed_blobs']
    assert hashlib.sha256(log).hexdigest() == record['log_sha256']
    scanner_hash = hashlib.sha256((snapshot / 'scripts/check-doc-paths.sh').read_bytes()).hexdigest()
    assert scanner_hash == record['scanner_sha256']
    result[side] = {**record, 'tree': tree, 'verified_committed_blobs': count,
                    'log': side + '.log', 'log_sha256': hashlib.sha256(log).hexdigest(),
                    'scanner_sha256': scanner_hash}
assert result['base']['findings'] == result['source']['findings']
result.update(identical_findings=26, new_findings=[], global_gate_passed=False)
(out / 'comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['scope', 'identical_findings', 'new_findings', 'global_gate_passed']}))
