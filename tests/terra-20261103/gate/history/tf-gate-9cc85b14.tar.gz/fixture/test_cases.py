import os
import shutil
from pathlib import Path
import subprocess
import tempfile
import unittest

TOOL = Path(__file__).resolve().parents[3] / "scripts/coord-tools/gate.sh"

class GateCases(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="terra gate ")
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.repo = self.root / "repo"
        self.repo.mkdir()
        self.git("init", "-q")
        self.git("config", "user.name", "Fixture")
        self.git("config", "user.email", "fixture@example.invalid")
        for path, content in {"Solidity/A.lean":"def a := 1\n", "Solidity/B.lean":"import Solidity.A\n", "Solidity/C.lean":"import Solidity.B\n", "Solidity/Z.lean":"def z := 1\n", "Solidity.lean":"import Solidity.C\n"}.items():
            self.write(path, content)
        self.git("add", ".")
        self.git("commit", "-qm", "base")
        self.base = self.git("rev-parse", "HEAD")
        self.branch = self.git("branch", "--show-current")
        self.bin = self.root / "bin"
        self.bin.mkdir()
        self.calls = self.root / "calls"
        for name in ("lake",):
            p = self.bin / name
            p.write_text("#!/bin/sh\nprintf '%s\\n' \"" + name + " $*\" >> \"$CALLS\"\n[ \"${FAIL_TOOL:-}\" != \"" + name + "\" ]\n")
            p.chmod(0o755)
        self.logs = self.root / "logs"
        self.env = {k:v for k,v in os.environ.items() if not k.startswith("GATE_")}
        self.env.update(PATH=str(self.bin)+os.pathsep+os.environ["PATH"], CALLS=str(self.calls), GATE_BASE=self.base, GATE_LOGS=str(self.logs), TMPDIR=str(self.root))

    def write(self, name, contents):
        path = self.repo / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(contents)

    def git(self, *args):
        return subprocess.check_output(["git", *map(str, args)], cwd=self.repo, text=True).strip()

    def run_gate(self, *args, cwd=None, **updates):
        return subprocess.run(["/bin/bash", str(TOOL), *args], cwd=cwd or self.repo, env=dict(self.env, **updates), text=True, capture_output=True)

    def calls_read(self):
        return self.calls.read_text().splitlines() if self.calls.exists() else []

    def inspect(self, result, names, statuses=None, logs=None):
        logs = logs or self.logs
        statuses = statuses or ["PASS"] * len(names)
        self.assertEqual(result.returncode, 0 if all(s == "PASS" for s in statuses) else 1, result.stderr)
        self.assertEqual((logs / "HEAD").read_text().strip(), self.git("rev-parse", "HEAD"))
        rows = [line.split("\t") for line in (logs / "gates.tsv").read_text().splitlines()]
        self.assertEqual(len(rows), len(names))
        self.assertEqual({p.name for p in logs.iterdir()}, {"HEAD", "gates.tsv"} | {str(i)+".log" for i in range(1,len(names)+1)})
        for i, (row, name, status) in enumerate(zip(rows, names, statuses), 1):
            self.assertEqual(len(row), 5)
            self.assertEqual(row[:2], [status, name])
            self.assertTrue(row[2].isdigit())
            self.assertEqual(row[3], str(logs / (str(i)+".log")))
            self.assertTrue(row[4])
            self.assertTrue((logs / (str(i)+".log")).is_file())
        self.assertEqual(len(result.stdout.splitlines()), len(names))
        return rows

    def touched(self, expected):
        result = self.run_gate("touched")
        self.inspect(result, ["build-touched"])
        expected = sorted(expected)
        self.assertEqual((self.logs / "1.log").read_text(), "targets: " + (" ".join(expected) if expected else "none") + "\n")
        self.assertEqual(self.calls_read(), ["lake build " + " ".join(expected)] if expected else [])

    def test_usage(self):
        for args in [(), ("per-file",), ("unknown",), ("touched", "extra")]:
            r = self.run_gate(*args)
            self.assertEqual(r.returncode, 2)
            self.assertIn("usage:", r.stderr)
        self.assertFalse(self.logs.exists())
        self.assertEqual(self.calls_read(), [])

    def test_per_file_relative_paths(self):
        r = self.run_gate("per-file", "A.lean", "B.lean", cwd=self.repo / "Solidity")
        self.inspect(r, ["lean:Solidity/A.lean", "lean:Solidity/B.lean"])
        self.assertEqual(self.calls_read(), ["lake env lean --tstack=131072 Solidity/A.lean", "lake env lean --tstack=131072 Solidity/B.lean"])
        self.assertEqual([(self.logs / (str(i)+".log")).read_text() for i in (1,2)], ["", ""])

    def test_relative_logs(self):
        r = self.run_gate("per-file", "A.lean", cwd=self.repo / "Solidity", GATE_LOGS="relative logs")
        logs = self.repo / "Solidity/relative logs"
        self.inspect(r, ["lean:Solidity/A.lean"], logs=logs)
        self.assertEqual(self.calls_read(), ["lake env lean --tstack=131072 Solidity/A.lean"])

    def test_head_stamp(self):
        self.git("commit", "-qm", "next", "--allow-empty")
        r = self.run_gate("per-file", "Solidity/A.lean")
        self.inspect(r, ["lean:Solidity/A.lean"])
        self.assertNotEqual((self.logs / "HEAD").read_text().strip(), self.base)
        self.assertEqual(self.calls_read(), ["lake env lean --tstack=131072 Solidity/A.lean"])

    def test_changed_module(self):
        self.write("Solidity/Z.lean", "def z := 2\n")
        self.touched(["Solidity.Z"])

    def test_reverse_import_closure(self):
        self.write("Solidity/A.lean", "def a := 2\n")
        self.touched(["Solidity.A", "Solidity.B", "Solidity.C"])

    def test_deleted_module_importers(self):
        (self.repo / "Solidity/A.lean").unlink()
        self.touched(["Solidity.B", "Solidity.C"])

    def test_renamed_module_importers(self):
        self.git("mv", "Solidity/A.lean", "Solidity/D.lean")
        self.touched(["Solidity.B", "Solidity.C", "Solidity.D"])

    def test_diverged_base_merge_base(self):
        self.git("checkout", "-qb", "other", self.base)
        self.write("Solidity/Z.lean", "def z := 3\n")
        self.git("commit", "-qam", "other")
        other = self.git("rev-parse", "HEAD")
        self.git("checkout", "-q", self.branch)
        self.write("Solidity/C.lean", "import Solidity.B\ndef c := 1\n")
        self.git("commit", "-qam", "current")
        self.assertEqual(self.git("merge-base", other, "HEAD"), self.base)
        self.env["GATE_BASE"] = other
        self.touched(["Solidity.C"])

    def test_root_module(self):
        self.write("Solidity.lean", "import Solidity.C\n-- root changed\n")
        self.touched(["Solidity"])

    def test_untracked_module(self):
        self.write("Solidity/New.lean", "import Solidity.Z\n")
        self.touched(["Solidity.New"])

    def test_scratch_excluded(self):
        self.write("Solidity/Scratch/Test.lean", "import Solidity.A\n")
        self.touched([])

    def test_failure_exit(self):
        r = self.run_gate("per-file", "Solidity/A.lean", "Solidity/B.lean", FAIL_TOOL="lake")
        self.inspect(r, ["lean:Solidity/A.lean", "lean:Solidity/B.lean"], ["FAIL", "FAIL"])
        self.assertEqual(self.calls_read(), ["lake env lean --tstack=131072 Solidity/A.lean", "lake env lean --tstack=131072 Solidity/B.lean"])

    def all_gates(self, mode):
        # Run the repository check scripts in the disposable checkout. Only
        # lake is mocked; wrappers record and delegate bash and node unchanged.
        source = TOOL.parents[2]
        shutil.copytree(source / "scripts", self.repo / "scripts", ignore=shutil.ignore_patterns("lean-vscode"))
        shutil.copy2(source / "run-lean.sh", self.repo / "run-lean.sh")
        real_node = shutil.which("node")
        self.assertIsNotNone(real_node)
        self.assertFalse((Path.home() / ".elan/bin/lake").exists(), "unsafe lake override would bypass the fake backend")
        for name, executable in (("bash", "/bin/bash"), ("node", real_node)):
            wrapper = self.bin / name
            wrapper.write_text("#!/bin/sh\nprintf '%s\\n' \"" + name + " $*\" >> \"$CALLS\"\nexec \"" + executable + "\" \"$@\"\n")
            wrapper.chmod(0o755)
        names = ["build-touched", "run-lean", "trust", "orphans", "layers", "roots", "doc-paths", "axiom-pins"]
        commands = ["build_touched", "bash run-lean.sh", "bash scripts/check-trust.sh", "node scripts/check-orphans.mjs", "node scripts/check-layers.mjs", "bash scripts/coord-tools/register.sh --check", "bash scripts/check-doc-paths.sh", "node scripts/check-axiom-pins.mjs"]
        if mode == "full":
            names += ["testsuite", "corpus", "automatic-strict"]
            commands += ["bash scripts/check-testsuite.sh", "bash scripts/check-corpus.sh", "node scripts/check-automatic.mjs --strict"]
        # In a minimal repository, several real checks must fail. The fake lake
        # fails closed so no simulated build can masquerade as successful.
        r = self.run_gate(mode, FAIL_TOOL="lake", SOLKEY_EXAMPLES=str(self.root / "missing-solkey"))
        rows = [line.split("\t") for line in (self.logs / "gates.tsv").read_text().splitlines()]
        self.assertEqual([row[1] for row in rows], names)
        self.assertEqual([row[4].strip() for row in rows], commands)
        self.assertEqual(r.returncode, 1)
        self.assertEqual((self.logs / "HEAD").read_text().strip(), self.base)
        self.assertEqual({p.name for p in self.logs.iterdir()}, {"HEAD", "gates.tsv"} | {str(i)+".log" for i in range(1,len(names)+1)})
        statuses = ["PASS", "FAIL", "FAIL", "FAIL", "FAIL", "FAIL", "PASS", "FAIL"]
        if mode == "full":
            statuses += ["FAIL", "FAIL", "PASS"]
        self.assertEqual([row[0] for row in rows], statuses)
        self.assertEqual((self.logs / "1.log").read_text(), "targets: none\n")
        calls = self.calls_read()
        for cmd in commands[1:]:
            self.assertIn(cmd, calls)
        for i, row in enumerate(rows, 1):
            self.assertIn(row[0], ("PASS", "FAIL"))
            self.assertTrue(row[2].isdigit())
            self.assertEqual(row[3], str(self.logs / (str(i)+".log")))
            if row[0] == "FAIL" and row[1] != "corpus":
                self.assertTrue((self.logs / (str(i)+".log")).read_text())
        if mode == "full":
            self.assertIn("lake build Solidity.Corpus.Basic", calls)
        self.assertEqual(len(r.stdout.splitlines()), len(names))

    def test_checkpoint_all_gates(self):
        self.all_gates("checkpoint")

    def test_full_extra_gates(self):
        self.all_gates("full")
