// Lean compiler output
// Module: Solidity.Lowering.V08.HelperPackets.ConstructorTransport.Controls
// Imports: Init Solidity.Lowering.V08.HelperPackets.ConstructorTransport.Producer
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___boxed(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongReached___redArg(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__9;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__11;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__7;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__15;
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultReached(lean_object*, lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__5;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___boxed(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__10;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__13;
lean_object* lean_nat_to_int(lean_object*);
lean_object* l_Int_pow(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__3;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__12;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__21;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__22;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__16;
extern lean_object* l_Solidity_Source_SCtx_body;
lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global(uint8_t);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__3;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__1;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultReached___redArg(lean_object*, lean_object*);
lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initialized(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__19;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__20;
lean_object* lean_int_sub(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__14;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__0;
extern lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongReached(lean_object*, lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__8;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__6;
lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultReached___redArg___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal(uint8_t);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__1;
extern lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl;
extern lean_object* l_Solidity_Source_IntTy_u256;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint;
extern lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__2;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__1;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__17;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__0;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__2;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__18;
lean_object* l_Solidity_Source_Elem_ty(uint8_t, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0(lean_object*);
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Source_IntTy_u256;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__3() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(256u);
x_2 = 0;
x_3 = lean_alloc_ctor(5, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__3;
x_2 = 1;
x_3 = l_Solidity_Source_Elem_ty(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__6;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_3 = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__7;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__5;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_4 = lean_alloc_ctor(19, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__8;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1;
x_4 = l_Solidity_Source_SCtx_body;
x_5 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_1);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_3 = lean_alloc_ctor(6, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__11;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1;
x_4 = l_Solidity_Source_SCtx_body;
x_5 = lean_alloc_ctor(3, 5, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_2);
lean_ctor_set(x_5, 4, x_1);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__14;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_3 = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__15;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__13;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_4 = lean_alloc_ctor(19, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__16;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__10;
x_4 = l_Solidity_Source_SCtx_body;
x_5 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_1);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__10;
x_2 = l_Solidity_Source_SCtx_body;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__18;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__17;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__2;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__10;
x_5 = l_Solidity_Source_SCtx_body;
x_6 = lean_alloc_ctor(1, 6, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_4);
lean_ctor_set(x_6, 3, x_3);
lean_ctor_set(x_6, 4, x_2);
lean_ctor_set(x_6, 5, x_1);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__20() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__19;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__12;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__2;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__10;
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1;
x_6 = l_Solidity_Source_SCtx_body;
x_7 = lean_alloc_ctor(1, 6, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
lean_ctor_set(x_7, 2, x_4);
lean_ctor_set(x_7, 3, x_3);
lean_ctor_set(x_7, 4, x_2);
lean_ctor_set(x_7, 5, x_1);
return x_7;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__21() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__20;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__9;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__2;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1;
x_5 = l_Solidity_Source_SCtx_body;
x_6 = lean_alloc_ctor(1, 6, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_4);
lean_ctor_set(x_6, 3, x_3);
lean_ctor_set(x_6, 4, x_2);
lean_ctor_set(x_6, 5, x_1);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__21;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__2;
x_3 = 0;
x_4 = lean_box(0);
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1;
x_6 = lean_alloc_ctor(0, 6, 1);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_5);
lean_ctor_set(x_6, 3, x_2);
lean_ctor_set(x_6, 4, x_1);
lean_ctor_set(x_6, 5, x_4);
lean_ctor_set_uint8(x_6, sizeof(void*)*6, x_3);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__22;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cell", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__0;
x_3 = lean_string_dec_eq(x_1, x_2);
if (x_3 == 0)
{
lean_object* x_4; 
x_4 = lean_box(0);
return x_4;
}
else
{
lean_object* x_5; 
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__1;
return x_5;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal(uint8_t x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program;
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
lean_object* x_4; lean_object* x_5; uint8_t x_6; 
x_4 = lean_ctor_get(x_2, 3);
lean_dec(x_4);
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global(x_1);
x_6 = !lean_is_exclusive(x_5);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; 
x_7 = lean_ctor_get(x_5, 0);
lean_dec(x_7);
x_8 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___boxed), 1, 0);
lean_ctor_set(x_2, 3, x_8);
lean_ctor_set(x_5, 0, x_2);
return x_5;
}
else
{
uint8_t x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_9 = lean_ctor_get_uint8(x_5, sizeof(void*)*6);
x_10 = lean_ctor_get(x_5, 1);
x_11 = lean_ctor_get(x_5, 2);
x_12 = lean_ctor_get(x_5, 3);
x_13 = lean_ctor_get(x_5, 4);
x_14 = lean_ctor_get(x_5, 5);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_dec(x_5);
x_15 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___boxed), 1, 0);
lean_ctor_set(x_2, 3, x_15);
x_16 = lean_alloc_ctor(0, 6, 1);
lean_ctor_set(x_16, 0, x_2);
lean_ctor_set(x_16, 1, x_10);
lean_ctor_set(x_16, 2, x_11);
lean_ctor_set(x_16, 3, x_12);
lean_ctor_set(x_16, 4, x_13);
lean_ctor_set(x_16, 5, x_14);
lean_ctor_set_uint8(x_16, sizeof(void*)*6, x_9);
return x_16;
}
}
else
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; uint8_t x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; 
x_17 = lean_ctor_get(x_2, 0);
x_18 = lean_ctor_get(x_2, 1);
x_19 = lean_ctor_get(x_2, 2);
x_20 = lean_ctor_get(x_2, 4);
x_21 = lean_ctor_get(x_2, 5);
x_22 = lean_ctor_get(x_2, 6);
lean_inc(x_22);
lean_inc(x_21);
lean_inc(x_20);
lean_inc(x_19);
lean_inc(x_18);
lean_inc(x_17);
lean_dec(x_2);
x_23 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global(x_1);
x_24 = lean_ctor_get_uint8(x_23, sizeof(void*)*6);
x_25 = lean_ctor_get(x_23, 1);
lean_inc_ref(x_25);
x_26 = lean_ctor_get(x_23, 2);
lean_inc_ref(x_26);
x_27 = lean_ctor_get(x_23, 3);
lean_inc_ref(x_27);
x_28 = lean_ctor_get(x_23, 4);
lean_inc_ref(x_28);
x_29 = lean_ctor_get(x_23, 5);
lean_inc(x_29);
if (lean_is_exclusive(x_23)) {
 lean_ctor_release(x_23, 0);
 lean_ctor_release(x_23, 1);
 lean_ctor_release(x_23, 2);
 lean_ctor_release(x_23, 3);
 lean_ctor_release(x_23, 4);
 lean_ctor_release(x_23, 5);
 x_30 = x_23;
} else {
 lean_dec_ref(x_23);
 x_30 = lean_box(0);
}
x_31 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___boxed), 1, 0);
x_32 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_32, 0, x_17);
lean_ctor_set(x_32, 1, x_18);
lean_ctor_set(x_32, 2, x_19);
lean_ctor_set(x_32, 3, x_31);
lean_ctor_set(x_32, 4, x_20);
lean_ctor_set(x_32, 5, x_21);
lean_ctor_set(x_32, 6, x_22);
if (lean_is_scalar(x_30)) {
 x_33 = lean_alloc_ctor(0, 6, 1);
} else {
 x_33 = x_30;
}
lean_ctor_set(x_33, 0, x_32);
lean_ctor_set(x_33, 1, x_25);
lean_ctor_set(x_33, 2, x_26);
lean_ctor_set(x_33, 3, x_27);
lean_ctor_set(x_33, 4, x_28);
lean_ctor_set(x_33, 5, x_29);
lean_ctor_set_uint8(x_33, sizeof(void*)*6, x_24);
return x_33;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = lean_unbox(x_1);
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongReached___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initialized(x_1);
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
lean_inc(x_2);
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(x_3, x_4, x_2);
x_6 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl;
x_7 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(x_5, x_6, x_2);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongReached(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongReached___redArg(x_1, x_2);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(256u);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__0;
x_3 = l_Int_pow(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__2;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__1;
x_3 = lean_int_sub(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__3;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(17u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(88u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial(x_1);
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__0;
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(x_2, x_3, x_4);
x_6 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl;
x_7 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__1;
x_8 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(x_5, x_6, x_7);
return x_8;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultReached___redArg___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(7u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultReached___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial(x_1);
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultReached___redArg___closed__0;
x_6 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(x_3, x_4, x_5);
x_7 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(x_6, x_4, x_2);
x_8 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl;
x_9 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(x_7, x_8, x_5);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultReached(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultReached___redArg(x_1, x_2);
return x_4;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Producer(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Controls(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Producer(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__4);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__5 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__5();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__5);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__6 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__6();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__6);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__7 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__7();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__7);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__8 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__8();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__8);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__9 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__9();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__9);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__10 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__10();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__10);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__11 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__11();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__11);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__12 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__12();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__12);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__13 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__13();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__13);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__14 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__14();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__14);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__15 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__15();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__15);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__16 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__16();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__16);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__17 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__17();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__17);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__18 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__18();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__18);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__19 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__19();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__19);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__20 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__20();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__20);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__21 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__21();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__21);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__22 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__22();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody___closed__22);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongBody);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_wrongGlobal___lam__0___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_maxUint);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultInitial___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultReached___redArg___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultReached___redArg___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_nondefaultReached___redArg___closed__0);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
