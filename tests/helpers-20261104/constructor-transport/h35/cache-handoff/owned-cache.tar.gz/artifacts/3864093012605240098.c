// Lean compiler output
// Module: Solidity.Lowering.V08.HelperPackets.ConstructorTransport.Target
// Imports: Init Solidity.Lowering.V08.HelperPackets.ConstructorTransport.Source
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__7;
lean_object* l_Solidity_Storage_write___redArg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__24;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__12;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__14;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__1;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetRun___redArg___lam__0(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg___lam__1(lean_object*, lean_object*);
lean_object* l_Solidity_ContractWorld_World_empty___redArg(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__9;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__19;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__9;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__8;
LEAN_EXPORT uint8_t l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__1(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__10;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__13;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__1;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__1;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__1___boxed(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__8;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__0;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__10;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__21;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__4;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__2;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__1;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__16;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__2;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__17;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__2;
lean_object* lean_nat_to_int(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__1;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___boxed(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__23;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__18;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__3;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__22;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__14;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__6;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__13;
lean_object* l_Solidity_ContractWorld_Context_tx___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__3;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetReached___redArg(lean_object*);
uint8_t l_Solidity_PrimTy_decEqDenote(uint8_t, lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__11;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__7;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__26;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__2;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_catalog(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__2;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__15;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__2;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetReached(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__5;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__28;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__0;
lean_object* l_Solidity_ContractWorld_World_create___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__20;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__1;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__27;
extern lean_object* l_Solidity_Lowering_V08_Controls_sender;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__0;
lean_object* l_Solidity_Storage_init(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__5;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetRun(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__5;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__11;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg___lam__0___boxed(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__4;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__3;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__12;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__3;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetRun___redArg(lean_object*);
extern lean_object* l_Solidity_Lowering_V08_Controls_self;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__6;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__4;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__25;
lean_object* l_Solidity_SRef_ofRoot___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg___lam__0(lean_object*, lean_object*);
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("saved", 5, 5);
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1() {
_start:
{
uint8_t x_1; lean_object* x_2; 
x_1 = 1;
x_2 = lean_alloc_ctor(0, 0, 1);
lean_ctor_set_uint8(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("captured", 8, 8);
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__3;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__4;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__5;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__2;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("n", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__7;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__8;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("uint", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__10;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__12() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("old", 3, 3);
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__0;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__13;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__14;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__12;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__11;
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__7;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__16;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__13;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__3;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__12;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__20() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__19;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__18;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__21() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__20;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__21;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__23() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__22;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__15;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__24() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = 0;
x_2 = lean_box(0);
x_3 = lean_box(0);
x_4 = lean_alloc_ctor(0, 3, 1);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_3);
lean_ctor_set(x_4, 2, x_2);
lean_ctor_set_uint8(x_4, sizeof(void*)*3, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__25() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__24;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__23;
x_3 = 0;
x_4 = lean_box(0);
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__9;
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(0, 8, 3);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
lean_ctor_set(x_7, 2, x_4);
lean_ctor_set(x_7, 3, x_4);
lean_ctor_set(x_7, 4, x_2);
lean_ctor_set(x_7, 5, x_4);
lean_ctor_set(x_7, 6, x_1);
lean_ctor_set(x_7, 7, x_4);
lean_ctor_set_uint8(x_7, sizeof(void*)*8, x_3);
lean_ctor_set_uint8(x_7, sizeof(void*)*8 + 1, x_3);
lean_ctor_set_uint8(x_7, sizeof(void*)*8 + 2, x_3);
return x_7;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__25;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__27() {
_start:
{
uint8_t x_1; lean_object* x_2; 
x_1 = 0;
x_2 = lean_alloc_ctor(0, 0, 3);
lean_ctor_set_uint8(x_2, 0, x_1);
lean_ctor_set_uint8(x_2, 1, x_1);
lean_ctor_set_uint8(x_2, 2, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__28() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__27;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__26;
x_3 = lean_box(0);
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__6;
x_5 = lean_alloc_ctor(0, 11, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_3);
lean_ctor_set(x_5, 3, x_3);
lean_ctor_set(x_5, 4, x_3);
lean_ctor_set(x_5, 5, x_3);
lean_ctor_set(x_5, 6, x_2);
lean_ctor_set(x_5, 7, x_3);
lean_ctor_set(x_5, 8, x_3);
lean_ctor_set(x_5, 9, x_3);
lean_ctor_set(x_5, 10, x_1);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__28;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_catalog(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell;
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(5u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(93u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; uint8_t x_4; 
x_2 = 1;
x_3 = l_Solidity_Lowering_V08_Controls_sender;
x_4 = l_Solidity_PrimTy_decEqDenote(x_2, x_1, x_3);
if (x_4 == 0)
{
lean_object* x_5; uint8_t x_6; 
x_5 = l_Solidity_Lowering_V08_Controls_self;
x_6 = l_Solidity_PrimTy_decEqDenote(x_2, x_1, x_5);
if (x_6 == 0)
{
lean_object* x_7; 
x_7 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__0;
return x_7;
}
else
{
lean_object* x_8; 
x_8 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__1;
return x_8;
}
}
else
{
lean_object* x_9; 
x_9 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__2;
return x_9;
}
}
}
LEAN_EXPORT uint8_t l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__1(lean_object* x_1) {
_start:
{
uint8_t x_2; 
x_2 = 0;
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___boxed), 1, 0);
x_2 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__1___boxed), 1, 0);
x_3 = l_Solidity_ContractWorld_World_empty___redArg(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__1___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__1(x_1);
x_3 = lean_box(x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__0;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__0;
x_3 = l_Solidity_Lowering_V08_Controls_sender;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__1;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__0() {
_start:
{
uint8_t x_1; lean_object* x_2; 
x_1 = 1;
x_2 = lean_alloc_ctor(0, 0, 1);
lean_ctor_set_uint8(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__12;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__0;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__4() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__3;
x_2 = 1;
x_3 = lean_alloc_ctor(1, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__4;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__5;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__2;
x_3 = 1;
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(3, 3, 1);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_2);
lean_ctor_set(x_5, 2, x_1);
lean_ctor_set_uint8(x_5, sizeof(void*)*3, x_3);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__3;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__9() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__8;
x_2 = 1;
x_3 = lean_alloc_ctor(2, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__10() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__9;
x_2 = 1;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__11() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__10;
x_2 = 1;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__11;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__7;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__1;
x_5 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_1);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__1;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__13;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__12;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__1;
x_4 = lean_alloc_ctor(1, 5, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_3);
lean_ctor_set(x_4, 2, x_3);
lean_ctor_set(x_4, 3, x_2);
lean_ctor_set(x_4, 4, x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_2 = lean_box(0);
x_3 = 1;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__1;
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_6 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__3;
x_7 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__6;
x_8 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_8, 0, x_1);
lean_ctor_set_uint8(x_8, sizeof(void*)*1, x_3);
x_9 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_9, 0, x_8);
lean_ctor_set_uint8(x_9, sizeof(void*)*1, x_3);
x_10 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_10, 0, x_9);
lean_ctor_set_uint8(x_10, sizeof(void*)*1, x_3);
x_11 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_11, 0, x_4);
lean_ctor_set(x_11, 1, x_5);
lean_ctor_set(x_11, 2, x_6);
lean_ctor_set(x_11, 3, x_10);
x_12 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__14;
x_13 = lean_alloc_ctor(1, 5, 0);
lean_ctor_set(x_13, 0, x_4);
lean_ctor_set(x_13, 1, x_4);
lean_ctor_set(x_13, 2, x_4);
lean_ctor_set(x_13, 3, x_11);
lean_ctor_set(x_13, 4, x_12);
x_14 = lean_alloc_ctor(1, 5, 0);
lean_ctor_set(x_14, 0, x_2);
lean_ctor_set(x_14, 1, x_4);
lean_ctor_set(x_14, 2, x_4);
lean_ctor_set(x_14, 3, x_7);
lean_ctor_set(x_14, 4, x_13);
return x_14;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg(x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(7u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__1() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__0;
x_2 = 1;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__2() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__1;
x_2 = 1;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__3() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__2;
x_2 = 1;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__3;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__3;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_1);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_2 = lean_box(0);
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__4;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__1;
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg(x_1);
x_6 = lean_alloc_ctor(28, 3, 0);
lean_ctor_set(x_6, 0, x_2);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_5);
x_7 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__5;
x_8 = lean_alloc_ctor(1, 5, 0);
lean_ctor_set(x_8, 0, x_2);
lean_ctor_set(x_8, 1, x_2);
lean_ctor_set(x_8, 2, x_2);
lean_ctor_set(x_8, 3, x_6);
lean_ctor_set(x_8, 4, x_7);
x_9 = lean_alloc_ctor(1, 5, 0);
lean_ctor_set(x_9, 0, x_2);
lean_ctor_set(x_9, 1, x_2);
lean_ctor_set(x_9, 2, x_2);
lean_ctor_set(x_9, 3, x_3);
lean_ctor_set(x_9, 4, x_8);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg(x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell;
x_2 = l_Solidity_Storage_init(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_Controls_self;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext;
x_4 = l_Solidity_ContractWorld_Context_tx___redArg(x_3, x_2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__1;
x_3 = lean_box(0);
x_4 = lean_box(0);
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__0;
x_6 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_3);
lean_ctor_set(x_6, 3, x_3);
lean_ctor_set(x_6, 4, x_4);
lean_ctor_set(x_6, 5, x_2);
lean_ctor_set(x_6, 6, x_1);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__2;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__0;
x_3 = l_Solidity_SRef_ofRoot___redArg(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__1() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__0;
x_2 = 1;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__3;
x_3 = l_Solidity_SRef_ofRoot___redArg(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__0;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__0;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_5 = l_Solidity_Storage_write___redArg(x_4, x_3, x_2, x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_12; lean_object* x_17; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__0;
x_3 = 1;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1;
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__0;
x_6 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__1;
x_17 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__3;
if (lean_obj_tag(x_17) == 0)
{
x_12 = x_2;
goto block_16;
}
else
{
lean_object* x_18; 
x_18 = lean_ctor_get(x_17, 0);
lean_inc(x_18);
x_12 = x_18;
goto block_16;
}
block_11:
{
lean_object* x_8; lean_object* x_9; 
x_8 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__2;
lean_inc(x_7);
x_9 = l_Solidity_Storage_write___redArg(x_4, x_7, x_8, x_6);
if (lean_obj_tag(x_9) == 0)
{
return x_7;
}
else
{
lean_object* x_10; 
lean_dec(x_7);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
lean_dec_ref(x_9);
return x_10;
}
}
block_16:
{
lean_object* x_13; lean_object* x_14; 
x_13 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_13, 0, x_1);
lean_ctor_set_uint8(x_13, sizeof(void*)*1, x_3);
lean_inc(x_12);
x_14 = l_Solidity_Storage_write___redArg(x_4, x_12, x_5, x_13);
if (lean_obj_tag(x_14) == 0)
{
x_7 = x_12;
goto block_11;
}
else
{
lean_object* x_15; 
lean_dec(x_12);
x_15 = lean_ctor_get(x_14, 0);
lean_inc(x_15);
lean_dec_ref(x_14);
x_7 = x_15;
goto block_11;
}
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetReached___redArg(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered;
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_4 = lean_ctor_get(x_2, 4);
lean_dec(x_4);
x_5 = lean_ctor_get(x_2, 3);
lean_dec(x_5);
x_6 = lean_ctor_get(x_2, 2);
lean_dec(x_6);
x_7 = lean_ctor_get(x_2, 1);
lean_dec(x_7);
x_8 = lean_ctor_get(x_2, 0);
lean_dec(x_8);
x_9 = lean_box(0);
x_10 = lean_box(0);
x_11 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg(x_1);
lean_ctor_set(x_2, 4, x_9);
lean_ctor_set(x_2, 3, x_10);
lean_ctor_set(x_2, 2, x_10);
lean_ctor_set(x_2, 1, x_9);
lean_ctor_set(x_2, 0, x_11);
return x_2;
}
else
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_12 = lean_ctor_get(x_2, 5);
x_13 = lean_ctor_get(x_2, 6);
lean_inc(x_13);
lean_inc(x_12);
lean_dec(x_2);
x_14 = lean_box(0);
x_15 = lean_box(0);
x_16 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg(x_1);
x_17 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_14);
lean_ctor_set(x_17, 2, x_15);
lean_ctor_set(x_17, 3, x_15);
lean_ctor_set(x_17, 4, x_14);
lean_ctor_set(x_17, 5, x_12);
lean_ctor_set(x_17, 6, x_13);
return x_17;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetReached(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetReached___redArg(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg___lam__0(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; lean_object* x_4; uint8_t x_5; 
x_3 = 1;
x_4 = l_Solidity_Lowering_V08_Controls_self;
x_5 = l_Solidity_PrimTy_decEqDenote(x_3, x_2, x_4);
if (x_5 == 0)
{
lean_object* x_6; 
lean_dec(x_1);
x_6 = lean_box(0);
return x_6;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_7 = lean_box(0);
x_8 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg(x_1);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_10, 0, x_9);
return x_10;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg___lam__1(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; lean_object* x_4; uint8_t x_5; 
x_3 = 1;
x_4 = l_Solidity_Lowering_V08_Controls_self;
x_5 = l_Solidity_PrimTy_decEqDenote(x_3, x_2, x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; 
x_6 = lean_ctor_get(x_1, 1);
lean_inc_ref(x_6);
lean_dec_ref(x_1);
x_7 = lean_apply_1(x_6, x_2);
return x_7;
}
else
{
lean_object* x_8; 
lean_dec(x_2);
lean_dec_ref(x_1);
x_8 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__1;
return x_8;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial;
x_3 = lean_ctor_get(x_2, 2);
lean_inc(x_3);
x_4 = lean_ctor_get(x_2, 3);
lean_inc_ref(x_4);
x_5 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg___lam__0___boxed), 2, 1);
lean_closure_set(x_5, 0, x_1);
x_6 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg___lam__1), 2, 1);
lean_closure_set(x_6, 0, x_2);
x_7 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_7, 0, x_5);
lean_ctor_set(x_7, 1, x_6);
lean_ctor_set(x_7, 2, x_3);
lean_ctor_set(x_7, 3, x_4);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg___lam__0___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetNext___redArg___lam__0(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetRun___redArg___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell;
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetRun___redArg(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_2 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetRun___redArg___lam__0), 1, 0);
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial;
x_4 = lean_box(0);
x_5 = l_Solidity_Lowering_V08_Controls_self;
x_6 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg(x_1);
x_7 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext;
x_8 = l_Solidity_ContractWorld_World_create___redArg(x_2, x_3, x_4, x_5, x_6, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetRun(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetRun___redArg(x_1);
return x_3;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Target(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__4 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__4();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__4);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__5 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__5();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__5);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__6 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__6();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__6);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__7 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__7();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__7);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__8 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__8();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__8);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__9 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__9();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__9);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__10 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__10();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__10);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__11 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__11();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__11);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__12 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__12();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__12);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__13 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__13();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__13);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__14 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__14();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__14);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__15 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__15();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__15);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__16 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__16();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__16);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__17 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__17();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__17);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__18 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__18();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__18);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__19 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__19();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__19);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__20 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__20();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__20);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__21 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__21();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__21);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__22 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__22();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__22);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__23 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__23();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__23);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__24 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__24();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__24);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__25 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__25();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__25);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__26 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__26();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__26);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__27 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__27();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__27);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__28 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__28();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell___closed__28);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Cell);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial___lam__0___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetInitial);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetContext);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__4 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__4();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__4);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__5 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__5();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__5);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__6 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__6();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__6);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__7 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__7();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__7);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__8 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__8();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__8);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__9 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__9();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__9);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__10 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__10();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__10);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__11 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__11();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__11);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__12 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__12();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__12);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__13 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__13();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__13);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__14 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__14();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_captureBody___redArg___closed__14);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__4 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__4();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__4);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__5 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__5();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetBody___redArg___closed__5);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_entered);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_targetStore___redArg___closed__3);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
