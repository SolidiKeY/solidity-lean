// Lean compiler output
// Module: Solidity.Lowering.V08.HelperPackets.ConstructorTransport.Source
// Imports: Init Solidity.Lowering.V08.CreationPremises
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__1;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__1;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__0___boxed(lean_object*);
static lean_object* l___auto___closed__0____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__6;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__4;
lean_object* l_Solidity_Source_Q_ofInt(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__3;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__1;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_frame;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___boxed(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__1___boxed(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__18;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__9;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__9;
static lean_object* l___auto___closed__1____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__5;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__8;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__12;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__3;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body;
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__6;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___boxed(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__1;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__5;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__3;
static lean_object* l___auto___closed__10____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l___auto___closed__18____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__2;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__26;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__24;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__1(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2___boxed(lean_object*);
extern lean_object* l_Solidity_Lowering_V08_ConstructorScalarTransport_frame;
static lean_object* l___auto___closed__12____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__7;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__6;
static lean_object* l___auto___closed__19____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__0;
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__2;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint;
static lean_object* l___auto___closed__21____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__1;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__11;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__4___boxed(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__8;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__22;
static lean_object* l___auto___closed__14____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__8;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2(lean_object*);
LEAN_EXPORT lean_object* l___auto____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
lean_object* lean_nat_to_int(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__2;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax;
static lean_object* l___auto___closed__16____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E___closed__0;
lean_object* l_Array_empty(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__4(lean_object*);
extern lean_object* l_Solidity_Source_Examples_u256;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__14;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__6;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__2;
lean_object* l_Solidity_Source_Heap_empty(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__7;
static lean_object* l___auto___closed__20____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__25;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___closed__0;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__18;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg___lam__0(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__1;
extern lean_object* l_Solidity_Source_SCtx_body;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__17;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__3;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__15;
lean_object* l_Solidity_Source_Storage_write___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__7;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global(uint8_t);
lean_object* l_Solidity_Source_ExecState_apply___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__20;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__1;
lean_object* l_Solidity_Source_Decl_path(lean_object*);
extern lean_object* l_Solidity_Lowering_V08_ConstructorScalarTransport_params;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__21;
static lean_object* l___auto___closed__15____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
extern lean_object* l_Solidity_Source_SemanticsExamples_toyFixed;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__4;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__21;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__0;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__20;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_reached(lean_object*, lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__19;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initialized(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__9;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__10;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__4;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__3;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__3(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__15;
static lean_object* l___auto___closed__3____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l___auto___closed__11____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__9;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__14;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__7;
lean_object* l_Solidity_Source_ExecState_run___redArg(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__5;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_locals(lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__6;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl___closed__0;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__2;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__11;
lean_object* l_Solidity_Source_Syn_decls(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__0(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__5;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__17;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__10;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__23;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__0;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__2;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__0;
static lean_object* l___auto___closed__5____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__1;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__3___boxed(lean_object*);
static lean_object* l___auto___closed__4____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__2;
static lean_object* l___auto___closed__7____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
lean_object* l_Solidity_Source_Env_layout(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__16;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___boxed(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__12;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_locals___redArg(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__4;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__4;
static lean_object* l___auto___closed__17____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__10;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(lean_object*, lean_object*, lean_object*);
static lean_object* l___auto___closed__2____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__0___boxed(lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__0(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__13;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__13;
extern lean_object* l_Solidity_Source_IntTy_u256;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__3;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__8;
lean_object* l_Solidity_Source_Heap_alloc___redArg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2(lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__22;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__19;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__5;
lean_object* l_Lean_Name_mkStr1(lean_object*);
lean_object* l_Lean_Name_mkStr4(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_reached___redArg(lean_object*, lean_object*);
static lean_object* l___auto___closed__6____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__2;
static lean_object* l___auto___closed__9____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__0;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__1;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__5;
lean_object* l_Lean_mkAtom(lean_object*);
LEAN_EXPORT uint8_t l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__1(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__1___boxed(lean_object*, lean_object*);
static lean_object* l___auto___closed__8____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
lean_object* l_Solidity_Source_St_init(lean_object*);
lean_object* l_Solidity_Source_Elem_ty(uint8_t, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__1;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__0;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2___closed__0;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg___lam__0___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__16;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__6;
static lean_object* l___auto___closed__13____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
static lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__4;
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__0(lean_object*);
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("saved", 5, 5);
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__1;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_unsigned_to_nat(7u);
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__2;
x_2 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__3;
x_2 = lean_alloc_ctor(73, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__4;
x_2 = lean_box(17);
x_3 = lean_alloc_ctor(3, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__5;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__0;
x_3 = 0;
x_4 = lean_box(0);
x_5 = l_Solidity_Source_Examples_u256;
x_6 = lean_alloc_ctor(26, 6, 1);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_4);
lean_ctor_set(x_6, 3, x_4);
lean_ctor_set(x_6, 4, x_2);
lean_ctor_set(x_6, 5, x_1);
lean_ctor_set_uint8(x_6, sizeof(void*)*6, x_3);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__6;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("captured", 8, 8);
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(17);
x_2 = lean_alloc_ctor(2, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__0;
x_3 = 0;
x_4 = lean_box(0);
x_5 = l_Solidity_Source_Examples_u256;
x_6 = lean_alloc_ctor(26, 6, 1);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_4);
lean_ctor_set(x_6, 3, x_4);
lean_ctor_set(x_6, 4, x_2);
lean_ctor_set(x_6, 5, x_1);
lean_ctor_set_uint8(x_6, sizeof(void*)*6, x_3);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__2;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(7);
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Source_SCtx_body;
x_2 = lean_alloc_ctor(20, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("old", 3, 3);
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__2;
x_2 = lean_box(0);
x_3 = l_Solidity_Source_Examples_u256;
x_4 = lean_alloc_ctor(46, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__0;
x_2 = lean_alloc_ctor(72, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__4;
x_2 = lean_box(17);
x_3 = lean_alloc_ctor(3, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__5;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__3;
x_3 = lean_alloc_ctor(76, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__6;
x_2 = l_Solidity_Source_SCtx_body;
x_3 = lean_alloc_ctor(80, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__7;
x_2 = l_Solidity_Source_SCtx_body;
x_3 = lean_alloc_ctor(95, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("n", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__9;
x_2 = lean_alloc_ctor(72, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__10;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__4;
x_3 = 0;
x_4 = lean_alloc_ctor(68, 2, 1);
lean_ctor_set(x_4, 0, x_2);
lean_ctor_set(x_4, 1, x_1);
lean_ctor_set_uint8(x_4, sizeof(void*)*2, x_3);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__11;
x_2 = lean_alloc_ctor(78, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__12;
x_2 = l_Solidity_Source_SCtx_body;
x_3 = lean_alloc_ctor(80, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__13;
x_2 = l_Solidity_Source_SCtx_body;
x_3 = lean_alloc_ctor(95, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__0;
x_2 = lean_alloc_ctor(72, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__2;
x_2 = lean_alloc_ctor(72, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__16;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__15;
x_3 = 0;
x_4 = lean_alloc_ctor(68, 2, 1);
lean_ctor_set(x_4, 0, x_2);
lean_ctor_set(x_4, 1, x_1);
lean_ctor_set_uint8(x_4, sizeof(void*)*2, x_3);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__17;
x_2 = lean_alloc_ctor(78, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__18;
x_2 = l_Solidity_Source_SCtx_body;
x_3 = lean_alloc_ctor(80, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__20() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__19;
x_2 = l_Solidity_Source_SCtx_body;
x_3 = lean_alloc_ctor(95, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__21() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__1;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__21;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__20;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__1;
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__23() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__22;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__14;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__1;
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__24() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__23;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__8;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__1;
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__25() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__24;
x_2 = l_Solidity_Source_SCtx_body;
x_3 = lean_alloc_ctor(94, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__26() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__25;
x_2 = lean_box(0);
x_3 = 0;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__0;
x_5 = l_Solidity_Lowering_V08_ConstructorScalarTransport_params;
x_6 = lean_alloc_ctor(15, 4, 1);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_2);
lean_ctor_set(x_6, 3, x_1);
lean_ctor_set_uint8(x_6, sizeof(void*)*4, x_3);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__26;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__0() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Cell", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(4);
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__2() {
_start:
{
uint8_t x_1; lean_object* x_2; 
x_1 = 0;
x_2 = lean_alloc_ctor(3, 0, 1);
lean_ctor_set_uint8(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__2;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__3;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__2;
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__4;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__2;
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__5;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__2;
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; uint8_t x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__6;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__1;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__1;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__0;
x_5 = 0;
x_6 = lean_alloc_ctor(10, 4, 1);
lean_ctor_set(x_6, 0, x_4);
lean_ctor_set(x_6, 1, x_3);
lean_ctor_set(x_6, 2, x_2);
lean_ctor_set(x_6, 3, x_1);
lean_ctor_set_uint8(x_6, sizeof(void*)*4, x_5);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(1);
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__8;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__7;
x_3 = lean_box(1);
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__9;
x_2 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__10;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit;
x_2 = l_Solidity_Source_Syn_decls(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E___closed__0;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__0;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__1() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; lean_object* x_4; uint8_t x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax;
x_2 = 0;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__0;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__0;
x_5 = 11;
x_6 = lean_alloc_ctor(0, 3, 2);
lean_ctor_set(x_6, 0, x_4);
lean_ctor_set(x_6, 1, x_3);
lean_ctor_set(x_6, 2, x_1);
lean_ctor_set_uint8(x_6, sizeof(void*)*3, x_5);
lean_ctor_set_uint8(x_6, sizeof(void*)*3 + 1, x_2);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__1;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl___closed__0() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; lean_object* x_4; uint8_t x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax;
x_2 = 0;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__0;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__0;
x_5 = 11;
x_6 = lean_alloc_ctor(0, 3, 2);
lean_ctor_set(x_6, 0, x_4);
lean_ctor_set(x_6, 1, x_3);
lean_ctor_set(x_6, 2, x_1);
lean_ctor_set_uint8(x_6, sizeof(void*)*3, x_5);
lean_ctor_set_uint8(x_6, sizeof(void*)*3 + 1, x_2);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl___closed__0;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Source_IntTy_u256;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0;
return x_1;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__2() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(256u);
x_2 = 0;
x_3 = lean_alloc_ctor(5, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__2;
x_2 = 1;
x_3 = l_Solidity_Source_Elem_ty(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_3 = lean_alloc_ctor(6, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__5;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0;
x_4 = l_Solidity_Source_SCtx_body;
x_5 = lean_alloc_ctor(3, 5, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_2);
lean_ctor_set(x_5, 4, x_1);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__8;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_4 = lean_alloc_ctor(1, 4, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_3);
lean_ctor_set(x_4, 2, x_2);
lean_ctor_set(x_4, 3, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__9;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_3 = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__10;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__7;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_4 = lean_alloc_ctor(19, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__11;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__4;
x_4 = l_Solidity_Source_SCtx_body;
x_5 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_1);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__14;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_3 = lean_alloc_ctor(5, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__15;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__13;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_4 = lean_alloc_ctor(19, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__16;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__4;
x_4 = l_Solidity_Source_SCtx_body;
x_5 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_1);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__4;
x_2 = l_Solidity_Source_SCtx_body;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__18;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__17;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__1;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__4;
x_5 = l_Solidity_Source_SCtx_body;
x_6 = lean_alloc_ctor(1, 6, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_4);
lean_ctor_set(x_6, 3, x_3);
lean_ctor_set(x_6, 4, x_2);
lean_ctor_set(x_6, 5, x_1);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__20() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__19;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__12;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__1;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__4;
x_5 = l_Solidity_Source_SCtx_body;
x_6 = lean_alloc_ctor(1, 6, 0);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_4);
lean_ctor_set(x_6, 3, x_3);
lean_ctor_set(x_6, 4, x_2);
lean_ctor_set(x_6, 5, x_1);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__21() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__20;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__6;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__1;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__4;
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0;
x_6 = l_Solidity_Source_SCtx_body;
x_7 = lean_alloc_ctor(1, 6, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_5);
lean_ctor_set(x_7, 2, x_4);
lean_ctor_set(x_7, 3, x_3);
lean_ctor_set(x_7, 4, x_2);
lean_ctor_set(x_7, 5, x_1);
return x_7;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__22() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__21;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__1;
x_3 = 0;
x_4 = lean_box(0);
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0;
x_6 = lean_alloc_ctor(0, 6, 1);
lean_ctor_set(x_6, 0, x_5);
lean_ctor_set(x_6, 1, x_4);
lean_ctor_set(x_6, 2, x_5);
lean_ctor_set(x_6, 3, x_2);
lean_ctor_set(x_6, 4, x_1);
lean_ctor_set(x_6, 5, x_4);
lean_ctor_set_uint8(x_6, sizeof(void*)*6, x_3);
return x_6;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body() {
_start:
{
lean_object* x_1; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__22;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_box(0);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__1(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0;
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body;
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__0;
x_3 = lean_string_dec_eq(x_1, x_2);
if (x_3 == 0)
{
lean_object* x_4; 
x_4 = lean_box(0);
return x_4;
}
else
{
lean_object* x_5; 
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2___closed__0;
return x_5;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__3(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_box(0);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__4(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_box(0);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(7u);
x_2 = lean_nat_to_int(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__0;
x_2 = l_Solidity_Source_Q_ofInt(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__1;
x_2 = lean_alloc_ctor(14, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__1;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__3;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__2;
x_4 = lean_alloc_ctor(9, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__4;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
x_4 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__5;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__0;
x_3 = lean_string_dec_eq(x_1, x_2);
if (x_3 == 0)
{
lean_object* x_4; 
x_4 = lean_box(0);
return x_4;
}
else
{
lean_object* x_5; 
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__6;
return x_5;
}
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__0;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_1 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__0___boxed), 1, 0);
x_2 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__1___boxed), 1, 0);
x_3 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2___boxed), 1, 0);
x_4 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__3___boxed), 1, 0);
x_5 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__4___boxed), 1, 0);
x_6 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___boxed), 1, 0);
x_7 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___closed__0;
x_8 = lean_alloc_ctor(0, 7, 0);
lean_ctor_set(x_8, 0, x_5);
lean_ctor_set(x_8, 1, x_4);
lean_ctor_set(x_8, 2, x_6);
lean_ctor_set(x_8, 3, x_3);
lean_ctor_set(x_8, 4, x_2);
lean_ctor_set(x_8, 5, x_1);
lean_ctor_set(x_8, 6, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__0(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__1___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__1(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__3___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__3(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__4___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__4(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5(x_1);
lean_dec_ref(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__0(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(93u);
return x_2;
}
}
LEAN_EXPORT uint8_t l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__1(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; 
x_3 = 0;
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_box(0);
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__0;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__1;
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global(uint8_t x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_2 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__0___boxed), 1, 0);
x_3 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__1___boxed), 2, 0);
x_4 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___boxed), 1, 0);
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program;
x_6 = l_Solidity_Source_SemanticsExamples_toyFixed;
x_7 = lean_unsigned_to_nat(0u);
x_8 = lean_alloc_ctor(0, 6, 1);
lean_ctor_set(x_8, 0, x_5);
lean_ctor_set(x_8, 1, x_6);
lean_ctor_set(x_8, 2, x_2);
lean_ctor_set(x_8, 3, x_3);
lean_ctor_set(x_8, 4, x_4);
lean_ctor_set(x_8, 5, x_7);
lean_ctor_set_uint8(x_8, sizeof(void*)*6, x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__0___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__0(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__1___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
uint8_t x_3; lean_object* x_4; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__1(x_1, x_2);
lean_dec(x_2);
lean_dec(x_1);
x_4 = lean_box(x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = lean_unbox(x_1);
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global(x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_frame() {
_start:
{
lean_object* x_1; uint8_t x_2; 
x_1 = l_Solidity_Lowering_V08_ConstructorScalarTransport_frame;
x_2 = !lean_is_exclusive(x_1);
if (x_2 == 0)
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; uint8_t x_8; uint8_t x_9; 
x_3 = lean_ctor_get(x_1, 5);
lean_dec(x_3);
x_4 = lean_ctor_get(x_1, 4);
lean_dec(x_4);
x_5 = lean_ctor_get(x_1, 2);
lean_dec(x_5);
x_6 = lean_box(0);
x_7 = lean_unsigned_to_nat(0u);
x_8 = 1;
x_9 = 0;
lean_ctor_set(x_1, 5, x_6);
lean_ctor_set(x_1, 4, x_7);
lean_ctor_set(x_1, 2, x_7);
lean_ctor_set_uint8(x_1, sizeof(void*)*6, x_9);
lean_ctor_set_uint8(x_1, sizeof(void*)*6 + 1, x_8);
return x_1;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; uint8_t x_15; uint8_t x_16; lean_object* x_17; 
x_10 = lean_ctor_get(x_1, 0);
x_11 = lean_ctor_get(x_1, 1);
x_12 = lean_ctor_get(x_1, 3);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_dec(x_1);
x_13 = lean_box(0);
x_14 = lean_unsigned_to_nat(0u);
x_15 = 1;
x_16 = 0;
x_17 = lean_alloc_ctor(0, 6, 2);
lean_ctor_set(x_17, 0, x_10);
lean_ctor_set(x_17, 1, x_11);
lean_ctor_set(x_17, 2, x_14);
lean_ctor_set(x_17, 3, x_12);
lean_ctor_set(x_17, 4, x_14);
lean_ctor_set(x_17, 5, x_13);
lean_ctor_set_uint8(x_17, sizeof(void*)*6, x_16);
lean_ctor_set_uint8(x_17, sizeof(void*)*6 + 1, x_15);
return x_17;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_locals___redArg(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_2 = l_Solidity_Source_IntTy_u256;
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0;
x_4 = lean_box(0);
x_5 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_5, 0, x_2);
lean_ctor_set(x_5, 1, x_1);
x_6 = lean_box(0);
x_7 = lean_alloc_ctor(1, 4, 0);
lean_ctor_set(x_7, 0, x_3);
lean_ctor_set(x_7, 1, x_4);
lean_ctor_set(x_7, 2, x_5);
lean_ctor_set(x_7, 3, x_6);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_locals(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_locals___redArg(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__0(lean_object* x_1) {
_start:
{
uint8_t x_2; 
x_2 = !lean_is_exclusive(x_1);
if (x_2 == 0)
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_3 = lean_ctor_get(x_1, 1);
lean_dec(x_3);
x_4 = lean_ctor_get(x_1, 0);
lean_dec(x_4);
x_5 = lean_unsigned_to_nat(93u);
x_6 = lean_unsigned_to_nat(3u);
lean_ctor_set(x_1, 1, x_6);
lean_ctor_set(x_1, 0, x_5);
return x_1;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_7 = lean_ctor_get(x_1, 2);
x_8 = lean_ctor_get(x_1, 3);
lean_inc(x_8);
lean_inc(x_7);
lean_dec(x_1);
x_9 = lean_unsigned_to_nat(93u);
x_10 = lean_unsigned_to_nat(3u);
x_11 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_11, 0, x_9);
lean_ctor_set(x_11, 1, x_10);
lean_ctor_set(x_11, 2, x_7);
lean_ctor_set(x_11, 3, x_8);
return x_11;
}
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
x_2 = l_Solidity_Source_Decl_path(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__1() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; 
x_1 = lean_unsigned_to_nat(256u);
x_2 = 0;
x_3 = lean_alloc_ctor(0, 1, 1);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set_uint8(x_3, sizeof(void*)*1, x_2);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__1;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__1;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl;
x_2 = l_Solidity_Source_Decl_path(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1(lean_object* x_1) {
_start:
{
uint8_t x_2; 
x_2 = !lean_is_exclusive(x_1);
if (x_2 == 0)
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_3 = lean_ctor_get(x_1, 3);
x_4 = lean_ctor_get(x_1, 1);
lean_dec(x_4);
x_5 = lean_ctor_get(x_1, 0);
lean_dec(x_5);
x_6 = lean_unsigned_to_nat(5u);
x_7 = lean_unsigned_to_nat(1u);
x_8 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__0;
x_9 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__2;
x_10 = l_Solidity_Source_Storage_write___redArg(x_3, x_8, x_9);
x_11 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__3;
x_12 = l_Solidity_Source_Storage_write___redArg(x_10, x_11, x_9);
lean_ctor_set(x_1, 3, x_12);
lean_ctor_set(x_1, 1, x_7);
lean_ctor_set(x_1, 0, x_6);
return x_1;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; 
x_13 = lean_ctor_get(x_1, 2);
x_14 = lean_ctor_get(x_1, 3);
lean_inc(x_14);
lean_inc(x_13);
lean_dec(x_1);
x_15 = lean_unsigned_to_nat(5u);
x_16 = lean_unsigned_to_nat(1u);
x_17 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__0;
x_18 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__2;
x_19 = l_Solidity_Source_Storage_write___redArg(x_14, x_17, x_18);
x_20 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__3;
x_21 = l_Solidity_Source_Storage_write___redArg(x_19, x_20, x_18);
x_22 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_22, 0, x_15);
lean_ctor_set(x_22, 1, x_16);
lean_ctor_set(x_22, 2, x_13);
lean_ctor_set(x_22, 3, x_21);
return x_22;
}
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__0() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E;
x_2 = l_Solidity_Source_St_init(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E;
x_2 = l_Solidity_Source_Env_layout(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__1;
x_2 = l_Solidity_Source_Heap_empty(x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__3() {
_start:
{
uint8_t x_1; lean_object* x_2; 
x_1 = 0;
x_2 = lean_alloc_ctor(8, 0, 1);
lean_ctor_set_uint8(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__4() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; lean_object* x_4; 
x_1 = lean_box(0);
x_2 = 255;
x_3 = lean_box(x_2);
x_4 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__5() {
_start:
{
lean_object* x_1; uint8_t x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__4;
x_2 = 0;
x_3 = lean_box(x_2);
x_4 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_1);
return x_4;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = lean_box(1);
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__7() {
_start:
{
uint8_t x_1; lean_object* x_2; 
x_1 = 1;
x_2 = lean_alloc_ctor(1, 0, 1);
lean_ctor_set_uint8(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = lean_box(0);
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__7;
x_3 = lean_box(0);
x_4 = lean_box(1);
x_5 = lean_alloc_ctor(1, 4, 0);
lean_ctor_set(x_5, 0, x_4);
lean_ctor_set(x_5, 1, x_3);
lean_ctor_set(x_5, 2, x_2);
lean_ctor_set(x_5, 3, x_1);
return x_5;
}
}
static lean_object* _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__8;
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__6;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__0;
x_3 = !lean_is_exclusive(x_2);
if (x_3 == 0)
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; uint8_t x_18; 
x_4 = lean_ctor_get(x_2, 0);
x_5 = lean_ctor_get(x_2, 4);
lean_dec(x_5);
x_6 = lean_ctor_get(x_2, 3);
lean_dec(x_6);
x_7 = lean_ctor_get(x_2, 2);
lean_dec(x_7);
x_8 = lean_ctor_get(x_2, 1);
lean_dec(x_8);
x_9 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_frame;
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
x_12 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__2;
x_13 = 0;
x_14 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__3;
lean_inc(x_1);
x_15 = lean_alloc_ctor(1, 1, 1);
lean_ctor_set(x_15, 0, x_1);
lean_ctor_set_uint8(x_15, sizeof(void*)*1, x_13);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_14);
lean_ctor_set(x_16, 1, x_15);
x_17 = l_Solidity_Source_Heap_alloc___redArg(x_12, x_16);
x_18 = !lean_is_exclusive(x_17);
if (x_18 == 0)
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; uint8_t x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_19 = lean_ctor_get(x_17, 0);
x_20 = lean_ctor_get(x_17, 1);
lean_dec(x_20);
x_21 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__0), 1, 0);
x_22 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1), 1, 0);
lean_inc(x_11);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_11);
lean_ctor_set(x_23, 1, x_21);
lean_inc(x_10);
x_24 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_24, 0, x_10);
lean_ctor_set(x_24, 1, x_22);
x_25 = lean_box(0);
x_26 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_26, 0, x_24);
lean_ctor_set(x_26, 1, x_25);
x_27 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_27, 0, x_23);
lean_ctor_set(x_27, 1, x_26);
x_28 = l_Solidity_Source_ExecState_run___redArg(x_4, x_27);
x_29 = lean_unsigned_to_nat(0u);
x_30 = 0;
lean_inc(x_1);
lean_inc(x_11);
x_31 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_31, 0, x_11);
lean_ctor_set(x_31, 1, x_29);
lean_ctor_set(x_31, 2, x_1);
lean_ctor_set_uint8(x_31, sizeof(void*)*3, x_30);
x_32 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_25);
lean_ctor_set(x_17, 1, x_1);
lean_ctor_set(x_17, 0, x_10);
x_33 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__5;
x_34 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_34, 0, x_11);
lean_ctor_set(x_34, 1, x_33);
x_35 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_35, 0, x_34);
lean_ctor_set(x_35, 1, x_25);
x_36 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_36, 0, x_17);
lean_ctor_set(x_36, 1, x_35);
x_37 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__9;
lean_ctor_set(x_2, 4, x_37);
lean_ctor_set(x_2, 3, x_36);
lean_ctor_set(x_2, 2, x_32);
lean_ctor_set(x_2, 1, x_19);
lean_ctor_set(x_2, 0, x_28);
return x_2;
}
else
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; uint8_t x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; 
x_38 = lean_ctor_get(x_17, 0);
lean_inc(x_38);
lean_dec(x_17);
x_39 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__0), 1, 0);
x_40 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1), 1, 0);
lean_inc(x_11);
x_41 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_41, 0, x_11);
lean_ctor_set(x_41, 1, x_39);
lean_inc(x_10);
x_42 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_42, 0, x_10);
lean_ctor_set(x_42, 1, x_40);
x_43 = lean_box(0);
x_44 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_44, 0, x_42);
lean_ctor_set(x_44, 1, x_43);
x_45 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_45, 0, x_41);
lean_ctor_set(x_45, 1, x_44);
x_46 = l_Solidity_Source_ExecState_run___redArg(x_4, x_45);
x_47 = lean_unsigned_to_nat(0u);
x_48 = 0;
lean_inc(x_1);
lean_inc(x_11);
x_49 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_49, 0, x_11);
lean_ctor_set(x_49, 1, x_47);
lean_ctor_set(x_49, 2, x_1);
lean_ctor_set_uint8(x_49, sizeof(void*)*3, x_48);
x_50 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_50, 0, x_49);
lean_ctor_set(x_50, 1, x_43);
x_51 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_51, 0, x_10);
lean_ctor_set(x_51, 1, x_1);
x_52 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__5;
x_53 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_53, 0, x_11);
lean_ctor_set(x_53, 1, x_52);
x_54 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_54, 0, x_53);
lean_ctor_set(x_54, 1, x_43);
x_55 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_55, 0, x_51);
lean_ctor_set(x_55, 1, x_54);
x_56 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__9;
lean_ctor_set(x_2, 4, x_56);
lean_ctor_set(x_2, 3, x_55);
lean_ctor_set(x_2, 2, x_50);
lean_ctor_set(x_2, 1, x_38);
lean_ctor_set(x_2, 0, x_46);
return x_2;
}
}
else
{
lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; uint8_t x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; uint8_t x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; 
x_57 = lean_ctor_get(x_2, 0);
lean_inc(x_57);
lean_dec(x_2);
x_58 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_frame;
x_59 = lean_ctor_get(x_58, 0);
lean_inc(x_59);
x_60 = lean_ctor_get(x_58, 1);
lean_inc(x_60);
x_61 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__2;
x_62 = 0;
x_63 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__3;
lean_inc(x_1);
x_64 = lean_alloc_ctor(1, 1, 1);
lean_ctor_set(x_64, 0, x_1);
lean_ctor_set_uint8(x_64, sizeof(void*)*1, x_62);
x_65 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_65, 0, x_63);
lean_ctor_set(x_65, 1, x_64);
x_66 = l_Solidity_Source_Heap_alloc___redArg(x_61, x_65);
x_67 = lean_ctor_get(x_66, 0);
lean_inc(x_67);
if (lean_is_exclusive(x_66)) {
 lean_ctor_release(x_66, 0);
 lean_ctor_release(x_66, 1);
 x_68 = x_66;
} else {
 lean_dec_ref(x_66);
 x_68 = lean_box(0);
}
x_69 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__0), 1, 0);
x_70 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1), 1, 0);
lean_inc(x_60);
x_71 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_71, 0, x_60);
lean_ctor_set(x_71, 1, x_69);
lean_inc(x_59);
x_72 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_72, 0, x_59);
lean_ctor_set(x_72, 1, x_70);
x_73 = lean_box(0);
x_74 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_74, 0, x_72);
lean_ctor_set(x_74, 1, x_73);
x_75 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_75, 0, x_71);
lean_ctor_set(x_75, 1, x_74);
x_76 = l_Solidity_Source_ExecState_run___redArg(x_57, x_75);
x_77 = lean_unsigned_to_nat(0u);
x_78 = 0;
lean_inc(x_1);
lean_inc(x_60);
x_79 = lean_alloc_ctor(1, 3, 1);
lean_ctor_set(x_79, 0, x_60);
lean_ctor_set(x_79, 1, x_77);
lean_ctor_set(x_79, 2, x_1);
lean_ctor_set_uint8(x_79, sizeof(void*)*3, x_78);
x_80 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_80, 0, x_79);
lean_ctor_set(x_80, 1, x_73);
if (lean_is_scalar(x_68)) {
 x_81 = lean_alloc_ctor(0, 2, 0);
} else {
 x_81 = x_68;
}
lean_ctor_set(x_81, 0, x_59);
lean_ctor_set(x_81, 1, x_1);
x_82 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__5;
x_83 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_83, 0, x_60);
lean_ctor_set(x_83, 1, x_82);
x_84 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_84, 0, x_83);
lean_ctor_set(x_84, 1, x_73);
x_85 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_85, 0, x_81);
lean_ctor_set(x_85, 1, x_84);
x_86 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__9;
x_87 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_87, 0, x_76);
lean_ctor_set(x_87, 1, x_67);
lean_ctor_set(x_87, 2, x_80);
lean_ctor_set(x_87, 3, x_85);
lean_ctor_set(x_87, 4, x_86);
return x_87;
}
}
}
static lean_object* _init_l___auto___closed__0____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Lean", 4, 4);
return x_1;
}
}
static lean_object* _init_l___auto___closed__1____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Parser", 6, 6);
return x_1;
}
}
static lean_object* _init_l___auto___closed__2____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Tactic", 6, 6);
return x_1;
}
}
static lean_object* _init_l___auto___closed__3____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("tacticSeq", 9, 9);
return x_1;
}
}
static lean_object* _init_l___auto___closed__4____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l___auto___closed__3____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l___auto___closed__2____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_3 = l___auto___closed__1____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_4 = l___auto___closed__0____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_5 = l_Lean_Name_mkStr4(x_4, x_3, x_2, x_1);
return x_5;
}
}
static lean_object* _init_l___auto___closed__5____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; 
x_1 = l_Array_empty(lean_box(0));
return x_1;
}
}
static lean_object* _init_l___auto___closed__6____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("tacticSeq1Indented", 18, 18);
return x_1;
}
}
static lean_object* _init_l___auto___closed__7____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l___auto___closed__6____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l___auto___closed__2____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_3 = l___auto___closed__1____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_4 = l___auto___closed__0____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_5 = l_Lean_Name_mkStr4(x_4, x_3, x_2, x_1);
return x_5;
}
}
static lean_object* _init_l___auto___closed__8____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("null", 4, 4);
return x_1;
}
}
static lean_object* _init_l___auto___closed__9____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___auto___closed__8____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l_Lean_Name_mkStr1(x_1);
return x_2;
}
}
static lean_object* _init_l___auto___closed__10____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("tacticRfl", 9, 9);
return x_1;
}
}
static lean_object* _init_l___auto___closed__11____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l___auto___closed__10____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l___auto___closed__2____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_3 = l___auto___closed__1____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_4 = l___auto___closed__0____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_5 = l_Lean_Name_mkStr4(x_4, x_3, x_2, x_1);
return x_5;
}
}
static lean_object* _init_l___auto___closed__12____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("rfl", 3, 3);
return x_1;
}
}
static lean_object* _init_l___auto___closed__13____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___auto___closed__12____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l_Lean_mkAtom(x_1);
return x_2;
}
}
static lean_object* _init_l___auto___closed__14____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___auto___closed__13____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l___auto___closed__5____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l___auto___closed__15____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l___auto___closed__14____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l___auto___closed__11____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_3 = lean_box(2);
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l___auto___closed__16____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___auto___closed__15____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l___auto___closed__5____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l___auto___closed__17____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l___auto___closed__16____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l___auto___closed__9____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_3 = lean_box(2);
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l___auto___closed__18____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___auto___closed__17____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l___auto___closed__5____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l___auto___closed__19____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l___auto___closed__18____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l___auto___closed__7____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_3 = lean_box(2);
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l___auto___closed__20____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l___auto___closed__19____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l___auto___closed__5____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_3 = lean_array_push(x_2, x_1);
return x_3;
}
}
static lean_object* _init_l___auto___closed__21____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l___auto___closed__20____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_2 = l___auto___closed__4____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
x_3 = lean_box(2);
x_4 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_1);
return x_4;
}
}
static lean_object* _init_l___auto____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_() {
_start:
{
lean_object* x_1; 
x_1 = l___auto___closed__21____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg___lam__0(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_5 = lean_ctor_get(x_3, 3);
x_6 = l_Solidity_Source_Decl_path(x_1);
x_7 = l_Solidity_Source_IntTy_u256;
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_7);
lean_ctor_set(x_8, 1, x_2);
x_9 = l_Solidity_Source_Storage_write___redArg(x_5, x_6, x_8);
lean_ctor_set(x_3, 3, x_9);
return x_3;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_10 = lean_ctor_get(x_3, 0);
x_11 = lean_ctor_get(x_3, 1);
x_12 = lean_ctor_get(x_3, 2);
x_13 = lean_ctor_get(x_3, 3);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_inc(x_10);
lean_dec(x_3);
x_14 = l_Solidity_Source_Decl_path(x_1);
x_15 = l_Solidity_Source_IntTy_u256;
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_2);
x_17 = l_Solidity_Source_Storage_write___redArg(x_13, x_14, x_16);
x_18 = lean_alloc_ctor(0, 4, 0);
lean_ctor_set(x_18, 0, x_10);
lean_ctor_set(x_18, 1, x_11);
lean_ctor_set(x_18, 2, x_12);
lean_ctor_set(x_18, 3, x_17);
return x_18;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = !lean_is_exclusive(x_1);
if (x_4 == 0)
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_5 = lean_ctor_get(x_1, 0);
x_6 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_frame;
x_7 = lean_ctor_get(x_6, 0);
lean_inc(x_7);
x_8 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg___lam__0___boxed), 3, 2);
lean_closure_set(x_8, 0, x_2);
lean_closure_set(x_8, 1, x_3);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_7);
lean_ctor_set(x_9, 1, x_8);
x_10 = l_Solidity_Source_ExecState_apply___redArg(x_5, x_9);
lean_ctor_set(x_1, 0, x_10);
return x_1;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_11 = lean_ctor_get(x_1, 0);
x_12 = lean_ctor_get(x_1, 1);
x_13 = lean_ctor_get(x_1, 2);
x_14 = lean_ctor_get(x_1, 3);
x_15 = lean_ctor_get(x_1, 4);
lean_inc(x_15);
lean_inc(x_14);
lean_inc(x_13);
lean_inc(x_12);
lean_inc(x_11);
lean_dec(x_1);
x_16 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_frame;
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_alloc_closure((void*)(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg___lam__0___boxed), 3, 2);
lean_closure_set(x_18, 0, x_2);
lean_closure_set(x_18, 1, x_3);
x_19 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_19, 0, x_17);
lean_ctor_set(x_19, 1, x_18);
x_20 = l_Solidity_Source_ExecState_apply___redArg(x_11, x_19);
x_21 = lean_alloc_ctor(0, 5, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_12);
lean_ctor_set(x_21, 2, x_13);
lean_ctor_set(x_21, 3, x_14);
lean_ctor_set(x_21, 4, x_15);
return x_21;
}
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(x_1, x_2, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg___lam__0___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg___lam__0(x_1, x_2, x_3);
lean_dec_ref(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initialized(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_2 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial(x_1);
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__0;
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_reached___redArg(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_3 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initialized(x_1);
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl;
x_5 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(x_3, x_4, x_2);
x_6 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl;
x_7 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__0;
x_8 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_write___redArg(x_5, x_6, x_7);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_reached(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_reached___redArg(x_1, x_2);
return x_4;
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Solidity_Lowering_V08_CreationPremises(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Solidity_Lowering_V08_CreationPremises(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__4 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__4();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__4);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__5 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__5();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__5);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__6 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__6();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax___closed__6);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedSyntax);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedSyntax);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__4 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__4();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__4);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__5 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__5();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__5);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__6 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__6();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__6);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__7 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__7();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__7);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__8 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__8();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__8);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__9 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__9();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__9);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__10 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__10();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__10);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__11 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__11();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__11);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__12 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__12();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__12);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__13 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__13();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__13);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__14 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__14();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__14);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__15 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__15();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__15);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__16 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__16();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__16);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__17 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__17();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__17);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__18 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__18();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__18);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__19 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__19();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__19);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__20 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__20();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__20);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__21 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__21();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__21);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__22 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__22();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__22);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__23 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__23();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__23);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__24 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__24();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__24);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__25 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__25();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__25);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__26 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__26();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax___closed__26);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_constructorSyntax);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__4 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__4();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__4);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__5 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__5();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__5);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__6 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__6();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__6);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__7 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__7();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__7);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__8 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__8();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__8);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__9 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__9();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__9);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__10 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__10();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit___closed__10);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_unit);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_E);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_savedDecl);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_capturedDecl);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_uint);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__4 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__4();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__4);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__5 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__5();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__5);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__6 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__6();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__6);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__7 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__7();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__7);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__8 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__8();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__8);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__9 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__9();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__9);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__10 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__10();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__10);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__11 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__11();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__11);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__12 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__12();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__12);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__13 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__13();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__13);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__14 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__14();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__14);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__15 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__15();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__15);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__16 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__16();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__16);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__17 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__17();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__17);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__18 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__18();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__18);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__19 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__19();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__19);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__20 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__20();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__20);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__21 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__21();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__21);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__22 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__22();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body___closed__22);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_body);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__2___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__4 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__4();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__4);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__5 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__5();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__5);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__6 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__6();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___lam__5___closed__6);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_program);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_global___lam__2___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_frame = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_frame();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_frame);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___lam__1___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__0 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__0();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__0);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__1 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__1();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__1);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__2 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__2();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__2);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__3 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__3();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__3);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__4 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__4();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__4);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__5 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__5();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__5);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__6 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__6();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__6);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__7 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__7();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__7);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__8 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__8();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__8);
l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__9 = _init_l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__9();
lean_mark_persistent(l_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_initial___closed__9);
l___auto___closed__0____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__0____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__0____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__1____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__1____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__1____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__2____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__2____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__2____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__3____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__3____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__3____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__4____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__4____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__4____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__5____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__5____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__5____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__6____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__6____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__6____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__7____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__7____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__7____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__8____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__8____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__8____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__9____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__9____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__9____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__10____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__10____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__10____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__11____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__11____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__11____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__12____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__12____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__12____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__13____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__13____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__13____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__14____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__14____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__14____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__15____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__15____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__15____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__16____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__16____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__16____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__17____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__17____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__17____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__18____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__18____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__18____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__19____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__19____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__19____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__20____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__20____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__20____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto___closed__21____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto___closed__21____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto___closed__21____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
l___auto____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_ = _init_l___auto____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_();
lean_mark_persistent(l___auto____x40_Solidity_Lowering_V08_HelperPackets_ConstructorTransport_Source_92965948____hygCtx___hyg_8_);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
