import Solidity.Frontend.ExecutableAst.Shared.Compose
open Lean Solidity
open Solidity.Frontend.ExecutableAst
#check Shared.executableExpression
#print axioms Shared.executableExpression
#check Shared.executableStatements
#print axioms Shared.executableStatements
#check Shared.executableReader
#print axioms Shared.executableReader
private def decode {α : Type} (x : Except String α) : IO α :=
  match x with
  | .ok value => pure value
  | .error reason => throw (IO.userError reason)
#eval show IO Unit from do
  let fixture ← decode (Json.parse (← IO.FS.readFile
    "docs/benchmarks/directruntime-2026-11-04/published-b86a/C-controls/controls-with-guard/Controls.ast.json"))
  let ast ← decode (fixture.getObjVal? "ast")
  let nodes ← decode (ast.getObjValAs? (Array Json) "nodes")
  let some contract := nodes.find? (fun j => (j.getObjValAs? String "name").toOption == some "ControlTuples")
    | throw (IO.userError "missing fixture contract")
  let members ← decode (contract.getObjValAs? (Array Json) "nodes")
  let functions := members.filter fun j =>
    (j.getObjValAs? String "nodeType").toOption == some "FunctionDefinition" &&
      [some "public", some "external"].contains ((j.getObjValAs? String "visibility").toOption)
  unless functions.size == 13 do throw (IO.userError "expected 13 public fixture functions")
  let rows := functions.map fun fn =>
    let name := ((fn.getObjValAs? String "name").toOption).getD ""
    match Shared.function Shared.executableReader fn contract.compress with
    | .ok (_, d) => Json.mkObj [("name", toJson name), ("accepted", toJson true),
        ("params", toJson d.params.length), ("returns", toJson d.rets.length),
        ("rawStatements", toJson d.body.length)]
    | .error reason => Json.mkObj [("name", toJson name), ("accepted", toJson false),
        ("reason", toJson reason)]
  let rootAccepted := match Shared.contract Shared.executableReader contract with
    | .ok _ => true
    | .error _ => false
  let report := Json.mkObj [("functions", Json.arr rows),
    ("rootStorageValidationAccepted", toJson rootAccepted),
    ("intrinsicProof", toJson false), ("runtimeVerdict", toJson false),
    ("boundary", toJson "Build-time published reader admission only. Separate function translation and root storage validation; no compiler/source adequacy or intrinsic/backend proof.")]
  IO.FS.writeFile "docs/benchmarks/directruntime-2026-11-04/published-b86a/composed-admission.json" report.pretty
  IO.println "13 composed-reader function admission observations saved; no intrinsic proof or runtime verdict implied"
